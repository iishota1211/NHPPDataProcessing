from classicUtils import reportTemplate

def saveBaseDataSet(dataSetDict, dataPersistencePath, nowTimeStr):
	# 保存数据集
	reportName = dataPersistencePath + nowTimeStr + "数据集信息.xlsx"
	reportTemplate.saveBaseDataSet(dataSetDict, reportName)

def saveEstimateBaseResult(estimateDict, dataPersistencePath, nowTimeStr):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + nowTimeStr + "基础估计结果.xlsx"
	reportTemplate.saveEstimateBaseResult(estimateDict, reportName, dictUniName)

def saveEstimateBestResult(estimateDict, dataPersistencePath, nowTimeStr):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + nowTimeStr + "最佳measureValue结果.xlsx"
	reportTemplate.saveEstimateBestResult(estimateDict, reportName, dictUniName)

def savePredictBaseResult(basePredictDict, dataPersistencePath, nowTimeStr):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + nowTimeStr + "基础预测结果.xlsx"
	reportTemplate.savePredictBaseResult(basePredictDict, reportName, dictUniName)

def savePredictBestResult(basePredictDict, dataPersistencePath, nowTimeStr):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + nowTimeStr + "最小PMAE结果.xlsx"
	reportTemplate.savePredictBestResult(basePredictDict, reportName, dictUniName)

def savePredictMeasureMiniResult(basePredictDict, dataPersistencePath, nowTimeStr, mainMeasureOnly = True):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + nowTimeStr + "最佳measureValue的PMAE结果.xlsx"
	reportTemplate.savePredictMeasureMiniResult(basePredictDict, reportName, dictUniName, mainMeasureOnly)

def savePredictResultComparisonWithMeasureMiniResult(basePredictDict, dataPersistencePath, prefixStr):
	reportName = dataPersistencePath + prefixStr + "最佳measureValue的PMAE结果比较.xlsx"
	
	reportTemplate.savePredictResultComparisonWithMeasureMiniResult(basePredictDict, reportName)
	# 函数定义:
	# reportTemplate.savePredictResultComparisonWithMeasureMiniResult(usrPredDict, reportName, uniMethodList = [], showModelName = True)
	# 参数说明:
	# uniMethodList 用于确定比较结果的对象. (可以留空. 此时表示比较predictDict内所有的结果字典)
	# uniMethodList 可以接受以下两种格式的输入:
	# 第一种:
	# uniMethodList = [dictUniName, ...,]
	# 此时只比较uniMethodList内的dictUniName字典之间的结果
	# 第二种:
	# uniMethodList = [uniMethodDict, ...,]
	# uniMethodDict["dictUniName"] 		# 预测结果保存字典
	# uniMethodDict["methodName"] 		# 推参方法. 留空时表示比较dictUniName下所有的推参方法
	# uniMethodDict["measureName"] 		# 模型选择指标. 留空时则只考虑主指标
	# uniMethodDict["nameTitle"] 		# 展示用名称 / 推参方法名称. 留空时则默认等于 "methodName (measureName)"
	# 第一种输入等同于第二种输入除了dictUniName全留空的情形.
	# 
	# showModelName 决定是否展示具有最佳measureValue的"模型名称"(不同于"推参方法名称")

def saveBaseEstimationCostTimeResult(usrEstDict, dataPersistencePath, prefixStr):
	dictUniName = "classicMethod"
	reportName = dataPersistencePath + prefixStr + dictUniName + "推参时间.xlsx"
	reportTemplate.saveEstimationCostTimeResult(usrEstDict, reportName, dictUniName)