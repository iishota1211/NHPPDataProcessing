from setup import init
from classicUtils import generalEstSpark
from classicGlobalLib import classicEstCore

def classicEst(dataSetDict, sc, redisConfDict = None):
	
	modelList = init.getTypeIModel()
	methodList = init.getMethodList()
	nowMethodList = []
	for methodDict in methodList:
		if methodDict["methodName"] == "MLE":
			nowMethodList.append(methodDict)
		elif methodDict["methodName"] == "LSE":
			nowMethodList.append(methodDict)
		elif methodDict["methodName"] == "EM":
			nowMethodList.append(methodDict)
	# 计算各个模型在不同数据集上的经典极大似然估计或经典最小二乘估计参数
	dictUniName = "classicMethod"
	sparkFun = classicEstCore.sparkFun
	estimateDict = generalEstSpark.exec(dataSetDict, modelList, nowMethodList, dictUniName, sparkFun, sc, redisConfDict= redisConfDict)
	# 输入结构 (必须)
	# dataDict["culTrainData"]
	# 
	# 返回值主结构 (新增)
	# dataDict["classicMethod"]
	# 返回值子结构 (新增)
	# 完整训练数据的指标与推参结果
	# modelEstDict = dataDict["classicMethod"][methodName][modelType][modelName]
	# modelEstDict["paraList"]
	# modelEstDict["aliasName"]
	# modelEstDict["culFormatedEstData"]
	# modelEstDict["measureNameList"]
	# modelEstDict["measureValueDict"] = dict()
	# modelEstDict["measureName_A"] = measureValue_A
	# modelEstDict["measureName_B"] = measureValue_B
	# modelEstDict["measureName_C"] = measureValue_C

	return estimateDict






































