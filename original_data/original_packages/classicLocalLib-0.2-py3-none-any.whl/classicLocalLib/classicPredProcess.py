from classicUtils import generalPredSpark, generalRelSpark
from classicGlobalLib import classicPredCore, classicRelCore

def classicPred(estimateDict, sc, redisConfDict = None):
	
	# 计算各个模型在不同数据集上的预测值
	dictUniName = "classicMethod"
	predSparkFun = classicPredCore.sparkFun
	basePredictDict = generalPredSpark.exec(estimateDict, dictUniName, predSparkFun, sc, redisConfDict= redisConfDict)


	#basePredictDict = classicPredSpark.exec(estimateDict, dictUniName, estDictUniName, sc)
	# 输入结构 (必须)
	# dataDict["culTestData"]
	# dataDict["classicMethod"][methodName][modelType][modelName]
	#
	# 返回值主结构 (新增)
	# dataDict["classicMethod"]
	# 完整训练数据的指标与推参结果
	# culTrainDataRes = dataDict["classicMethod"][methodName][modelType][modelName]
	# culTrainDataRes["culPMAE"]
	# culTrainDataRes["nonCulPMAE"]
	# culTrainDataRes["culFormatedPredData"]

	relSparkFun = classicRelCore.sparkFun
	relPredictDict = generalRelSpark.exec(basePredictDict, dictUniName, relSparkFun, sc, redisConfDict= redisConfDict)


	return relPredictDict

























