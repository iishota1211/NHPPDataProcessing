from classicUtils import generalRelAssSpark
from classicGlobalLib import classicRelAssCore

def classicRelAss(estimateDict, sc):
	
	# 计算各个模型在不同数据集上的预测值
	dictUniName = "classicMethod"
	sparkFun = classicRelAssCore.sparkFun


	# 虽然留了接口允许用户额外传入参数，不过目前并未实际使用
	optionDict = dict()

	baseRelAssictDict = generalRelAssSpark.exec(estimateDict, dictUniName, sparkFun, sc, optionDict)
	#baseRelAssictDict = classicRelAssSpark.exec(estimateDict, dictUniName, estDictUniName, sc)
	# 输入结构 (必须)
	# dataDict["culTestData"]
	# dataDict["classicMethod"][methodName][modelType][modelName]
	#
	# 返回值主结构 (新增)
	# dataDict["classicMethod"]
	# 完整训练数据的指标与推参结果
	# culTrainDataRes = dataDict["classicMethod"][methodName][modelType][modelName]
	# culTrainDataRes["bestReleaseTimeList"]
	# culTrainDataRes["softwareReliabilityCulFormatedList"]
	return baseRelAssictDict

























