from classicUtils import FunctionPic

def createPic(dataDict, estModelDict, dataType, picPropertyDict = {}):
	picTitle = picPropertyDict.get("picTitle", None)
	xLabel = picPropertyDict.get("xLabel", "Time")
	yLabel = picPropertyDict.get("yLabel", "Cumulative number of software faults")
	dpi = picPropertyDict.get("dpi", 200)
	markerSize = picPropertyDict.get("markerSize", 2)
	showPointFlag = picPropertyDict.get("showPointFlag", False)
	isNeedEPS = picPropertyDict.get("isNeedEPS", False)
	picFileName = picPropertyDict.get("picFileName", None)
	if picFileName == None:
		return False
	savePicNameList = [picFileName+".jpg"]
	if isNeedEPS == True:
		savePicNameList.append(picFileName+".eps")

	# 值列表
	valueList = []
	# x轴列表
	timeLists = []
	# 模型名称
	labelList = []
	# 图像参数
	propertyList = []

	maxOutputList = []

	if estModelDict is not None:
		# 添加模型图像
		timeLists.append(estModelDict["timeList"])
		valueList.append(estModelDict["valueList"])
		labelList.append(estModelDict["labelName"])
		maxOutputList.append(max(estModelDict["valueList"]))

		propertyDict = dict()
		propertyDict["type"] = "plot"
		propertyDict["lineWidth"] = 0.7
		propertyDict["lineStyle"] = True
		showPoint = estModelDict.get("showPoint", False)
		if showPoint == True:
			propertyDict["showPoint"] = True
			markerSize = estModelDict.get("markerSize", 2)
			propertyDict["markerSize"] 	= markerSize
		propertyList.append(propertyDict)
	
	# 添加数据
	timeLists.append(dataDict["timeList"])
	valueList.append(dataDict["valueList"])
	labelList.append(dataDict["labelName"])
	maxOutputList.append(max(dataDict["valueList"]))
	propertyDict = dict()

	if dataType == "group":
		dataLen = len(dataDict["timeList"])
		xlim = (0.5, dataLen+0.5)
		propertyDict["type"] = "bar"
		propertyDict["edgecolor"] = "black"
		propertyDict["color"] = "white"
	
	elif dataType == "time":
		propertyDict["type"] 		= "plot"
		propertyDict["lineWidth"] 	= 0.7
		propertyDict["lineStyle"] 	= True
		propertyDict["showPoint"] 	= True
		propertyDict["color"]	  	= "black"
		showPoint = dataDict.get("showPoint", True)
		if showPoint == True:
			propertyDict["showPoint"] = True
			markerSize = dataDict.get("markerSize", 2)
			propertyDict["markerSize"] 	= markerSize
		propertyDict["markerSize"] 	= markerSize
	
	propertyList.append(propertyDict)

	# 图片属性字典
	picPropertyDict = dict()
	picPropertyDict["picTitle"] 		= picTitle
	picPropertyDict['titleFontSize'] 	= 9
	picPropertyDict["savePicNameList"] 	= savePicNameList
	picPropertyDict["xLabel"] 	= xLabel
	picPropertyDict["yLabel"] 	= yLabel
	picPropertyDict["dpi"] 		= dpi
	if dataType == "group":
		picPropertyDict["xlim"] = xlim
		if dataLen <= 20:
			picPropertyDict["xInterval"] = 1
	picPropertyDict["picHide"] = True
	# 分割线起始点
	if estModelDict is not None and estModelDict["timeList"][0] > dataDict["timeList"][0]:
		lineList = []
		startPoint_x = estModelDict["timeList"][0]
		lineDict = dict()
		lineDict["startPoint"] 	= [startPoint_x, max(maxOutputList)]
		lineDict["endPoint"] 	= [startPoint_x, 0]
		lineDict["color"] 		= "black"
		lineDict["lineWidth"] 	= 1.5
		lineDict["lineStyle"] 	= True
		lineList.append(lineDict)
		picPropertyDict["lineList"] = lineList
	
	FunctionPic.showPicList(timeLists, valueList, labelList, picPropertyDict, propertyList)
	return True

def timeData(dataDict, estModelDict, picPropertyDict = {}):
	createPic(dataDict, estModelDict, "time", picPropertyDict)

def groupData(dataDict, estModelDict, picPropertyDict = {}):
	createPic(dataDict, estModelDict, "group", picPropertyDict)



























