import copy
from classicUtils import global_variables

# 计算各个模型在不同数据集上的预测值
def main(estimateDict, dictUniName, optionDict = None):
	resDict = copy.deepcopy(estimateDict)
	for dataType in estimateDict:
		for predInterval in estimateDict[dataType]:
			for dataName in estimateDict[dataType][predInterval]:
				# 当前训练数据的字典
				singleEstDict 			= estimateDict[dataType][predInterval][dataName]
				# 当前训练数据
				culFormatedTrainData 	= singleEstDict["culFormatedTrainData"]
				# 当前验证数据
				culFormatedTestData 	= singleEstDict["culFormatedTestData"]
				# 不同推参方法
				for methodName in singleEstDict[dictUniName]:
					for modelType in singleEstDict[dictUniName][methodName]:
						for modelName in singleEstDict[dictUniName][methodName][modelType]:
							estResDict = singleEstDict[dictUniName][methodName][modelType][modelName]
							paraList = estResDict["paraList"]
							methodDict = estResDict["methodDict"]
							# 一周目收集spark任务
							if global_variables.sparkTaskCounter == -1 :
								sparkTaskDict = dict()
								sparkTaskDict["culFormatedTrainData"] = culFormatedTrainData
								sparkTaskDict["culFormatedTestData"] = culFormatedTestData
								sparkTaskDict["paraList"] = paraList
								sparkTaskDict["modelType"] = modelType
								sparkTaskDict["modelName"] = modelName
								sparkTaskDict["dataType"] = dataType
								sparkTaskDict["methodDict"] = methodDict
								if optionDict is None:
									optionDict = dict()
								sparkTaskDict["optionDict"] = optionDict
								#sparkTaskDict["otherPredDict"] = singleEstDict
								global_variables.sparkTaskList.append(sparkTaskDict)
							# 二周目返还spark计算结果
							if global_variables.sparkTaskCounter != -1 :
								# 回收结果
								sparkResDict = global_variables.sparkTaskList[global_variables.sparkTaskCounter]
								global_variables.sparkTaskCounter += 1
								# 整理结果
								tempResDict = copy.deepcopy(estResDict)
								tempResDict["bestReleaseTimeList"] = sparkResDict["bestReleaseTimeList"]
								tempResDict["softwareReliabilityCulFormatedList"] = sparkResDict["softwareReliabilityCulFormatedList"]
								# 保存结果
								resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType][modelName] = tempResDict
	return resDict

def startSpark(sc, sparkFun):
	# Spark计算
	print("spark任务数量 : "+str(len(global_variables.sparkTaskList)))
	paraRDD = sc.parallelize(global_variables.sparkTaskList)
	predictionRDD = paraRDD.map(lambda sparkTaskDict: sparkFun(sparkTaskDict))
	global_variables.sparkTaskList = predictionRDD.collect()
	global_variables.sparkTaskCounter = 0

def exec(estimateDict, dictUniName, sparkFun, sc, optionDict = None):
	# 布置Spark任务
	global_variables.sparkTaskList = []
	global_variables.sparkTaskCounter = -1
	# 收集Spark任务（主逻辑）
	main(estimateDict, dictUniName, optionDict)
	# 提交Spark计算处理
	startSpark(sc, sparkFun)
	# 再次执行并返还Spark计算结果 （再次调用主逻辑）
	resDict = main(estimateDict, dictUniName, optionDict)
	return resDict