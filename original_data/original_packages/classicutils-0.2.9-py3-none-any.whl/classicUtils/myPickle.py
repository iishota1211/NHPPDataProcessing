import pickle,time,paramiko,os,random

def save(pickleName, dataDict):
	#timeStr = str(time.strftime('%Y_%m%d_%H%M_%S_',time.localtime(time.time())))
	# 将对象序列化并写入文件
	with open(pickleName+'.pickle', 'wb') as f:
		pickle.dump(dataDict, f)
	print("序列化保存成功!")
	return pickleName+'.pickle'

def load(pickleName):
	# 从文件中读取序列化的对象
	with open(pickleName+'.pickle', 'rb') as f:
		data_loaded = pickle.load(f)
	print("反序列化读取成功")
	return data_loaded

def send(localPickleName, remote_temp_path, dataDict, destinationIP, username, password, port = 22):
	nowTime = str(time.strftime('%Y_%m%d_%H%M_%S_',time.localtime(time.time())))
	randomNum = ''.join(random.choices('0123456789', k=4))  # 例如 "0427"
	remote_temp_path = remote_temp_path + nowTime + localPickleName + randomNum+".pickle"
	localPicklePath = save(nowTime + localPickleName + randomNum, dataDict)
	print(f"file has been saved in: {localPicklePath}")
	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	ssh.connect(hostname=destinationIP, port=port, username=username, password=password)
	with ssh.open_sftp() as sftp:
		sftp.put(localPicklePath, remote_temp_path)
		print(f"file has been uploaded in: {remote_temp_path}")
		os.system('rm '+localPicklePath)

def sendDebugData(debugDict, localPickleName, debugServerInfoDict):
	remote_temp_path = debugServerInfoDict["remote_temp_path"]
	destinationIP = debugServerInfoDict["destinationIP"]
	if "port" in debugServerInfoDict:
		port = debugServerInfoDict["port"]
	else:
		port = 22
	username = debugServerInfoDict["username"]
	password = debugServerInfoDict["password"]
	send(localPickleName, remote_temp_path, debugDict, destinationIP, username, password, port)





































