# Version 0.2.7
# 新增likelihoodFunc_TypeI:
# 第一版 TypeI-NHPP 似然函数实现
# 包含算数平均，几何平均，调和平均
# 在float精度的基础上做了高精度优化（float疑似越界时会用高精度重算一遍)

# Version 0.2.6
# 更新了输出推参时间报告 saveEstimationCostTimeResult()
# 更新了generalEstSpark, 支持记录推参时间 EstCostTime

# Version 0.2.2
# 更新了 reportTemplate, reportUtilsTemplate 模块。新增了软件可靠性各项指标的通用报告模板

# Version 0.2.1
# 更新了 reportTemplate, reportUtilsTemplate 模块。
# 给reportTemplate.savePredictResultComparisonWithMeasureMiniResult方法新增baselineDict比较功能.
# reportUtilsTemplate 更新bold样式输出

# Version 0.2
# 新增 generalRelAssSpark 模块。用于实现软件可靠性各项指标的通用评价与估计。

# Version 0.1.7
# 更新了reportTemplate模块，增加了measureValue的写入的鲁棒性

# Version 0.1.6
# 更新了reportTemplate模块，缩短了部分工作簿的命名长度

# Version 0.1.5
# 更新了generalEstSpark, generalPredSpark模块。

# Version 0.1.4
# 更新了measure模块。修复了AICC的数据长度判断条件

# Version 0.1.2 - 0.1.3
# 更新了readExcel模块。新增 getSheetName, getSheetLength 功能

# Version 0.1.1
# 更新了measure模块。修复了AICC公式

# Version 0.1.0
# 包名 	: classicUtils
# 功能	: 实现了11种 typeI-NHPP 模型的平均值函数, 强度函数
# 		  实现了基础的全局共享变量, excel表格快捷读取, 对象序列化与反序列化, SRMtool常用工具
# 主要模块与接口 : 
# existSRM.ClassicTypeI().meanValueFunctionTypeI_float(modelName)
# existSRM.ClassicTypeI().intensityFunctionTypeI_float(modelName)
# existSRM.ClassicTypeI().LLF_t_float
# existSRM.ClassicTypeI().LLF_g_float
# RSRAT.getParameter_timeData(nonCulTrainData, modelName)
# RSRAT.getParameter_groupData(nonCulTrainData, modelName)
import classicUtils.SRMtoolv05 as SRMtool
import classicUtils.baseModelv11 as baseModel
import classicUtils.existSRMv10 as existSRM
import classicUtils.parametricEstimationv02 as parametricEstimation
import classicUtils.RSRATv03 as RSRAT
import classicUtils.measurev03 as measure
import classicUtils.readExcelv03 as readExcel
import classicUtils.FunctionPicv03 as FunctionPic