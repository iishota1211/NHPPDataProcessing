# v02
# 新增归一化最大似然估计
# normalizedMaxLikelihoodMethod(dataType, formatedData, meanValueFun, intensityFun)
# 新增归一化最小二乘估计
# normalizedLeastSquaresMethod(goalFun, initPara, formatedData, bounds = None)
# 新增山田毕业论文版最小二乘估计
# leastSquaresMethod2(goalFun, initPara, formatedData, bounds = None)

# v01
# 新增最小二乘估计
# leastSquaresMethod(goalFun, initPara, formatedData, bounds = None)

# 全局变量
#import global_variables

from scipy import optimize
from numpy import emath
from scipy.special import gamma,gammaincc
from classicUtils import SRMtool

def leastSquaresMethod(goalFun, initPara, formatedData, modelType, modelName, bounds = None):
	def lossFun(args, goalFun, formatedData):
		total = 0
		for x,y in formatedData:
			estValue = float(goalFun(x, args))
			total += (estValue - y)**2
		return total
	initRes = lossFun(initPara, goalFun, formatedData)
	res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
	return [res.x, res.fun, initRes,]

def leastSquaresMethod2_simple(goalFun, initPara, formatedData, modelType, modelName, bounds = None):
	def lossFun(args, goalFun, formatedData):
		endX = formatedData[-1][0]
		endY = formatedData[-1][1]
		estEndY = float(goalFun(endX, args))
		if estEndY == 0.0:
			return 999999
		total = 0
		for x,y in formatedData:
			estValue = float(goalFun(x, args))
			total += (estValue/estEndY - y/endY)**2
		return total
	initRes = lossFun(initPara, goalFun, formatedData)
	try:
		res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
	except Exception as e:
		title = "LSM2 推参出错"
		msgStr = modelName+"\n"
		msgStr += str(bounds)+"\n"
		msgStr += str(formatedData)+"\n"
		msgStr += str(initPara)+"\n"
		SRMtool.sendNoticeMail(title,msgStr)
		raise e
	endX = formatedData[-1][0]
	endY = formatedData[-1][1]
	estEndY = float(goalFun(endX, res.x))
	aPara = endY/estEndY
	if aPara == float("inf") or aPara == float("-inf"):
		return [[], "False", "False"]
	paraList = [aPara,]
	for paraValue in res.x:
		paraList.append(paraValue)
	return [paraList, res.fun, initRes]

def normalizedLeastSquaresMethod(goalFun, initPara, formatedData, modelType, modelName, bounds = None):
	def realLossFun(args, goalFun, formatedData):
		total = 0
		endX = formatedData[-1][0]
		endY = formatedData[-1][1]
		for x,y in formatedData:
			estValue = goalFun(x/endX, args)*endY
			total += (estValue - y)**2
		return total
	def lossFun(args, goalFun, formatedData):
		endX = formatedData[-1][0]
		endY = formatedData[-1][1]
		total = 0
		for x,y in formatedData:
			estValue = goalFun(x/endX, args)
			total += (estValue - y/endY)**2
		return total
	bList = []
	cList = []
	i = 10
	s = 0.0000001
	counter = 0
	while counter <= 14:
		bList.append(s)
		cList.append(s)
		s = s * i
		counter += 1
	try:
		isSame1 = True
		isFinish = False
		initRes = realLossFun(initPara, goalFun, formatedData)
		if bounds != None:
			bounds[0][0] = 1
		res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
		lastRes = realLossFun(res.x, goalFun, formatedData)
		isFinish = True
		i = 0
		for p in initPara:
			if res.x[i] != p:
				isSame = False
				break
			i += 1
		if isSame1 == True:
			raise Exception
	except Exception as e:
		"""
		# 先尝试历史成功参数
		for initPara in global_variables.histroyParaList[modelType][modelName]:
			try:
				nLL = lossFun(initPara, goalFun, formatedData)
				if nLL != float("inf") and nLL != float("-inf"):
					initRes = realLossFun(initPara, goalFun, formatedData)
					if bounds != None:
						bounds[0][0] = 1
					res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
					lastRes = realLossFun(res.x, goalFun, formatedData)
				else:
					continue
			except Exception:
				pass
			else:
				isSame = True
				i = 0
				for p in initPara:
					if res.x[i] != p:
						isSame = False
						break
					i += 1
				if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
					print("历史参数成功")
					return [res.x, lastRes, initRes,]
				else:
					continue
		"""
		for b in bList:
			for c in cList:
				try:
					initPara[1] = b
				except Exception as e:
					print(initPara)
					raise e
				initPara[1] = b
				initPara[2] = c
				try:
					nLL = lossFun(initPara, goalFun, formatedData)
					if nLL != float("inf") and nLL != float("-inf"):
						initRes = realLossFun(initPara, goalFun, formatedData)
						if bounds != None:
							bounds[0][0] = 1
						res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
						lastRes = realLossFun(res.x, goalFun, formatedData)
					else:
						continue
				except Exception:
					pass
				else:
					isSame = True
					i = 0
					for p in initPara:
						if res.x[i] != p:
							isSame = False
							break
						i += 1
					if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
						return [res.x, lastRes, initRes,]
					else:
						continue
		return [[],"False","False"]
		raise e
	return [res.x, lastRes, initRes,]

# 还原结果时需要乘上dataLen再除以estEndY
def leastSquaresMethod2(goalFun, initPara, formatedData, modelType, modelName, bounds = None):
	def lossFun(args, goalFun, formatedData):
		endX = formatedData[-1][0]
		endY = formatedData[-1][1]
		#print("endX : "+str(endX))
		#print("endY : "+str(endY))
		estEndY = goalFun(endX, args)
		#print("estEndY : "+str(estEndY))
		total = 0
		for x,y in formatedData:
			estValue = goalFun(x, args)
			total += (estValue/estEndY - y/endY)**2
			#print("estValue/estEndY : "+str(estValue/estEndY)+" y/endY : "+str(y/endY))
		return total

	bList = []
	cList = []
	i = 10
	s = 0.0000001
	counter = 0
	while counter <= 14:
		bList.append(s)
		cList.append(s)
		s = s * i
		counter += 1
	try:
		isSame1 = True
		isFinish = False
		initRes = lossFun(initPara, goalFun, formatedData)
		if bounds != None:
			bounds[0][0] = 1
		res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
		isFinish = True
		i = 0
		for p in initPara:
			if res.x[i] != p:
				isSame = False
				break
			i += 1
		if isSame1 == True:
			raise Exception
	except Exception as e:
		"""
		# 先尝试历史成功参数
		for initPara in global_variables.histroyParaList_yamada[modelType][modelName]:
			try:
				nLL = lossFun(initPara, goalFun, formatedData)
				if nLL != float("inf") and nLL != float("-inf"):
					initRes = lossFun(initPara, goalFun, formatedData)
					if bounds != None:
						bounds[0][0] = 1
					res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
				else:
					continue
			except Exception:
				pass
			else:
				isSame = True
				i = 0
				for p in initPara:
					if res.x[i] != p:
						isSame = False
						break
					i += 1
				if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
					print("历史参数成功")
					return [res.x, res.fun, initRes,]
				else:
					continue
		"""
		for b in bList:
			for c in cList:
				initPara[1] = b
				initPara[2] = c
				try:
					nLL = lossFun(initPara, goalFun, formatedData)
					if nLL != float("inf") and nLL != float("-inf"):
						initRes = lossFun(initPara, goalFun, formatedData)
						if bounds != None:
							bounds[0][0] = 1
						res = optimize.minimize(fun=lossFun, x0=initPara, args=(goalFun, formatedData,), method = "Nelder-Mead", bounds=bounds)
					else:
						continue
				except Exception:
					pass
				else:
					isSame = True
					i = 0
					for p in initPara:
						if res.x[i] != p:
							isSame = False
							break
						i += 1
					if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
						return [res.x, res.fun, initRes,]
					else:
						continue
		return [[],"False","False"]
		raise e
	return [res.x, res.fun, initRes,]




	"""
	args = res.x
	endX = formatedData[-1][0]
	endY = formatedData[-1][1]
	print("endX : "+str(endX))
	print("endY : "+str(endY))
	estEndY = goalFun(endX, args)
	print("estEndY : "+str(estEndY))
	total = 0
	for x,y in formatedData:
		estValue = goalFun(x, args)
		total += (estValue/estEndY - y/endY)**2
		print("estValue/estEndY : "+str(estValue/estEndY)+" y/endY : "+str(y/endY))
	"""
	return [res.x, res.fun, initRes,]

# 时间数据的LLF
# timeDataFormat[0] = [t_i, n_i]
# t_i : failure time
# n_i : cumulative number of software faults
# Numpy version
def normalized_LLF_t_float(args, timeDataFormat, meanValueFun, intensityFun):
	res = 0
	old_t = 0
	old_n = 0
	last_t,last_n, = timeDataFormat[-1]
	dataLen = len(timeDataFormat)

	meanValue = meanValueFun(last_t/last_t, args)*dataLen
	#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
	res = longdouble(- meanValue)
	i = 0
	for dataEle in timeDataFormat:
		t_i = dataEle[0]
		intensity = intensityFun(t_i/last_t, args)*dataLen
		try:
			lnIntensity = emath.log(intensity)
			if intensity == 0.0:
				raise 
		except Exception as e:
			print("args : "+str(args))
			print("i : "+str(i))
			print("t_i : "+str(t_i/last_t)+" intensity : "+str(intensity))
			raise e
		i += 1
		res = res + lnIntensity
	#print("res : ")
	#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
	return float(res)

def GammaFunction(self, x, startTime = 0):
	# new version
	if startTime != 0:
		return gammaincc(x,startTime)
	else:
		return gamma(x)	
# 组数据时的LLF
# groupDataFormat[0] = [t_i, n_i]
# t_i : failure time
# n_i : cumulative number of software faults
# Numpy version
def normalized_LLF_g_float(args, groupDataFormat, meanValueFun, intensityFun):
	"""
	normalizedGroupDataFormat = []
	last_t,last_n, = groupDataFormat[-1]
	for dataEle in groupDataFormat:
		nowTime = dataEle[0]
		nowFaultNumber = dataEle[1]
		normalizedGroupDataFormat.append([nowTime/last_t,nowFaultNumber/last_n])
	last_t,last_n, = normalizedGroupDataFormat[-1]
	"""
	last_t,last_n, = groupDataFormat[-1]
	res = 0
	meanValue = meanValueFun(last_t/last_t, args)
	#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
	res = - meanValue
	i = 0
	oldMeanValue = 0
	oldFaultNumber = 0
	for dataEle in groupDataFormat:
		nowTime = dataEle[0]/last_t
		nowFaultNumber = dataEle[1]/last_n
		nowMeanValue = meanValueFun(nowTime, args)
		intervalMeanValue = nowMeanValue - oldMeanValue
		intervalFaultNumber = nowFaultNumber - oldFaultNumber
		partA = emath.power(intervalMeanValue, intervalFaultNumber)
		partB = GammaFunction(intervalFaultNumber)
		try:
			lnPart = emath.log(partA) - emath.log(partB)
		except Exception as e:
			print("intervalMeanValue : "+str(intervalMeanValue))
			print("intervalFaultNumber : "+str(intervalFaultNumber))
			print("partA : "+str(partA))
			print("partB : "+str(partB))
			print("t_i : "+str(t_i)+" args : "+str(args))
			raise e
		i += 1
		res = res + lnPart
		oldMeanValue = nowMeanValue
		oldFaultNumber = nowFaultNumber
	#print("res : ")
	#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
	return res

def normalizedMaxLikelihoodMethod(dataType, formatedData, meanValueFun, intensityFun,modelType,modelName):
	# 对数似然函数
	if dataType == "time":
		logLikelihoodFunc = normalized_LLF_t_float
	elif dataType == "group":
		logLikelihoodFunc = normalized_LLF_g_float
	"""
	if len(global_variables.histroyParaList[modelType][modelName]) > 0:
		initPara = global_variables.histroyParaList[modelType][modelName][0]
	else:
		initPara = [1,0.01,0.01,]
	"""
	initPara = [1,0.01,0.01,]
	#logLikelihoodFunc = models.LLF_t_float
	def negLikelihoodFunc(args, formatedData, meanValueFun, intensityFun,):
		return -logLikelihoodFunc(args, formatedData, meanValueFun, intensityFun,)
	bounds = []
	bounds.append([0,5000])
	bounds.append([1e-100,None])
	bounds.append([1e-100,None])
	bList = []
	cList = []
	i = 10
	s = 0.0000001
	counter = 0
	while counter <= 14:
		bList.append(s)
		cList.append(s)
		s = s * i
		counter += 1
	try:
		isSame1 = True
		isFinish = False
		res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
		isFinish = True
		i = 0
		for p in initPara:
			if res.x[i] != p:
				isSame = False
				break
			i += 1
		if isSame1 == True:
			raise Exception
	except Exception as e:
		"""
		# 先尝试历史成功参数
		for initPara in global_variables.histroyParaList[modelType][modelName]:
			try:
				nLL = negLikelihoodFunc(initPara, formatedData, meanValueFun, intensityFun)
				if nLL != float("inf") and nLL != float("-inf"):
					res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
				else:
					continue
			except Exception:
				pass
			else:
				isSame = True
				i = 0
				for p in initPara:
					if res.x[i] != p:
						isSame = False
						break
					i += 1
				if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
					#global_variables.histroyParaList.append(res.x)
					print("历史参数成功")
					return res.x
				else:
					continue
		"""
		# 先尝试所有可能的初始参数
		for b in bList:
			for c in cList:
				initPara[1] = b
				initPara[2] = c
				try:
					nLL = negLikelihoodFunc(initPara, formatedData, meanValueFun, intensityFun)
					if nLL != float("inf") and nLL != float("-inf"):
						res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
					else:
						continue
				except Exception:
					pass
				else:
					isSame = True
					i = 0
					for p in initPara:
						if res.x[i] != p:
							isSame = False
							break
						i += 1
					if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
						#global_variables.histroyParaList.append(res.x)
						return res.x
					else:
						continue
		return []
		raise e
	#global_variables.histroyParaList.append(res.x)
	return res.x

















