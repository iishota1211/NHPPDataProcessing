global histroyParaList

histroyParaList = dict()
histroyParaList["typeI"] = dict()
type1ModelNameList = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin"]
for type1ModelName in type1ModelNameList:
	histroyParaList["typeI"][type1ModelName] = []
	#histroyParaList["typeI"][type1ModelName].append([1,0.01,0.01])


global histroyParaList_yamada
histroyParaList_yamada = dict()
histroyParaList_yamada["typeI"] = dict()
type1ModelNameList = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin"]
for type1ModelName in type1ModelNameList:
	histroyParaList_yamada["typeI"][type1ModelName] = []
	#histroyParaList_yamada["typeI"][type1ModelName].append([1,0.01,0.01])


global sparkTaskList
global sparkTaskCounter


































