# Version 0.3
# 抛弃rpy2库, 直接调用Rscript系统命令实现

# Version 0.2
# 倒转了部分模型的参数顺序

# python3 /Users/hello/GoogleDrive/学术相关/python调用rsrat/RSRATv03.py

import subprocess, copy, os
from classicUtils import SRMtool
from rpy2.robjects import r

def modelTran(model):
	if model == "Exp":
		model = "exp"

	elif model == "Gamma":
		model = "gamma"

	elif model == "Pareto":
		model = "pareto"

	elif model == "TruncNormal":
		model = "tnorm"

	elif model == "LogNormal":
		model = "lnorm"

	elif model == "TruncLogist":
		model = "tlogis"

	elif model == "LogLogist":
		model = "llogis"

	elif model == "TruncEVMax":
		model = "txvmax"

	elif model == "LogEVMax":
		model = "lxvmax"

	elif model == "TruncEVMin":
		model = "txvmin"

	elif model == "LogEVMin":
		model = "lxvmin"
	return model

# 非累计数据
def getParameter_groupData(oriList, model):
	dataList = str(oriList)[1:-1].replace(" ", "")
	tempList = dataList.split(",")
	checkList = []
	for x in tempList:
		checkList.append(float(x))
	if sum(checkList) != sum(oriList):
		print("数据字符串化失败！")
		raise
	modelNames = ["Exp","Gamma","Pareto","LogNormal","TruncNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin"]
	# 参数b与c需反转的模型
	inverseModelNames = ["TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
	if model not in modelNames:
		return False
	try:
		oldModelName = model
		model = modelTran(model)
		# R代码字符串
		r_code = """library(Rsrat)
tohma<-c("""+dataList+""")
result <- fit.srm.nhpp(fault=tohma, srm.names=c("{}"))
print(result)""".format(model.lower())
		#print(r_code)
		# 使用echo将R代码传递给Rscript
		process = subprocess.run(['Rscript', '-e', r_code], capture_output=True, text=True)
		stdout = process.stdout.split()
		#print(process.stderr)
		#print(stdout)
		try:
			LLF = float(stdout[-5])
			AIC = float(stdout[-3])
		except Exception as e:
			print(r_code)
			print(process.stdout)
			raise e
		if model == "exp":
			a = float(stdout[-9])
			b = float(stdout[-8])
			resList = ([a,b],[LLF,AIC])
		else:
			a = float(stdout[-10])
			b = float(stdout[-9])
			c = float(stdout[-8])
			resList = ([a,b,c],[LLF,AIC])
			# 模型参数调转
			if oldModelName in inverseModelNames:
				resList = ([a,c,b],[LLF,AIC])
		return resList
	except Exception as e:
		print(r_code)
		print("------------- stdout --------------")
		print(process.stdout)
		print("------------- stderr --------------")
		print(process.stderr)
		print("-------------- detail ---------------------")
		print("PATH=", os.environ.get("PATH"))
		p1 = subprocess.run(["which", "Rscript"], check=True)
		p2 = subprocess.run(["Rscript","-e", "cat(.libPaths(), sep='\\n')"], check=True)
		print(p1.stdout)
		print(p1.stderr)
		print(p2.stdout)
		print(p2.stderr)
		#SRMtool.sendNoticeMail("RSRAT出错", "oriList : "+str(oriList)+"\n model : "+str(model)+"\n stdout : "+str(process.stdout))
		raise e
		return e

# 非累计数据
def getParameter_timeData(oriList, model):
	dataList = copy.deepcopy(oriList)
	if dataList[-1] >= 0:
		dataList.append(-1)
	dataListStr = str(dataList)[1:-1].replace(" ", "")
	tempList = dataListStr.split(",")
	checkList = []
	for x in tempList:
		checkList.append(float(x))
	if oriList[-1] >= 0:
		if sum(checkList)+1 != sum(oriList):
			print("数据字符串化失败！")
			print("dataListStr : "+str(dataListStr))
			print("tempList : "+str(tempList))
			print("checkList : "+str(checkList))
			print("sum(checkList)+1 : "+str(sum(checkList)+1))
			raise
	else:
		if sum(checkList) != sum(oriList):
			print("数据字符串化失败！")
			print("dataListStr : "+str(dataListStr))
			print("tempList : "+str(tempList))
			print("checkList : "+str(checkList))
			print("sum(checkList)+1 : "+str(sum(checkList)+1))
			raise
	
	modelNames = ["Exp","Gamma","Pareto","LogNormal","TruncNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin"]
	# 参数b与c需反转的模型
	inverseModelNames = ["TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
	if model not in modelNames:
		return False
	try:
		oldModelName = model
		model = modelTran(model)
		
		# 使用echo将R代码传递给Rscript
		r_code = """library(Rsrat)
tohma<-c("""+dataListStr+""")
result <- fit.srm.nhpp(time=tohma[tohma>=0], te=-tohma[tohma<0] ,srm.names=c("{}"))
print()
print(result)""".format(model.lower())
		"""
		print(r_code)
		
		process = subprocess.run(['Rscript', '-e', r_code], capture_output=True, text=True)
		stdout = process.stdout.split()
		#print(process.stderr)
		print(process.stdout)
		"""
		
		# 使用rpy2执行R代码
		threshold = 50
		subDataList = SRMtool.split_list(dataList, threshold)
		totalDataStr = "tohma <- c("
		dataStr = ""
		counter = 1
		for subData in subDataList:
			subDataStr = ""
			for nowTime in subData:
				subDataStr += str(float(nowTime)) + ","
			subDataStr = subDataStr[:-1]
			dataStr += "subData"+str(counter)+" <- c("+subDataStr+")\n"
			totalDataStr += "subData"+str(counter)+","
			counter += 1
		totalDataStr = totalDataStr[:-1]
		totalDataStr += ")\n"
		r_code = "library(Rsrat)\n" + dataStr + totalDataStr + "result <- fit.srm.nhpp(time=tohma[tohma>=0], te=-tohma[tohma<0], srm.names=c(\""+str(model.lower())+"\"))"
		
		#print(r_code)
		
		try:
			r(r_code)
			stdout = str(r['result']).split()
			LLF = float(stdout[-5])
			AIC = float(stdout[-3])
			if model == "exp":
				a = float(stdout[-9])
				b = float(stdout[-8])
				resList = ([a,b],[LLF,AIC])
			else:
				a = float(stdout[-10])
				b = float(stdout[-9])
				c = float(stdout[-8])
				resList = ([a,b,c],[LLF,AIC])
				# 模型参数调转
				if oldModelName in inverseModelNames:
					resList = ([a,c,b],[LLF,AIC])
			return resList
		except Exception as e:
			print("------------- r_code --------------")
			print(r_code)
			raise e
	except Exception as e:
		print("r_code")
		print(r_code)
		#SRMtool.sendNoticeMail("RSRAT出错", "oriList : "+str(oriList)+"\n model : "+str(model)+" \n r_code : \n"+str(r_code))
		raise e
		return e
