# 0.3
# 新增根据sheetName查找sheetIndex功能

# 新增 getSheetName 功能
import xlrd

class WorkBook(object):

	def __init__(self, fileName):
		self.rowData = list()
		self.colData = list()
		self.rowDataLen = list()
		self.colDataLen = list()
		self.nameData = list()
		self.indexData = dict()
		self.sheetLength = 0
		# 读取整个工作簿
		#print(fileName)
		wb = xlrd.open_workbook(fileName)
		allSheet = wb.sheets()
		for workSheet in allSheet:
			tempList = []
			for x in range(workSheet.nrows):
				tempList.append(workSheet.row_values(x))
			self.rowData.append(tempList)
			self.rowDataLen.append(len(tempList))
			tempList = []
			for x in range(workSheet.ncols):
				tempList.append(workSheet.col_values(x))
			self.colData.append(tempList)
			self.colDataLen.append(len(tempList))
			sheetName = workSheet.name
			self.nameData.append(sheetName)
			self.indexData[sheetName] = self.sheetLength
			self.sheetLength += 1
		#wb.close()

	def getSheetLength(self):
		return self.sheetLength

	def getSheetName(self, sheetIndex):
		return self.nameData[sheetIndex]

	def getSheetIndex(self, sheetName):
		return self.indexData[sheetName]

	def getRow(self, sheetIndex, row):
		if len(self.rowData[sheetIndex]) == 0:
			return []
		return self.rowData[sheetIndex][row]

	def getRowLen(self, sheetIndex):
		return self.rowDataLen[sheetIndex]

	def getCol(self, sheetIndex, col):
		if len(self.colData[sheetIndex]) == 0:
			return []
		return self.colData[sheetIndex][col]

	def getColLen(self, sheetIndex):
		return self.colDataLen[sheetIndex]

	def getValue(self, sheetIndex, row, col):
		return self.rowData[sheetIndex][row][col]


