import copy, redis, pickle, hashlib, time
from classicUtils import global_variables, SRMtool
from tqdm import tqdm

# 主逻辑
def main(dataSetDict,methodList, debugServerInfoDict = None, sparkFun = None, redisConfDict=None):
	resDict = dict()
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			redisHost = redisConfDict["host"] # "10.30.87.10"
			redisPassword = redisConfDict["password"] # "wJc@2410"
			redisPort = redisConfDict["port"] # 6379
			if "databaseNum" in redisConfDict:
				redisDbNum = redisConfDict["databaseNum"] # 0
			else:
				redisDbNum = 0
			if global_variables.sparkTaskCounter != -1 :
				client = redis.Redis(
					host=redisHost,
					port=redisPort,
					db=redisDbNum,
					password=redisPassword,
					decode_responses=False
				)
		bar = tqdm(len(global_variables.sparkTaskList))
	isFirst = True
	for dataType in dataSetDict:
		for predInterval in dataSetDict[dataType]:
			for dataName in dataSetDict[dataType][predInterval]:
				# 当前训练数据的字典
				singleDataDict 			= dataSetDict[dataType][predInterval][dataName]
				# 当前训练数据
				culFormatedTrainData 	= singleDataDict["culFormatedTrainData"]
				# 当前验证数据
				culFormatedTestData 	= singleDataDict["culFormatedTestData"]
				dataLengthCoe = 1
				if dataLengthCoe in singleDataDict:
					dataLengthCoe 		= singleDataDict["dataLengthCoe"]

				if isFirst == True:
					dataTypeSum = len(dataSetDict.keys())
					predIntervalSum = len(dataSetDict[dataType].keys())
					dataNameSum = len(dataSetDict[dataType][predInterval].keys())
					methodSum = len(methodList)
					print("理论任务总数 : ",dataTypeSum," * ",predIntervalSum," * ",dataNameSum," * ",methodSum," = ",dataTypeSum*predIntervalSum*dataNameSum*methodSum)
				isFirst = False

				# 不同推参方法
				for methodDict in methodList:
					methodName = methodDict["methodName"]
					# 一周目收集spark任务
					if global_variables.sparkTaskCounter == -1 :
						sparkTaskDict = dict()
						sparkTaskDict["culFormatedTrainData"] = culFormatedTrainData
						sparkTaskDict["culFormatedTestData"] = culFormatedTestData
						sparkTaskDict["methodDict"] = copy.deepcopy(methodDict)
						sparkTaskDict["dataType"] = dataType
						sparkTaskDict["predInterval"] = predInterval
						sparkTaskDict["dataName"] = dataName
						sparkTaskDict["debugServerInfoDict"] = debugServerInfoDict
						sparkTaskDict["dataLengthCoe"] = dataLengthCoe
						if len(culFormatedTestData) == 0:
							dataInterval = 1.0
						else:
							dataInterval = culFormatedTrainData[-1][0] / culFormatedTestData[-1][0]
						sparkTaskDict["dataInterval"] = dataInterval
						sparkTaskDict["otherEstDict"] = singleDataDict
						global_variables.sparkTaskList.append([sparkTaskDict, sparkFun, redisConfDict])
					# 二周目返还spark计算结果
					if global_variables.sparkTaskCounter != -1 :
						# 回收结果
						sparkResDict = global_variables.sparkTaskList[global_variables.sparkTaskCounter]
						# 从redis中还原结果
						if redisConfDict is not None:
							hashName = sparkResDict
							exeFlag = False
							for sleepTime in range(3):
								try:
									sparkResDump = client.get(hashName)
								except Exception as e:
									time.sleep(5 + sleepTime*10)
								else:
									exeFlag = True
									break
							if exeFlag == False:
								raise
							sparkResDict = pickle.loads(sparkResDump)
						global_variables.sparkTaskCounter += 1
						# 整理结果
						formatedDataList	= sparkResDict["formatedDataList"]
						methodDict 			= sparkResDict["methodDict"]
						if dataType not in resDict:
							resDict[dataType] = dict()
						if predInterval not in resDict[dataType]:
							resDict[dataType][predInterval] = dict()
						for dataName, singleDataDict in formatedDataList:
							resDict[dataType][predInterval][dataName] = singleDataDict
						# 校验结果是否按预期顺序返还
						if methodName != sparkResDict["methodDict"]["methodName"]:
							raise 
	# 二周目返还spark计算结果
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			client.flushdb()
			client.close()
	return resDict



# 将spark的结果用redis暂存
def sparkFun_redis(args):
	sparkTaskDict = args[0]
	sparkFun = args[1]
	redisConfDict = args[2]
	redisHost = redisConfDict["host"] # "10.30.87.10"
	redisPassword = redisConfDict["password"] # "wJc@2410"
	redisPort = redisConfDict["port"] # 6379
	if "databaseNum" in redisConfDict:
		redisDbNum = redisConfDict["databaseNum"] # 0
	else:
		redisDbNum = 0
	exeFlag = False
	maxSum = 5
	#print("sparkFun()")
	sparkResDict = sparkFun(sparkTaskDict)
	for sleepTime in range(maxSum):
		
		try:
			#print("redis.Redis()")
			client = redis.Redis(
				host=redisHost,
				port=redisPort,
				db=redisDbNum,
				password=redisPassword,
				decode_responses=False
			)
			dumpsDict = pickle.dumps(sparkResDict, protocol=pickle.HIGHEST_PROTOCOL)
			hashName = str(hashlib.sha256(dumpsDict).hexdigest())
			client.set(hashName, dumpsDict)
			client.close()
			exeFlag = True
		except Exception as e:
			if sleepTime < maxSum - 1:
				time.sleep(5 + sleepTime*15)
			else:
				raise e
		else:
			break

	if exeFlag == True:
		#print("return hashName")
		return hashName
	else:
		#print("raise")
		raise


# 启动spark执行计算
def startSpark(sc,sparkFun,redisConfDict,threshold = 30000):
	# spark计算
	#threshold = 5000
	
	print("spark任务数量 : "+str(len(global_variables.sparkTaskList)))
	sparkTaskList_total = SRMtool.split_list(global_variables.sparkTaskList, threshold)
	totalLen = 0
	for subList in sparkTaskList_total:
		totalLen += len(subList)
	print("spark任务实际数量 : "+str(totalLen))
	resTaskList_total = []
	for sparkTaskList in sparkTaskList_total:
		print("当前批次spark任务数量 : "+str(len(sparkTaskList)))
		paraRDD = sc.parallelize(sparkTaskList)
		#predictionRDD = paraRDD.map(lambda sparkTaskDict: sparkFun(sparkTaskDict))
		predictionRDD = paraRDD.map(lambda args: sparkFun_redis(args))
		tempResList = predictionRDD.collect()
		resTaskList_total.append(tempResList)
	global_variables.sparkTaskList = SRMtool.rebuild_list(resTaskList_total)
	global_variables.sparkTaskCounter = 0

# 外部调用接口
def exec(dataSetDict,methodList,sparkFun,sc, debugServerInfoDict = None, redisConfDict=None,threshold = 30000):
	# 测试redis连接
	if redisConfDict is not None:
		redisHost = redisConfDict["host"] # "10.30.87.10"
		redisPassword = redisConfDict["password"] # "wJc@2410"
		redisPort = redisConfDict["port"] # 6379
		if "databaseNum" in redisConfDict:
			redisDbNum = redisConfDict["databaseNum"] # 0
		else:
			redisDbNum = 0
		client = redis.Redis(
			host=redisHost,
			port=redisPort,
			db=redisDbNum,
			password=redisPassword,
			decode_responses=False
		)
		client.set("hello", "world"+str(redisDbNum))
		value = client.get("hello")
		print("Redis Test Results : ", value)
		client.close()
	else:
		print("No Redis Conf (Data)")

	# 布置spark任务
	global_variables.sparkTaskList = []
	global_variables.sparkTaskCounter = -1
	# 收集spark任务（主逻辑）
	main(dataSetDict,methodList, debugServerInfoDict, sparkFun, redisConfDict)
	# 提交spark计算处理
	startSpark(sc,sparkFun, redisConfDict,threshold)
	# 再次执行并返还spark计算结果 （再次调用主逻辑）
	resDict = main(dataSetDict,methodList, debugServerInfoDict, sparkFun, redisConfDict)
	return resDict




































