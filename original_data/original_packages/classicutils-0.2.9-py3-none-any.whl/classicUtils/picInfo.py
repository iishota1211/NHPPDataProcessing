
def writeBoxPlotWithLineInfo(infoList, nowInfoIndex, ws_info, formate):
	# 读取属性
	titleStr = infoList[0]
	yLabel = infoList[1]
	dpi = infoList[2]
	addLine = infoList[3]

	saveFile = infoList[9]
	typeStr = infoList[10]

	# 写入标题
	ws_info.write(0, 2*nowInfoIndex, "属性", formate)
	ws_info.write(1, 2*nowInfoIndex, "图像标题", formate)
	ws_info.write(2, 2*nowInfoIndex, "Y轴名称", formate)
	ws_info.write(3, 2*nowInfoIndex, "图像分辨率", formate)
	ws_info.write(4, 2*nowInfoIndex, "基准线", formate)
	ws_info.write(5, 2*nowInfoIndex, "待使用参数行1", formate)
	ws_info.write(6, 2*nowInfoIndex, "待使用参数行2", formate)
	ws_info.write(7, 2*nowInfoIndex, "待使用参数行3", formate)
	ws_info.write(8, 2*nowInfoIndex, "待使用参数行4", formate)
	ws_info.write(9, 2*nowInfoIndex, "待使用参数行5", formate)
	ws_info.write(10, 2*nowInfoIndex, "保存图像文件名", formate)
	ws_info.write(11, 2*nowInfoIndex, "图像类型", formate)

	# 写入属性
	ws_info.write(0, 2*nowInfoIndex+1, "图"+str(nowInfoIndex+1), formate)
	ws_info.write(1, 2*nowInfoIndex+1, titleStr, formate)
	ws_info.write(2, 2*nowInfoIndex+1, yLabel, formate)
	ws_info.write(3, 2*nowInfoIndex+1, dpi, formate)
	ws_info.write(4, 2*nowInfoIndex+1, addLine, formate)

	ws_info.write(10, 2*nowInfoIndex+1, saveFile, formate)
	ws_info.write(11, 2*nowInfoIndex+1, typeStr, formate)

def writeSingleLineWithBoxPlotInfo(infoList, nowInfoIndex, ws_info, formate):
	# 读取属性
	titleStr = infoList[0]
	xLabel = infoList[1]
	yLabel = infoList[2]
	dpi = infoList[3]
	boxWidth = infoList[4]

	saveFile = infoList[9]
	typeStr = infoList[10]

	# 写入标题
	ws_info.write(0, 2*nowInfoIndex, "属性", formate)
	ws_info.write(1, 2*nowInfoIndex, "图像标题", formate)
	ws_info.write(2, 2*nowInfoIndex, "X轴名称", formate)
	ws_info.write(3, 2*nowInfoIndex, "Y轴名称", formate)
	ws_info.write(4, 2*nowInfoIndex, "图像分辨率", formate)
	ws_info.write(5, 2*nowInfoIndex, "柱状图宽度", formate)
	ws_info.write(6, 2*nowInfoIndex, "预测辅助线粗度", formate)
	ws_info.write(7, 2*nowInfoIndex, "预测辅助线显示", formate)
	ws_info.write(8, 2*nowInfoIndex, "待使用参数行1", formate)
	ws_info.write(9, 2*nowInfoIndex, "待使用参数行2", formate)
	ws_info.write(10, 2*nowInfoIndex, "保存图像文件名", formate)
	ws_info.write(11, 2*nowInfoIndex, "图像类型", formate)

	# 写入属性
	ws_info.write(0, 2*nowInfoIndex+1, "图"+str(nowInfoIndex+1), formate)
	ws_info.write(1, 2*nowInfoIndex+1, titleStr, formate)
	ws_info.write(2, 2*nowInfoIndex+1, xLabel, formate)
	ws_info.write(3, 2*nowInfoIndex+1, yLabel, formate)
	ws_info.write(4, 2*nowInfoIndex+1, dpi, formate)
	ws_info.write(5, 2*nowInfoIndex+1, boxWidth, formate)

	ws_info.write(10, 2*nowInfoIndex+1, saveFile, formate)
	ws_info.write(11, 2*nowInfoIndex+1, typeStr, formate)

def writeDoubleLineWithBoxPlotInfo(infoList, nowInfoIndex, ws_info, formate):
	# 读取属性
	titleStr = infoList[0]
	yLabel = infoList[1]
	dpi = infoList[2]
	addLine = infoList[3]

	saveFile = infoList[9]
	typeStr = infoList[10]

	# 写入标题
	ws_info.write(0, 2*nowInfoIndex, "属性", formate)
	ws_info.write(1, 2*nowInfoIndex, "图像标题", formate)
	ws_info.write(2, 2*nowInfoIndex, "Y轴名称", formate)
	ws_info.write(3, 2*nowInfoIndex, "图像分辨率", formate)
	ws_info.write(4, 2*nowInfoIndex, "基准线", formate)
	ws_info.write(5, 2*nowInfoIndex, "待使用参数行1", formate)
	ws_info.write(6, 2*nowInfoIndex, "待使用参数行2", formate)
	ws_info.write(7, 2*nowInfoIndex, "待使用参数行3", formate)
	ws_info.write(8, 2*nowInfoIndex, "待使用参数行4", formate)
	ws_info.write(9, 2*nowInfoIndex, "待使用参数行5", formate)
	ws_info.write(10, 2*nowInfoIndex, "保存图像文件名", formate)
	ws_info.write(11, 2*nowInfoIndex, "图像类型", formate)

	# 写入属性
	ws_info.write(0, 2*nowInfoIndex+1, "图"+str(nowInfoIndex+1), formate)
	ws_info.write(1, 2*nowInfoIndex+1, titleStr, formate)
	ws_info.write(2, 2*nowInfoIndex+1, yLabel, formate)
	ws_info.write(3, 2*nowInfoIndex+1, dpi, formate)
	ws_info.write(4, 2*nowInfoIndex+1, addLine, formate)

	ws_info.write(10, 2*nowInfoIndex+1, saveFile, formate)
	ws_info.write(11, 2*nowInfoIndex+1, typeStr, formate)

def writeIntervalVRelTimeLineInfo(infoList, nowInfoIndex, ws_info, formate):
	# 读取属性
	titleStr = infoList[0]
	xLabel = infoList[1]
	yLabel = infoList[2]
	dpi = infoList[3]
	fristTestTime = infoList[4]
	secTestTime = infoList[5]

	saveFile = infoList[9]
	typeStr = infoList[10]

	# 写入标题
	ws_info.write(0, 2*nowInfoIndex, "属性", formate)
	ws_info.write(1, 2*nowInfoIndex, "图像标题", formate)
	ws_info.write(2, 2*nowInfoIndex, "X轴名称", formate)
	ws_info.write(3, 2*nowInfoIndex, "Y轴名称", formate)
	ws_info.write(4, 2*nowInfoIndex, "图像分辨率", formate)
	ws_info.write(5, 2*nowInfoIndex, "实际测试截止时间", formate)
	ws_info.write(6, 2*nowInfoIndex, "虚拟测试截止时间", formate)
	ws_info.write(7, 2*nowInfoIndex, "虚拟测试标题字样", formate)
	ws_info.write(8, 2*nowInfoIndex, "待使用参数行1", formate)
	ws_info.write(9, 2*nowInfoIndex, "待使用参数行2", formate)
	ws_info.write(10, 2*nowInfoIndex, "保存图像文件名", formate)
	ws_info.write(11, 2*nowInfoIndex, "图像类型", formate)

	# 写入属性
	ws_info.write(0, 2*nowInfoIndex+1, "图"+str(nowInfoIndex+1), formate)
	ws_info.write(1, 2*nowInfoIndex+1, titleStr, formate)
	ws_info.write(2, 2*nowInfoIndex+1, xLabel, formate)
	ws_info.write(3, 2*nowInfoIndex+1, yLabel, formate)
	ws_info.write(4, 2*nowInfoIndex+1, dpi, formate)
	ws_info.write(5, 2*nowInfoIndex+1, fristTestTime, formate)
	ws_info.write(6, 2*nowInfoIndex+1, secTestTime, formate)

	ws_info.write(10, 2*nowInfoIndex+1, saveFile, formate)
	ws_info.write(11, 2*nowInfoIndex+1, typeStr, formate)

def writeTimeLineInfo(infoList, nowInfoIndex, ws_info, formate):
	# 读取属性
	titleStr = infoList[0]
	xLabel = infoList[1]
	yLabel = infoList[2]
	dpi = infoList[3]
	pointSize = infoList[4]
	

	saveFile = infoList[9]
	typeStr = infoList[10]

	# 写入标题
	ws_info.write(0, 2*nowInfoIndex, "属性", formate)
	ws_info.write(1, 2*nowInfoIndex, "图像标题", formate)
	ws_info.write(2, 2*nowInfoIndex, "X轴名称", formate)
	ws_info.write(3, 2*nowInfoIndex, "Y轴名称", formate)
	ws_info.write(4, 2*nowInfoIndex, "图像分辨率", formate)
	ws_info.write(5, 2*nowInfoIndex, "标记点大小", formate)
	ws_info.write(6, 2*nowInfoIndex, "待使用参数行1", formate)
	ws_info.write(7, 2*nowInfoIndex, "待使用参数行2", formate)
	ws_info.write(8, 2*nowInfoIndex, "待使用参数行3", formate)
	ws_info.write(9, 2*nowInfoIndex, "待使用参数行4", formate)
	ws_info.write(10, 2*nowInfoIndex, "保存图像文件名", formate)
	ws_info.write(11, 2*nowInfoIndex, "图像类型", formate)

	# 写入属性
	ws_info.write(0, 2*nowInfoIndex+1, "图"+str(nowInfoIndex+1), formate)
	ws_info.write(1, 2*nowInfoIndex+1, titleStr, formate)
	ws_info.write(2, 2*nowInfoIndex+1, xLabel, formate)
	ws_info.write(3, 2*nowInfoIndex+1, yLabel, formate)
	ws_info.write(4, 2*nowInfoIndex+1, dpi, formate)
	ws_info.write(5, 2*nowInfoIndex+1, pointSize, formate)

	ws_info.write(10, 2*nowInfoIndex+1, saveFile, formate)
	ws_info.write(11, 2*nowInfoIndex+1, typeStr, formate)


def writeInfo(infoList, nowInfoIndex, ws_info, formate):
	picType = infoList[-1]
	if picType == "boxPlotWithLine":
		writeBoxPlotWithLineInfo(infoList, nowInfoIndex, ws_info, formate)
	elif picType == "singleLineWithBoxPlot":
		writeSingleLineWithBoxPlotInfo(infoList, nowInfoIndex, ws_info, formate)
	elif picType == "doubleLineWithBoxPlot":
		writeDoubleLineWithBoxPlotInfo(infoList, nowInfoIndex, ws_info, formate)
	elif picType == "intervalVRelTimeLine" or picType == "intervalVRelTimeLineNoData":
		writeIntervalVRelTimeLineInfo(infoList, nowInfoIndex, ws_info, formate)
	elif picType == "timeLine":
		writeTimeLineInfo(infoList, nowInfoIndex, ws_info, formate)
	else:
		raise















