# Version 1.0
# 匹配baseModelv10
#
# Version 0.9
# 修改了高精度运算的上下文环境,使得运算精度超过设定值时不会报错而是自动舍入为近似值
# 新增 typeI 模型参数范围字典 bounds(modelName)
#
# Version 0.8
# 新增归一化最大似然估计
# 
# Version 0.7
# 新增生成模拟数据方法(在baseModel中)
# 新增部分模型的逆函数
# 
# Version 0.6
# 新增float精度方法
#
# Version 0.5
# 新增路径依赖
#
# Version 0.4
# python3 /Users/hello/GoogleDrive/学术代码/既存参数化模型/spark/NHPP_type2/existSRMv04.py
# python3 /Users/hello/GoogleDrive/学术代码/复合概率分布/新版实验代码/existSRMv05.py
# python3 /Users/hello/GoogleDrive/学术代码/既存参数化模型/existSRMv05.py
#
# class ClassicTypeI
# class ClassicTypeII
# class ZeroTruncatedZeroInflated

import copy,math
from numpy import emath
from decimal import *
from numpy import longdouble

from classicUtils import baseModel
#import classicGlobalLib.baseModelv10 as baseModel

"""
from baseModel import highPrecisionCalc
from baseModel import usefulMathFunction
from baseModel import NHPPbasedSRM
from baseModel import LindleyDist
from baseModel import BurrDist
"""


class ZeroTruncatedZeroInflated(baseModel.NHPPbasedSRM):

	modelNamesZTZI = None
	baseModelMeanValueFun = None # G(t)
	baseModelIntensityFun = None # g(t)

	meanValueFunctionDict = None
	intensityFunctionDict = None

	def __init__(self, baseModel, prec = 1000):
		super().__init__(prec)
		setcontext(ExtendedContext)
		getcontext().prec = prec
		self.modelNamesZTZI = ["B-ZTP","B-ZIP","ZIB-P","ZIB-ZTP","ZIB-ZIP",]
		if baseModel not in self.baseModelNames:
			raise 
		self.baseModelMeanValueFun = self.baseCumDistFun(baseModel)
		self.baseModelIntensityFun = self.baseInteDistFun(baseModel)
		self.meanValueFunctionDict = {
			"B-ZTP"			:	self.B_ZTP_meanValueFun,
			"B-ZIP"			:	self.B_ZIP_meanValueFun,
			"ZIB-P"			:	self.B_ZIP_meanValueFun,
			"ZIB-ZTP"		:	self.ZIB_ZTP_meanValueFun,
			"ZIB-ZIP"		:	self.ZIB_ZIP_meanValueFun,
		}

		self.intensityFunctionDict = {
			"B-ZTP"			:	self.B_ZTP_intensityFun,
			"B-ZIP"			:	self.B_ZIP_intensityFun,
			"ZIB-P"			:	self.B_ZIP_intensityFun,
			"ZIB-ZTP"		:	self.ZIB_ZTP_intensityFun,
			"ZIB-ZIP"		:	self.ZIB_ZIP_intensityFun,
		}

	def meanValueFunction(self, modelName):
		if modelName not in self.modelNamesZTZI:
			return None
		return self.meanValueFunctionDict[modelName]

	def intensityFunction(self, modelName):
		if modelName not in self.modelNamesZTZI:
			return None
		return self.intensityFunctionDict[modelName]

	def B_ZTP_meanValueFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		#print(float(Gt))
		partA = Decimal( Decimal(1) - Decimal(-v).exp() ).ln()
		partLn = Decimal(-v*Gt).exp() - Decimal(-v).exp()
		partB = Decimal( partLn ).ln()
		res = partA - partB
		return res

	def B_ZIP_meanValueFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w1 = Decimal(args[1])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		#print("Gt : "+str(float(Gt)))
		res = Decimal( w1 + ( Decimal(1) - w1 ) * Decimal( -v*Gt ).exp() ).ln()
		return -res

	def ZIB_ZTP_meanValueFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w2 = Decimal(args[1])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		#print("Gt : "+str(float(Gt)))
		partA = Decimal( Decimal(1) - Decimal(-v).exp() ).ln()
		partB = Decimal( w2 * ( Decimal(1) - Decimal( -v ).exp() ) + ( Decimal(1) - w2 ) * ( Decimal(-v*Gt).exp() - Decimal(-v).exp() ) ).ln()
		res = partA - partB
		return res

	def ZIB_ZIP_meanValueFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w1 = Decimal(args[1])
		w2 = Decimal(args[2])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		#print("w1 : "+str(float(w1))+" w2 : "+str(float(w2)))
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		#print("Gt : "+str(float(Gt)))
		part = w1 + w2 - w1*w2
		res = Decimal( part + ( Decimal(1) - part ) * Decimal( -v*Gt ).exp() ).ln()
		return -res

	def B_ZTP_intensityFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		g_t = self.baseModelIntensityFun(t, copyArgs)
		expVGt = Decimal(-v*Gt).exp()
		expV = Decimal(-v).exp()
		res = (expVGt * v * g_t) / (expVGt - expV)
		#print("partA : "+str(float(expVGt * v * g_t)))
		#print("partB : "+str(float(expVGt - expV)))
		return res

	def B_ZIP_intensityFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w1 = Decimal(args[1])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		g_t = self.baseModelIntensityFun(t, copyArgs)
		expVGt = Decimal(-v*Gt).exp()
		expV = Decimal(-v).exp()
		w1_1 = Decimal(1) - w1
		res = ( expVGt * v * g_t * w1_1 ) / ( w1_1 * expVGt + w1 )
		return res

	def ZIB_ZTP_intensityFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w2 = Decimal(args[1])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		g_t = self.baseModelIntensityFun(t, copyArgs)
		expVGt = Decimal(-v*Gt).exp()
		expV = Decimal(-v).exp()
		w2_1 = Decimal(1) - w2
		partA = expVGt * v * g_t * w2_1
		partB = w2_1 * ( expVGt - expV ) + w2 * ( 1 - expV )
		res = partA / partB
		return res


	def ZIB_ZIP_intensityFun(self, t, args):
		args = list(args)
		v = Decimal(args[0])
		w1 = Decimal(args[1])
		w2 = Decimal(args[2])
		copyArgs = copy.deepcopy(args)
		del copyArgs[0]
		del copyArgs[0]
		del copyArgs[0]
		#print(copyArgs)
		Gt = self.baseModelMeanValueFun(t, copyArgs)
		g_t = self.baseModelIntensityFun(t, copyArgs)
		#print("Gt : "+str(float(Gt)))
		#print("D_Gt : "+str(float(g_t)))
		expVGt = Decimal(-v*Gt).exp()
		#expV = Decimal(-v).exp()
		w1_1 = Decimal(1) - w1
		w2_1 = Decimal(1) - w2
		partA = expVGt * v * g_t * w1_1 * w2_1
		partB = w1 + w2 - w1*w2 + w1_1 * w2_1 * expVGt
		#print("expVGt : "+str(float(expVGt)))
		#print("partA : "+str(float(partA)))
		#print("partB : "+str(float(partB)))
		#print("partB_1 : "+str(float(w1_1 * w2_1 * expVGt)))
		#print("partB_2 : "+str(float(w1 + w2 - w1*w2)))

		res = partA / partB
		return res
"""

v = 100
w1 = 0.5
w2 = 0.5
b = 2
c = 2
t = 10

t = 10
v = 2
w1 = 0.5
w2 = 0.4
b = 2
c = 3
args1 = [v,b,c]
args2 = [v,w1,b,c]
args3 = [v,w2,b,c]
args4 = [v,w1,w2,b,c]

baseModelNames = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
#baseModelNames = ["Gamma",]
modelNamesZTZI = ["B-ZTP","B-ZIP","ZIB-ZTP","ZIB-ZIP",]
argsList = [args1,args2,args3,args4,]
modelNamesZTZI = ["B-ZTP",]
argsList = [args1]

index = 0


NHPPbaseModel = baseModel.NHPPbasedSRM()
try:
	res1 = NHPPbaseModel.GammaBaseMVF(t,[b,c])
	#print(float(res1))
except Exception as e:
	print(e)
try:
	res2 = NHPPbaseModel.GammaBaseMVF_mathematica(t,[b,c])
	#print(res2)
except Exception as e:
	print(e)


for modelName in modelNamesZTZI:
	args = argsList[index]
	for baseModel in baseModelNames:
		#print(modelName + " " + baseModel)
		comModel = ZeroTruncatedZeroInflated(baseModel)
		meanValueFun = comModel.meanValueFunction(modelName)
		intensityFun = comModel.intensityFunction(modelName)
		#meanValue = meanValueFun(t, args)
		intensity = intensityFun(t, args)
		print(modelName + " " + baseModel+" : "+str(intensity))
		#print("intensity : "+str(intensity))
	index += 1
"""



"""
modelName = "ZIB-ZTP"
baseModelName = "TruncEVMin"
t = 939
#args = [35.61520311, 0.0, 5934.13465482, 0.0]
args = [3.60089154, 0.0, 100.728756, 5.46732871e-07]
print(modelName)
print(baseModelName)
comModel = ZeroTruncatedZeroInflated(baseModelName,10000)
meanValueFun = comModel.meanValueFunction(modelName)
meanValue = meanValueFun(t, args)
print(modelName + " " + baseModelName+" : "+str(meanValue))
"""





# t_i : software fault count group data
# n_i : cumulative number of software faults
# JM模型在组数据上的LLF无法使用, 只能用LF. 
# 因为JM模型的LLF无法计算单日故障数为0的数据集
class JM(baseModel.highPrecisionCalc):

	def __init__(self,):
		pass

	def meanValueFunction(self, t, args):
		N = args[0]
		b = args[1]

		partA = 1 - math.exp(- b * t)

		return N * partA

	# 计算 n的阶乘 / s的阶乘 且 s必须小于n
	def factorial(self, n, s = 0):
		if n < 0 or s < 0:
			raise 
			return False
		if s > n:
			raise 
			return False
		startPoint = s + 1
		res = 1
		while startPoint <= n:
			res = res * startPoint
			startPoint += 1
		return res

	# 累计故障组数据
	def LLF_g(self, args, groupDataFormat):
		N = args[0]
		b = args[1]
		partA = 0
		partB = 0
		partC = 0
		old_t = 0
		old_n = 0
		for dataEle in groupDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]

			partA_1 = N - old_n
			partA_2 = n_i - old_n
			partA_3 = N - n_i
			if partA_1 < 0 or partA_2 < 0 or partA_3 < 0 :
				raise
			if partA_1 > partA_3:
				tempPartA = self.factorial(partA_1, partA_3) - 1
				if partA_2 < partA_3:
					tempPart = self.factorial(partA_2) * (self.factorial(partA_3,partA_2) * tempPartA - 1)
				elif partA_3 < partA_2:
					tempPart = self.factorial(partA_3) * (tempPartA  - self.factorial(partA_2,partA_3))
				else:
					tempPart = tempPartA - 1
			elif partA_1 == partA_3:
				tempPart = - self.factorial(partA_2)
			else:
				raise
			
			try:
				partA += math.log(tempPart)
			except Exception as e:
				print()
				print("N : " + str(N))
				print("b : " + str(b))
				print()
				print("partA_1 : " + str(partA_1))
				print("partA_2 : " + str(partA_2))
				print("partA_3 : " + str(partA_3))
				print("tempPart : " + str(tempPart))
				print()
				raise e
			
			
			#partA += math.log(tempPart)
			intervalT = t_i - old_t
			partB += b * intervalT * partA_3
			partC += partA_2 * math.log( 1 - math.exp( - b * intervalT ) )

			old_t = t_i
			old_n = n_i

		res = partA - partB - partC
		return res


# t_i : software fault count group data
# n_i : cumulative number of software faults
class M_GS(baseModel.highPrecisionCalc):

	def __init__(self,):
		pass
		
	def meanValueFunction(self, t, args):
		b = args[0]
		k = args[1]

		maxPower = 20
		res = 0
		j = 2
		while j <= maxPower:
			partA = 1
			l = 1
			while l <= j - 1:
				partA = partA * ( ( (b * t) * ( 1 - (k ** l) ) ) / l )
				l += 1
			partA = partA * ( (b * t) / j )

			res += ( (-1) ** (j - 1) ) * partA
			j += 1
		res += b * t
		return res

	# 累计故障组数据
	def LLF_g(self, args, groupDataFormat):
		b = args[0]
		k = args[1]

		res = 0
		old_n = 0
		old_t = 0

		for dataEle in groupDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]

			j = 0
			tempRes = 0
			intervalN = n_i - old_n
			while j <= intervalN:
				xList = []
				l = 1
				while l <= j:
					xList.append( 1 / ( (k ** l) - 1 ) )
					l += 1
				l = 1
				while l <= intervalN - j:
					xList.append( ( k ** (l-1) ) / ( (k ** l) - 1 ) )
					l += 1

				power = - b * ( t_i - old_t ) * ( k ** (old_n + j) )
				#print("start highPowerRes()")
				#print("power : " + str(power))
				#print("xList : ")
				#print(str(xList))
				tempRes += self.highPowerRes(power,xList) * ( (-1) ** j )
				#print("end highPowerRes()")
				#print()
				#print()
				j += 1
			try:
				# 疑问
				res += math.log(tempRes)
				# 也许应该是
				# res += math.log(abs(tempRes))*self.sign(tempRes)
			except Exception as e:
				print("error")
				print("tempRes : " + str(tempRes))
				raise e
			old_n = n_i
			old_t = t_i

		return res

# modelNames = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
class ClassicTypeI(baseModel.NHPPbasedSRM):

	modelNamesTypeI = None
	inverseModelNames = None
	normalEndTime = -1
	normalDataLen = -1

	#baseModel = None

	def __init__(self, prec = 1000):
		super().__init__(prec)
		setcontext(ExtendedContext)
		getcontext().prec = prec
		self.modelNamesTypeI = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin","Gtlogist","Plaw","Log","DSshaped","ISshaped"]
		self.inverseModelNames = ["Exp","Pareto","LogLogist"]
		self.inverseModelNames_highACC = ["Exp",]
		self.inverseFunctionDict = {
			"Exp": self.ExpInverse,
			"Pareto" : self.ParetoInverse,
			"LogLogist" : self.LogLogistInverse
		}
		self.inverseFunctionDict_highACC = {
			"Exp": self.ExpInverse_highACC,
		}

	def initPara(self, modelName):
		if modelName in self.modelNamesTypeI:
			return [100, *self.baseInitPara(modelName)]
		else:
			return [100,1,1]

	def bounds(self, modelName):
		zeroNear = 1e-15
		if modelName in self.modelNamesTypeI:
			return [[zeroNear,None],*self.baseBounds(modelName)]
		else:
			return [[None,None],[None,None],[None,None],]

	def normalizeSetting(self, normalEndTime, normalDataLen):
		self.normalEndTime = normalEndTime
		self.normalDataLen = normalDataLen

	def meanValueFunctionTypeI(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseCumDistFun(modelName)
		def newMean(t, args):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t, tArgs)
			try:
				finValue = Decimal(a) * meanValue
			except Exception as e:
				print("meanValueFun : " + str(meanValueFun))
				print("a : " + str(a))
				raise e
			return finValue
		return newMean


	def intensityFunctionTypeI(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		intensityFun = self.baseInteDistFun(modelName)
		def newIntensity(t, args):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			intensityValue = intensityFun(t, tArgs)
			return Decimal(a) * intensityValue
		return newIntensity

	def meanValueFunctionTypeI_normalized(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseCumDistFun(modelName)
		def newMean(t, args, endTime=self.normalEndTime, dataLen=self.normalDataLen):
			t = t / endTime
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t, tArgs)
			return Decimal(a) * meanValue * dataLen
		return newMean

	def intensityFunctionTypeI_normalized(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		intensityFun = self.baseInteDistFun(modelName)
		def newIntensity(t, args, endTime=self.normalEndTime, dataLen=self.normalDataLen):
			t = t / endTime
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			intensityValue = intensityFun(t, tArgs)
			return Decimal(a) * intensityValue * dataLen / endTime
		return newIntensity


	def meanValueFunctionTypeI_float(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseCumDistFun_float(modelName)
		def newMean(t, args):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t, tArgs)
			return a * meanValue
		return newMean


	def intensityFunctionTypeI_float(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		intensityFun = self.baseInteDistFun_float(modelName)
		def newIntensity(t, args):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			intensityValue = intensityFun(t, tArgs)
			return a * intensityValue
		return newIntensity

	def meanValueFunctionTypeI_float_normalized(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseCumDistFun_float(modelName)
		def newMean(t, args, endTime=self.normalEndTime, dataLen=self.normalDataLen):
			t = t / endTime
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t, tArgs)
			return a * meanValue * dataLen
		return newMean

	def intensityFunctionTypeI_float_normalized(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		intensityFun = self.baseInteDistFun_float(modelName)
		def newIntensity(t, args, endTime=self.normalEndTime, dataLen=self.normalDataLen):
			t = t / endTime
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			intensityValue = intensityFun(t, tArgs)
			return a * intensityValue * dataLen / endTime
		return newIntensity

	# 新版本名称。推荐使用
	def inverseMeanValueFunctionTypeI_float(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseInverseCumDistFun_float(modelName)
		def newInverseMean(t, args):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t/a, tArgs)
			return meanValue
		return newInverseMean

	def inverseMeanValueFunctionTypeI_float_normalized(self, modelName):
		if modelName not in self.modelNamesTypeI:
			return None
		meanValueFun = self.baseInverseCumDistFun_float(modelName)
		def newInverseMean(t, args, endTime=self.normalEndTime, dataLen=self.normalDataLen):
			a = args[0]
			tArgs = []
			i = 1
			while i < len(args):
				tArgs.append(args[i])
				i += 1
			meanValue = meanValueFun(t/(a*dataLen), tArgs)*endTime
			return meanValue
		return newInverseMean

	# 旧版本名称。出于兼容性目的保留
	def inverseDistFun(self, modelName):
		if modelName in self.inverseModelNames:
			return self.inverseFunctionDict[modelName]	
		else:
			return None

	def inverseDistFun_highACC(self, modelName):
		if modelName in self.inverseModelNames_highACC:
			return self.inverseFunctionDict_highACC[modelName]	
		else:
			return None

	def ExpInverse(self, y, args):
		a = longdouble(args[0])
		b = longdouble(args[1])
		y = longdouble(y)
		if a-y<=0:
			print("ExpInverse Error")
			print("a:"+str(a))
			print("y:"+str(y))
			print("res:"+str(emath.log(a/(a-y))/b))
			exit()
		return emath.log(a/(a-y))/b

	def ExpInverse_highACC(self, y, args):
		a = Decimal(args[0])
		b = Decimal(args[1])
		y = Decimal(y)
		if a-y<=0:
			print("ExpInverse_highACC Error")
			print("a:"+str(a))
			print("y:"+str(y))
			print("res:"+str(emath.log(a/(a-y))/b))
			exit()
		partA = a/(a-y)
		try:
			lnPart = partA.ln()
		except Exception as e:
			print(float(a))
			print(float(y))
			print(float(a-y))
			
			print(double(a))
			print(double(y))
			print(double(a-y))
			
			raise e
		return lnPart/b
		

	def ParetoInverse(self, y, args):
		a = args[0]
		b = args[1]
		c = args[2]
		if a-y<=0:
			print("ParetoInverse Error")
			print("a:"+str(a))
			print("y:"+str(y))
			print("res:"+str(emath.log(a/(a-y))/b))
			exit()
		fracPart = (a-y)/a
		return -c*((fracPart**(1/b))-1)*(fracPart**(-1/b))

	def LogLogistInverse(self, y, args):
		a = args[0]
		b = args[1]
		c = args[2]
		if a-y<=0:
			print("LogLogistInverse Error")
			print("a:"+str(a))
			print("y:"+str(y))
			print("res:"+str(emath.log(a/(a-y))/b))
			exit()
		return math.exp(c-b*emath.log((a-y)/y))


	def NHPPwithSum_timeScale_highACC( self ,meanValueFun, args ,totalSum, modelName = ""):
		if modelName not in self.inverseModelNames:
			return super(ClassicTypeI, self).NHPPwithSum_timeScale(meanValueFun, args ,totalSum)  
		else:
			resList = []
			totalE = Decimal(0)
			i = 0
			while i < totalSum:
				now = self.getU()
				totalE += Decimal(-1)*Decimal(now).ln()
				if totalE >= args[0]:
					return resList
				#SimulationData = inversefunc(meanValueFun, y_values=totalE)
				#print("yes inverse")
				SimulationData =  float(self.inverseDistFun_highACC(modelName)(totalE,args))
				#self.getInverse(meanValueFun, args, totalE, SimulationData)
				resList.append(SimulationData)
				i += 1
			return resList

	def NHPPwithSum_timeScale( self ,meanValueFun, args ,totalSum, modelName = ""):
		if modelName not in self.inverseModelNames:
			return super(ClassicTypeI, self).NHPPwithSum_timeScale(meanValueFun, args ,totalSum)  
		else:
			resList = []
			totalE = 0
			i = 0
			SimulationData = 0
			while i < totalSum:
				now = self.getU()
				totalE += (-1)*emath.log(now)
				if totalE >= args[0]:
					return resList
				#SimulationData = inversefunc(meanValueFun, y_values=totalE)
				#print("yes inverse")
				SimulationData =  self.inverseDistFun(modelName)(totalE,args)
				#self.getInverse(meanValueFun, args, totalE, SimulationData)
				resList.append(SimulationData)
				i += 1
			return resList

	def NHPPwithTime_timeScale(self, meanValueFun, args, endTime, modelName = ""):
		if modelName not in self.inverseModelNames:
			return super(ClassicTypeI, self).NHPPwithTime_timeScale(meanValueFun, args ,endTime)  
		else:
			resList = []
			totalE = 0
			SimulationData = 0
			while SimulationData <= endTime:
				now = self.getU()
				totalE += (-1)*emath.log(now)
				if totalE >= args[0]:
					return resList
				#SimulationData = inversefunc(meanValueFun, y_values=totalE)
				#print(SimulationData)
				SimulationData =  self.inverseDistFun(modelName)(totalE,args)
				#SimulationData = self.getInverse(meanValueFun, args, totalE, SimulationData + 10)
				#print(SimulationData)
				#if SimulationData == 0.0:
				#	exit()
				resList.append(SimulationData)
			del resList[-1]
			return resList


# modelNames = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
class ClassicTypeII(baseModel.NHPPbasedSRM):

	modelNamesTypeII = None

	def __init__(self, prec = 1000):
		super().__init__(prec)
		setcontext(ExtendedContext)
		getcontext().prec = prec
		self.modelNamesTypeII = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]

	# 通用型平均值函数
	def meanValueFunctionTypeII(self, modelName):
		if modelName not in self.modelNamesTypeII:
			return None
		meanValueFun = self.baseCumDistFun(modelName)
		def newMean(t, args):
			meanValue = meanValueFun(t, args)
			#res = - math.log(1 - meanValue)
			res = -Decimal(Decimal(1) - meanValue).ln()
			return res
		return newMean

	# 通用型强度函数
	def intensityFunctionTypeII(self, modelName):
		if modelName not in self.modelNamesTypeII:
			return None
		meanValueFun = self.baseCumDistFun(modelName)
		intensityFun = self.baseInteDistFun(modelName)
		def newIntensity(t, args):
			intensityValue = intensityFun(t, args)
			meanValue = meanValueFun(t, args)
			#res = intensityValue / (1 - meanValue)
			res = intensityValue / (Decimal(1) - meanValue)
			return res
		return newIntensity





#t = 2
#a = 1
#b = 3
#c = 4



"""
modelName = "LogLogist"
# 创建typeII实例
models = ClassicTypeII()

# 平均值函数与强度函数
meanValueFunction = models.meanValueFunctionTypeII(modelName)
intensityFunction = models.intensityFunctionTypeII(modelName)
res = float(meanValueFunction(t,[b,c]))
print("TypeII "+modelName + "平均值函数 : "+ str(res))
res = float(intensityFunction(t,[b,c]))
print("TypeII "+modelName + "强度函数 : "+ str(res))
"""

"""
modelNames = ["Exp","Pareto","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
modelNames = ["Gamma","TruncNormal","LogNormal"]
for modelName in modelNames:
	# 创建typeII实例
	models = ClassicTypeI()
	# 平均值函数与强度函数
	meanValueFunction = models.meanValueFunctionTypeI(modelName)
	#intensityFunction = models.intensityFunctionTypeI(modelName)
	res = float(meanValueFunction(t,[a,b,c]))
	print(modelName + "平均值函数 : "+ str(res))
	#res = float(intensityFunction(t,[a,b,c]))
	#print(modelName + "强度函数 : "+ str(res))

for modelName in modelNames:
	# 创建typeII实例
	models = ClassicTypeI()
	# 平均值函数与强度函数
	#meanValueFunction = models.meanValueFunctionTypeI(modelName)
	intensityFunction = models.intensityFunctionTypeI(modelName)
	#res = float(meanValueFunction(t,[a,b,c]))
	#print(modelName + "平均值函数 : "+ str(res))
	res = float(intensityFunction(t,[a,b,c]))
	print(modelName + "强度函数 : "+ str(res))
"""

"""
basePath = "/Users/hello/GoogleDrive/学术相关/既存参数化模型/spark/NHPP_type2"
trainDataInterval = 1.0
dataSet = "DS1"
dataType = "timeData"
import SRMtoolv04 as SRMtool
dataList = SRMtool.readXlsxData(basePath+"/"+dataType+"/"+dataSet+".xlsx")
dataList, testData = SRMtool.cutPercentageData(dataList, trainDataInterval)
# 组装验证集
testDataFormated = []
# 组装成时间数据的格式
timeDataFormat = []
n_i = 1
for t_i in dataList:
	timeDataFormat.append([t_i,n_i])
	n_i += 1
for t_i in testData:
	testDataFormated.append([t_i,n_i])
	n_i += 1
# 创建typeII实例
models = ClassicTypeII()
# 平均值函数与强度函数
meanValueFunction = models.meanValueFunctionTypeII("Exp")
intensityFunction = models.intensityFunctionTypeII("Exp")
# 对数似然函数
logLikelihoodFun = models.LLF_t
llf = logLikelihoodFun([0.00049688], timeDataFormat,meanValueFunction,intensityFunction)
print("llf : "+str(llf))
"""


"""
# debug start
a = 200
t = 100
b = 1
c = 10
prec = 1000
args = [b,c]
models = ClassicTypeII(prec)
modelNames = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
#modelNames = ["Gamma",]
print("MeanValue : ")
for modelName in modelNames:
	try:
		MeanValueFun = models.meanValueFunctionTypeII(modelName)
		estValue = MeanValueFun(t,args)
		print(modelName+" : "+str(round(estValue,4)))
	except Exception as e:
		import traceback
		traceback.print_exc()
		print(e)
		print(modelName+" : 超过精度无法计算")


print("\n\nintensityValue : ")
for modelName in modelNames:
	try:
		intensityFun = models.intensityFunctionTypeII(modelName)
		estValue = intensityFun(t,args)
		print(modelName+" : "+str(round(estValue,4)))
	except Exception as e:
		print(modelName+" : 超过精度无法计算")

# debug end
"""

class LindleyTypeI(baseModel.LindleyDist,ClassicTypeI):

	def __init__(self,):
		pass

class LindleyTypeII(baseModel.LindleyDist,ClassicTypeII):

	def __init__(self,):
		pass

class BurrTypeI(baseModel.BurrDist, ClassicTypeI):

	def __init__(self,):
		pass

class BurrTypeII(baseModel.BurrDist, ClassicTypeII):

	def __init__(self,):
		pass

class Polynomial():

	def __init__(self,):
		pass

class PI():

	def __init__(self,):
		pass

class GBP():

	def __init__(self,):
		pass


class GPP():

	def __init__(self,):
		pass

"""
b = 11.1234567
b = -b
xPower = 10
xEle = 1e-1
print("\n例1")
print("待计算表达式 : e^"+str(b)+" x ("+str(xEle)+")^"+str(xPower)+" = ?")

xList = []
i = 0
xTotal = 1
while i < xPower:
	xList.append(xEle)
	xTotal = xTotal * xEle
	i += 1

try:
	res1 = math.exp( b ) * xTotal
	print("直接运算结果 : " + str(res1))
except Exception as e:
	print("直接运算结果 : 超越python计算精度，无法计算。")

res2 = highPowerRes(b,xList)
print("高精计算结果 : " + str(res2))

b = 1000.7890123
b = b
xPower = 120
xEle = 1e-4
print("\n例2")
print("待计算表达式 : e^"+str(b)+" x ("+str(xEle)+")^"+str(xPower)+" = ?")

xList = []
i = 0
xTotal = 1
while i < xPower:
	xList.append(xEle)
	xTotal = xTotal * xEle
	i += 1

try:
	res1 = math.exp( b ) * xTotal
	print("直接运算结果 : " + str(res1))
except Exception as e:
	print("直接运算结果 : 超越python计算精度，无法计算。")

res2 = highPowerRes(b,xList)
print("高精计算结果 : " + str(res2)+"")


b = 10
c = 0.2
d = 10
print("\n例3")
print("待计算表达式 : e^"+str(b)+"*"+str(c)+"^"+str(d) +" = ?")

try:
	res1 = math.exp( b ) * (c ** d)
	print("直接运算结果 : " + str(res1))
except Exception as e:
	print("直接运算结果 : 超越python计算精度，无法计算。")

res2 = highPowerRes2(b,c,d)
print("高精计算结果 : " + str(res2)+"")

b = 1470
c = 0.23
d = 1000
print("\n例4")
print("待计算表达式 : e^"+str(b)+"*"+str(c)+"^"+str(d) +" = ?")

try:
	res1 = math.exp( b ) * (c ** d)
	print("直接运算结果 : " + str(res1))
except Exception as e:
	print("直接运算结果 : 超越python计算精度，无法计算。")

res2 = highPowerRes2(b,c,d)
print("高精计算结果 : " + str(res2)+"\n\n")
"""


"""
nMax = 5
n = 0
a = JM()
while n <= nMax:
	s = 0
	while s <= n:
		print("n = "+str(n)+ " s = "+str(s))
		res = a.factorial(n,s)
		print(res)
		print()
		s += 1
	n += 1

"""








