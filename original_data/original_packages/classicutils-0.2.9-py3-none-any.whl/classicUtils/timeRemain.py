# Version 1.1
# 新增仅计算长时间任务功能。setOnlyLongTask()
# 可以在大多数时候更准确的估计剩余时间
#
# Version 1.0 
# 完成剩余时间估计功能
# Auther WJC

import time

class clock:
	startTime = 0
	name = ''

	def __init__(self,name = ''):
		self.startTime = time.time()
		self.name = name

	def start(self):
		self.startTime = time.time()
		return self.startTime

	def end(self):
		endTime = time.time()
		m, s = divmod(endTime-self.startTime, 60)
		h, m = divmod(m, 60)
		print(str(self.name)+" : %d:%02d:%02d" % (h, m, s))
		return endTime-self.startTime

	def timeInterval(self, time):
		m, s = divmod(time, 60)
		h, m = divmod(m, 60)
		print(str(self.name)+" : %d:%02d:%02d" % (h, m, s))

class timer:
	startTime = 0
	totalTask = 0
	ifAlways = True
	per = 5
	old_per = 0
	onlyLongTask = False
	LongTaskSec = 3
	lightTask = 0
	nowTask = 0
	startT = 0
	firstAnnounce = True

	# 是否每次计算都汇报剩余进度。默认True. 若希望每间隔per%进度汇报一次，则设置此项.
	def __init__(self, totalTask, ifAlways = False, per = 5):
		self.startTime = time.perf_counter()
		self.startT = time.time()
		self.totalTask = totalTask
		self.ifAlways = ifAlways
		self.per = per
		self.old_per = 0
		self.onlyLongTask = False
		self.lightTask = 0
		self.nowTask = 0
		self.firstAnnounce = True

	def printTimeRemain(self, nowTask):
		per = nowTask / self.totalTask
		interval = time.perf_counter() - self.startTime
		# 计算真实比例
		realPer = per
		if self.onlyLongTask :
			realNowTask = nowTask - self.lightTask
			realTotalTask = self.totalTask - self.lightTask
			realPer = realNowTask / realTotalTask
		if interval <= self.LongTaskSec:
			self.lightTask += 1
		#(interval/realPer)*(1-realPer) = x
		#interval = (interval/realPer)-interval
		interval = (interval/realPer)*(1-realPer)
		m , s = divmod(interval,60)
		h , m = divmod(m,60)
		if self.ifAlways == False :
			if per*100 - self.old_per*100 >= self.per  or nowTask == self.totalTask:
				self.old_per = per
				firstAnnounce = False
			elif per*100 > 1 and self.firstAnnounce:
				self.firstAnnounce = False
			else : 
				return 
		endTime = time.time()
		m_1, s_1 = divmod(endTime-self.startT, 60)
		h_1, m_1 = divmod(m_1, 60)
		print("当前进度: " +str(round(int(per*1000)/10,3)) + "% 已耗时: "+str(int(h_1)) +"h "+str(int(m_1))+"m "+str(int(s_1))+"s"+" 剩余时间: " +str(int(h)) +"h "+str(int(m))+"m "+str(int(s))+"s")

	def show(self):
		self.nowTask = self.nowTask + 1
		self.printTimeRemain(self.nowTask)
		
	def setPrintInterval(self,ifAlways = True, per = 5):
		self.ifAlways = ifAlways
		self.per = per

	def setOnlyLongTask(self, onlyLongTask = True, LongTaskSec = 3):
		self.onlyLongTask = onlyLongTask
		self.LongTaskSec = LongTaskSec