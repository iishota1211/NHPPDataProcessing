


def create(msg, filePath):
	# 指定文件名
	filename = filePath + "readme.txt"

	# 使用 'w' 模式打开文件，'w' 表示写入模式，如果文件不存在则创建文件
	with open(filename, 'w') as file:
	    # 写入内容到文件
	    file.write(msg)
















