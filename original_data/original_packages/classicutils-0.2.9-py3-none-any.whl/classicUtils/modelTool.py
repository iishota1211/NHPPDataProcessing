from classicUtils import existSRM

# 将 modelDict 转换成对应的平均值函数
def meanValueFunction(modelDict):
	modelType = modelDict["modelType"]
	modelName = modelDict["modelName"]
	meanValueFun = None
	meanValueFun_backup = None
	if modelType == "typeI":
		models = existSRM.ClassicTypeI()
		meanValueFun = models.meanValueFunctionTypeI_float(modelName)
		meanValueFun_backup = models.meanValueFunctionTypeI(modelName)
	else:
		raise
	return [meanValueFun, meanValueFun_backup]

# 将 modelDict 转换成对应的强度函数
def intensityFunction(modelDict):
	modelType = modelDict["modelType"]
	modelName = modelDict["modelName"]
	intensityFun = None
	intensityFun_backup = None
	if modelType == "typeI":
		models = existSRM.ClassicTypeI()
		intensityFun = models.intensityFunctionTypeI_float(modelName)
		intensityFun_backup = models.intensityFunctionTypeI(modelName)
	else:
		raise
	return [intensityFun, intensityFun_backup]

# 将 modelDict 转换成对应的似然函数
def logLikelihoodFunction(modelDict, dataType):
	modelType = modelDict["modelType"]
	likelihoodFun = None
	likelihoodFun_backup = None
	if modelType == "typeI":
		models = existSRM.ClassicTypeI()
		if dataType == "time":
			likelihoodFun = models.LLF_t_float
			likelihoodFun_backup = models.LLF_t
		if dataType == "group":
			likelihoodFun = models.LLF_g_float
			likelihoodFun_backup = models.LLF_g
	else:
		raise
	return likelihoodFun, likelihoodFun_backup

# 将 modelDict 转换成对应的似然函数
def parameterBounds(modelDict):
	modelType = modelDict["modelType"]
	modelName = modelDict["modelName"]
	parameterBounds = None
	if modelType == "typeI":
		parameterBounds = existSRM.ClassicTypeI().bounds(modelName)
	else:
		raise
	return parameterBounds

# 获取 modelDict 推荐的初始参数
def initPara(modelDict):
	modelType = modelDict["modelType"]
	modelName = modelDict["modelName"]
	initParaList = None
	if modelType == "typeI":
		initParaList = existSRM.ClassicTypeI().initPara(modelName)
	else:
		raise
	return initParaList

# 获取支持的模型名称
def supportModelNameList():
	return existSRM.ClassicTypeI().modelNamesTypeI
