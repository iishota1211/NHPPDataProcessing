import copy, redis, pickle, hashlib, time, random
from classicUtils import global_variables, SRMtool
from tqdm import tqdm

# 计算各个模型在不同数据集上的预测值
def main(estimateDict, dictUniName, debugServerInfoDict, sparkFun = None, redisConfDict = None):
	# 二周目返还spark计算结果
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			redisHost = redisConfDict["host"] # "10.30.87.10"
			redisPassword = redisConfDict["password"] # "wJc@2410"
			redisPort = redisConfDict["port"] # 6379
			if "databaseNum" in redisConfDict:
				redisDbNum = redisConfDict["databaseNum"] # 0
			else:
				redisDbNum = 0
			if global_variables.sparkTaskCounter != -1 :
				client = redis.Redis(
					host=redisHost,
					port=redisPort,
					db=redisDbNum,
					password=redisPassword,
					decode_responses=False
				)
		bar = tqdm(len(global_variables.sparkTaskList))
	resDict = copy.deepcopy(estimateDict)
	for dataType in estimateDict:
		for predInterval in estimateDict[dataType]:
			if predInterval >= 1.0:
				continue
			for dataName in estimateDict[dataType][predInterval]:
				# 当前训练数据的字典
				singleEstDict 			= estimateDict[dataType][predInterval][dataName]
				# 当前训练数据
				culFormatedTrainData 	= singleEstDict["culFormatedTrainData"]
				# 当前验证数据
				culFormatedTestData 	= singleEstDict["culFormatedTestData"]
				# 额外的数据参数
				if "optionPara" in singleEstDict:
					optionPara = singleEstDict["optionPara"]
				else:
					optionPara = None
				# 不同推参方法
				for methodName in singleEstDict[dictUniName]:
					for modelType in singleEstDict[dictUniName][methodName]:
						for modelName in singleEstDict[dictUniName][methodName][modelType]:
							estResDict = singleEstDict[dictUniName][methodName][modelType][modelName]
							paraList = estResDict["paraList"]
							methodDict = estResDict["methodDict"]
							# 一周目收集spark任务
							if global_variables.sparkTaskCounter == -1 :
								sparkTaskDict = dict()
								sparkTaskDict["culFormatedTrainData"] = culFormatedTrainData
								sparkTaskDict["culFormatedTestData"] = culFormatedTestData
								sparkTaskDict["paraList"] = paraList
								sparkTaskDict["modelType"] = modelType
								sparkTaskDict["modelName"] = modelName
								sparkTaskDict["dataType"] = dataType
								sparkTaskDict["dataName"] = dataName
								sparkTaskDict["optionPara"] = optionPara
								sparkTaskDict["methodDict"] = methodDict
								sparkTaskDict["predInterval"] = predInterval
								if "measureNameList" in estResDict:
									sparkTaskDict["measureNameList"] = estResDict["measureNameList"]
								if "measureValueDict" in estResDict:
									sparkTaskDict["measureValueDict"] = estResDict["measureValueDict"]
								if "aliasName" in estResDict:
									sparkTaskDict["aliasName"] = estResDict["aliasName"]
								sparkTaskDict["debugServerInfoDict"] = debugServerInfoDict
								#sparkTaskDict["otherPredDict"] = singleEstDict
								global_variables.sparkTaskList.append([sparkTaskDict,sparkFun,redisConfDict])
							# 二周目返还spark计算结果
							if global_variables.sparkTaskCounter != -1 :
								# 回收结果
								sparkResDict = global_variables.sparkTaskList[global_variables.sparkTaskCounter]
								# 从redis中还原结果
								if redisConfDict is not None:
									hashName = sparkResDict
									exeFlag = False
									for sleepTime in range(3):
										try:
											sparkResDump = client.get(hashName)
										except Exception as e:
											time.sleep(5 + sleepTime*10)
										else:
											exeFlag = True
											break
									if exeFlag == False:
										raise
									sparkResDict = pickle.loads(sparkResDump)

								# 整理结果
								global_variables.sparkTaskCounter += 1
								
								tempResDict = copy.deepcopy(estResDict)
								tempResDict["culPMAE"] = sparkResDict["culPMAE"]
								tempResDict["nonCulPMAE"] = sparkResDict["nonCulPMAE"]
								if "culRMSE" in sparkResDict:
									tempResDict["culRMSE"] = sparkResDict["culRMSE"]
								if "nonCulRMSE" in sparkResDict:
									tempResDict["nonCulRMSE"] = sparkResDict["nonCulRMSE"]
								tempResDict["culFormatedPredData"] = sparkResDict["culFormatedPredData"]
								if "measureNameList" in sparkResDict:
									if "measureNameList" not in tempResDict:
										tempResDict["measureNameList"] = list()
									for measureName in sparkResDict["measureNameList"]:
										if measureName not in tempResDict["measureNameList"]:
											tempResDict["measureNameList"].append(measureName)
								if "measureValueDict" in sparkResDict:
									if "measureValueDict" not in tempResDict:
										tempResDict["measureValueDict"] = dict()
									for measureName in sparkResDict["measureValueDict"]:
										tempResDict["measureValueDict"][measureName] = sparkResDict["measureValueDict"][measureName]
								if "aliasName" in sparkResDict:
									tempResDict["aliasName"] = sparkResDict["aliasName"]
								# 保存结果
								resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType][modelName] = tempResDict
								bar.update(1)
	# 二周目返还spark计算结果
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			client.flushdb()
			client.close()
		bar.close()
	return resDict

# 将spark的结果用redis暂存
def sparkFun_redis(args):
	sparkTaskDict = args[0]
	sparkFun = args[1]
	redisConfDict = args[2]
	redisHost = redisConfDict["host"] # "10.30.87.10"
	redisPassword = redisConfDict["password"] # "wJc@2410"
	redisPort = redisConfDict["port"] # 6379
	if "databaseNum" in redisConfDict:
		redisDbNum = redisConfDict["databaseNum"] # 0
	else:
		redisDbNum = 0
	exeFlag = False
	sparkResDict = sparkFun(sparkTaskDict)
	for sleepTime in range(5):
		try:
			client = redis.Redis(
				host=redisHost,
				port=redisPort,
				db=redisDbNum,
				password=redisPassword,
				decode_responses=False
			)
			

			dumpsDict = pickle.dumps(sparkResDict, protocol=pickle.HIGHEST_PROTOCOL)
			hashName = str(hashlib.sha256(dumpsDict).hexdigest())
			client.set(hashName, dumpsDict)
			client.close()
			exeFlag = True
		except Exception as e:
			randomA = random.randint(5, 20)
			randomB = random.randint(10, 20)
			time.sleep(randomA + sleepTime*randomB)
		else:
			break
	if exeFlag == True:
		return hashName
	else:
		raise

def startSpark(sc, sparkFun, redisConfDict,threshold = 30000):
	# spark计算
	
	print("generalPredSpark 任务数量 : "+str(len(global_variables.sparkTaskList)))
	sparkTaskList_total = SRMtool.split_list(global_variables.sparkTaskList, threshold)
	resTaskList_total = []
	index = 1
	for sparkTaskList in sparkTaskList_total:
		print("spark任务 第",index,"批数量 : ",len(sparkTaskList))
		paraRDD = sc.parallelize(sparkTaskList)
		#predictionRDD = paraRDD.map(lambda sparkTaskDict: sparkFun(sparkTaskDict))
		predictionRDD = paraRDD.map(lambda args: sparkFun_redis(args))
		tempResList = predictionRDD.collect()
		resTaskList_total.append(tempResList)
		index += 1
	global_variables.sparkTaskList = SRMtool.rebuild_list(resTaskList_total)
	global_variables.sparkTaskCounter = 0

def exec(estimateDict, dictUniName, sparkFun, sc, debugServerInfoDict = None, redisConfDict=None,threshold = 30000):
	# 测试redis连接
	if redisConfDict is not None:
		redisHost = redisConfDict["host"] # "10.30.87.10"
		redisPassword = redisConfDict["password"] # "wJc@2410"
		redisPort = redisConfDict["port"] # 6379
		if "databaseNum" in redisConfDict:
			redisDbNum = redisConfDict["databaseNum"] # 0
		else:
			redisDbNum = 0
		client = redis.Redis(
			host=redisHost,
			port=redisPort,
			db=redisDbNum,
			password=redisPassword,
			decode_responses=False
		)
		client.set("hello", "world"+str(redisDbNum))
		value = client.get("hello")
		print("Redis Test Results : ", value)
		client.close()
	else:
		print("No Redis Conf (Pred)")
	# 布置Spark任务
	global_variables.sparkTaskList = []
	global_variables.sparkTaskCounter = -1
	# 收集Spark任务（主逻辑）
	main(estimateDict, dictUniName, debugServerInfoDict,sparkFun, redisConfDict)
	if len(global_variables.sparkTaskList) == 0:
		return estimateDict
	# 提交Spark计算处理
	try:
		startSpark(sc, sparkFun, redisConfDict,threshold)
	except Exception as e:
		raise e
	# 再次执行并返还Spark计算结果 （再次调用主逻辑）
	try:
		resDict = main(estimateDict, dictUniName, debugServerInfoDict,sparkFun,redisConfDict)
	except Exception as e:
		raise e
	return resDict