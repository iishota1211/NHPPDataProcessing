# v0.2
# 可以捕获更多低精度疑似越界的情况

# v0.1 
# 第一版 TypeI-NHPP 似然函数实现
# 包含算数平均，几何平均，调和平均
# 在float精度的基础上做了高精度优化（float疑似越界时会用高精度重算一遍)

from classicUtils import SRMtool, existSRM, RSRAT, measure, modelTool
import copy, math, traceback
from decimal import *

# 自制强度函数 (算数平均)
def intensityFun_ari(time, modelDictList):
	intensityValueList = []
	finValue = -1
	if modelDictList == []:
		return finValue
	zeroFlag = False
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		#weight = modelDict["weight"]
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		#intensityValue = intensityFun_backup(time, paraList)
		intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0:
			zeroFlag = True
			intensityValue = intensityFun_backup(time, paraList)
		intensityValueList.append(intensityValue)
	#finValue = Decimal(0)
	if zeroFlag == False:
		finValue = 0
		for intensityValue in intensityValueList:
			finValue = finValue + intensityValue
	elif zeroFlag == True:
		finValue = Decimal(0)
		for intensityValue in intensityValueList:
			finValue = finValue + Decimal(intensityValue)
	return float(finValue)

# 自制对数强度函数 (算数平均)
def logIntensityFun_ari(time, modelDictList):
	intensityValueList = []
	finValue = -1
	if modelDictList == []:
		return finValue
	zeroFlag = False
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		#weight = modelDict["weight"]
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		#intensityValue = intensityFun_backup(time, paraList)
		if zeroFlag == False:
			intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0 or intensityValue == float("inf") or intensityValue == float("-inf"):
			zeroFlag = True
		if zeroFlag == True:
			intensityValue = intensityFun_backup(time, paraList)
			"""
			# 使用局部上下文修改精度
			with localcontext() as ctx:
				# 清除flags
				ctx.clear_flags()
				maxPrec = 19000
				nowPrec = 1000
				while nowPrec <= maxPrec:
					ctx.prec = nowPrec
					intensityValue = intensityFun_backup(time, paraList)
					# 检查是否有未精确标志
					if ctx.flags[Inexact]:
						if nowPrec >= 4000:
							break
						else:
							nowPrec += 3000
					elif ctx.flags[Rounded]:
						nowPrec += 3000
						ctx.clear_flags()
					else:
						break
					print(intensityValue)
			"""
		intensityValueList.append(intensityValue)
	if zeroFlag == False:
		finValue = sum(intensityValueList)
		lnFinValue = math.log(finValue)
	elif zeroFlag == True or lnFinValue == float("inf") or lnFinValue == float("-inf"):
		finValue = Decimal(0)
		for intensityValue in intensityValueList:
			finValue = finValue + Decimal(intensityValue)
		lnFinValue = finValue.ln()
	#if float(lnFinValue) == float("inf") or float(lnFinValue) == float("-inf"):
	#	debugMsg = modelDict["modelName"]+"\nzeroFlag : "+str(zeroFlag) + "\n" + "finValue : " + str(finValue) + "\n" + "intensityValueList : " + str(intensityValueList) + "\n paraList : " + str(paraList)
	#	SRMtool.sendNoticeMail("debug", debugMsg)
	#	raise 
	return float(lnFinValue)


# 自制平均值函数 (算数平均)
def meanValueFun_ari(time, modelDictList):
	if time == 0.0 or time == 0:
		return 0.0
	meanValueList = []
	finValue = -1
	if modelDictList == []:
		return finValue
	zeroFlag = False
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		#weight = modelDict["weight"]
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		#meanValue = meanFun_backup(time, paraList)
		if zeroFlag == False:
			meanValue = mymeanFun(time, paraList)
		if meanValue == float("inf") or meanValue == float("-inf") or meanValue == 0.0:
			zeroFlag = True
		if zeroFlag == True:
			meanValue = meanFun_backup(time, paraList)

		meanValueList.append(meanValue)
	#finValue = Decimal(0)
	if zeroFlag == False:
		finValue = 0
		for meanValue in meanValueList:
			finValue = finValue + meanValue
	if zeroFlag == True:
		finValue = Decimal(0)
		for meanValue in meanValueList:
			finValue = finValue + Decimal(meanValue)
	return float(finValue)

# 自制对数似然函数(时间数据) (算数平均)
def logLikelihoodFun_time_ari(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i : i + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		newModelDictList.append(newModelDict)
		i = i + paraListLen
	lastTime = culFormatedTrainData[-1][0]
	lastEstNum = meanValueFun_ari(lastTime, newModelDictList)
	totalIntensity = 0
	oldNum = 0
	for time, num in culFormatedTrainData:
		if oldNum == num:
			break
		oldNum = num
		try:
			lnintensity = logIntensityFun_ari(time, newModelDictList)
		except Exception as e:
			SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n newModelDictList : "+str(newModelDictList)+"\n 错误详情:\n"+str(traceback.format_exc()))
			raise e
		totalIntensity = totalIntensity + lnintensity
		#if float(totalIntensity) == float("inf") or float(totalIntensity) == float("-inf"):
		#	debugMsg = "totalIntensity : "+str(totalIntensity) + "\n" + "lnintensity : " + str(lnintensity) + "\n" + "lastEstNum : " + str(lastEstNum)
		#	SRMtool.sendNoticeMail("debug", debugMsg)
		#	raise 
	finValue = totalIntensity - lastEstNum
	#if float(finValue) == float("inf") or float(finValue) == float("-inf"):
	#	debugMsg = "finValue : "+str(finValue) + "\n" + "totalIntensity : " + str(totalIntensity) + "\n" + "lastEstNum : " + str(lastEstNum)
	#	SRMtool.sendNoticeMail("debug", debugMsg)
	#	raise 
	return float(finValue)

# 自制负对数似然函数(时间数据) (算数平均)
def negaLogLikelihoodFun_time_ari(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_time_ari(paraList, culFormatedTrainData, modelDictList)

# 自制对数似然函数(组数据) (算数平均)
def logLikelihoodFun_group_ari(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i : i + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		#newModelDict["weight"] = paraList[i]
		newModelDictList.append(newModelDict)
		i = i + paraListLen

	old_t = 0
	old_n = 0
	old_meanValue = 0
	last_t = culFormatedTrainData[-1][0]
	res = - meanValueFun_ari(last_t, newModelDictList)
	zeroFlag = False
	for dataEle in culFormatedTrainData:
		t_i = dataEle[0]
		n_i = dataEle[1]
		meanValue = meanValueFun_ari(t_i, newModelDictList)
		intervalMeanValue = meanValue - old_meanValue
		# 防止越界
		if intervalMeanValue < 0:
			intervalMeanValue = 0.0

		intervalN = n_i - old_n
		old_meanValue = meanValue
		old_n = n_i

		try:
			tempRes = 1
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / i)
				i += 1
			if tempRes == 0.0:
				zeroFlag = True
				tempRes = Decimal(1)
				i = 1
				while i <= intervalN:
					tempRes = tempRes * (Decimal(intervalMeanValue) / Decimal(i))
					i += 1
				tempRes = tempRes.ln()
			else:
				tempRes = math.log(tempRes)
		except Exception as e:
			debugMsg = "tempRes : "+str(tempRes) + "\n" + "intervalMeanValue : " + str(intervalMeanValue) + "\n" + "intervalMeanValue / i : " + str(intervalMeanValue / i) + "\n tempRes : " + str(tempRes)
			SRMtool.sendNoticeMail("debug", debugMsg)
			raise e
		if zeroFlag == True:
			res = Decimal(res) + Decimal(tempRes)
		else:
			res = res + tempRes
	return float(res)


# 自制负对数似然函数(组数据) (算数平均)
def negaLogLikelihoodFun_group_ari(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_group_ari(paraList, culFormatedTrainData, modelDictList)



# 自制强度函数 (调和平均)
def intensityFun_har(time, modelDictList):
	if modelDictList == []:
		return -1
	intensityValueList = []
	meanValueReciList = []
	meanValuePowerList = []
	zeroFlag = False
	for modelDict in modelDictList:
		# 提取参数
		paraList = modelDict["paraList"]
		# 计算强度
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0:
			zeroFlag = True
			intensityValue = intensityFun_backup(time, paraList)
		intensityValueList.append(intensityValue)
		# 计算平均值
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		meanValue = mymeanFun(time, paraList)
		meanValueReciList.append(1/meanValue)
		meanValuePowerList.append(meanValue*meanValue)

	reciTotal = sum(meanValueReciList)
	partB = reciTotal * reciTotal

	if zeroFlag == False:
		partA = 0
		i = 0
		for intensityValue in intensityValueList:
			partA += intensityValue / meanValuePowerList[i]
			i += 1
		finValue = partA / partB
	elif zeroFlag == True:
		partA = Decimal(0)
		i = 0
		for intensityValue in intensityValueList:
			partA += Decimal(intensityValue) / Decimal(meanValuePowerList[i])
			i += 1
		finValue = partA / Decimal(partB)
	return float(finValue)

# 自制对数强度函数 (调和平均)
def logIntensityFun_har(time, modelDictList):
	if modelDictList == []:
		return -1
	intensityValueList = []
	meanValueReciList = []
	meanValuePowerList = []
	zeroFlag = False
	for modelDict in modelDictList:
		# 提取参数
		paraList = modelDict["paraList"]
		# 计算强度
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0:
			zeroFlag = True
			intensityValue = intensityFun_backup(time, paraList)
		intensityValueList.append(intensityValue)
		# 计算平均值
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		meanValue = mymeanFun(time, paraList)
		meanValueReciList.append(1/meanValue)
		meanValuePowerList.append(meanValue*meanValue)

	errorFlag = False
	try:
		reciTotal = sum(meanValueReciList)
		partB = reciTotal * reciTotal
	except Exception as e:
		errorFlag = True
		reciTotal = Decimal(0)
		for meanValueReci in meanValueReciList:
			reciTotal += Decimal(meanValueReci)
		partB = reciTotal * reciTotal

	if zeroFlag == False:
		partA = 0
		i = 0
		for intensityValue in intensityValueList:
			partA += intensityValue / meanValuePowerList[i]
			i += 1
		if errorFlag == False:
			try:
				finValue = partA / partB
				logValue = math.log(finValue)
			except Exception as e:
				errorFlag = True
		if errorFlag == True:
			finValue = Decimal(partA) / Decimal(partB)
			logValue = finValue.ln()
	elif zeroFlag == True:
		partA = Decimal(0)
		i = 0
		for intensityValue in intensityValueList:
			partA += Decimal(intensityValue) / Decimal(meanValuePowerList[i])
			i += 1
		finValue = partA / Decimal(partB)
		logValue = finValue.ln()
	return float(logValue)


# 自制平均值函数 (调和平均)
def meanValueFun_har(time, modelDictList):
	if time == 0.0 or time == 0:
		return 0.0
	meanValueList = []
	finValue = -1
	if modelDictList == []:
		return finValue

	zeroFlag = False
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		#weight = modelDict["weight"]
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		#meanValue = meanFun_backup(time, paraList)
		meanValue = mymeanFun(time, paraList)
		if meanValue == 0.0:
			zeroFlag = True
			meanValue = meanFun_backup(time, paraList)
		meanValueList.append(meanValue)

	if zeroFlag == False:
		finValue = 0
		for meanValue in meanValueList:
			finValue = finValue + (1/meanValue)
		res = 1 / finValue
		returnValue = res
	if zeroFlag == True or returnValue == 0.0:
		finValue = Decimal(0)
		logList = []
		for meanValue in meanValueList:
			value = Decimal(1)/Decimal(meanValue)
			finValue = finValue + value
			logList.append(round(float(value),2))
		res = Decimal(1) / finValue
		returnValue = float(res)
		#if returnValue == 0.0:
		#	SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n res : "+str(res)+"\n meanValueList : "+str(meanValueList)+"\n finValue : "+str(float(finValue))+"\n logList : "+str(logList))
		#	raise
	if returnValue <= 1e-15:
		returnValue = 1e-15
	return returnValue

# 自制平均值函数 (调和平均) 调试用
def meanValueFun_har_debug(time, modelDictList):
	if time == 0.0 or time == 0:
		return 0.0
	meanValueList = []
	nameList = []
	finValue = -1
	if modelDictList == []:
		return finValue

	zeroFlag = False
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		#weight = modelDict["weight"]
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		#meanValue = meanFun_backup(time, paraList)
		meanValue = mymeanFun(time, paraList)
		if meanValue == 0.0:
			zeroFlag = True
			meanValue = meanFun_backup(time, paraList)
		nameList.append(modelDict["modelName"])
		meanValueList.append(float(meanValue))

	deciList = []
	if zeroFlag == False:
		finValue = 0
		for meanValue in meanValueList:
			deciList.append(1/meanValue)
			finValue = finValue + (1/meanValue)
		res = 1 / finValue
		returnValue = res
	if zeroFlag == True or returnValue == 0.0:
		finValue = Decimal(0)
		logList = []
		for meanValue in meanValueList:
			value = Decimal(1)/Decimal(meanValue)
			deciList.append(float(value))
			finValue = finValue + value
			logList.append(round(float(value),2))
		res = Decimal(1) / finValue
		returnValue = float(res)
		#if returnValue == 0.0:
		#	SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n res : "+str(res)+"\n meanValueList : "+str(meanValueList)+"\n finValue : "+str(float(finValue))+"\n logList : "+str(logList))
		#	raise
	if returnValue <= 1e-15:
		returnValue = 1e-15
	return returnValue, float(res), float(finValue), deciList, meanValueList, nameList 

# 自制对数似然函数(时间数据) (调和平均)
def logLikelihoodFun_time_har(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i : i + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		newModelDictList.append(newModelDict)
		i = i + paraListLen
	lastTime = culFormatedTrainData[-1][0]
	lastEstNum = meanValueFun_har(lastTime, newModelDictList)
	totalIntensity = 0
	for time, num in culFormatedTrainData:
		try:
			lnintensity = logIntensityFun_har(time, newModelDictList)
		except Exception as e:
			SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n newModelDictList : "+str(newModelDictList)+"\n 错误详情:\n"+str(traceback.format_exc()))
			raise e
		totalIntensity = totalIntensity + lnintensity
	finValue = totalIntensity - lastEstNum
	return float(finValue)

# 自制负对数似然函数(时间数据) (调和平均)
def negaLogLikelihoodFun_time_har(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_time_har(paraList, culFormatedTrainData, modelDictList)

# 自制对数似然函数(组数据) (调和平均)
def logLikelihoodFun_group_har(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i : i + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		#newModelDict["weight"] = paraList[i]
		newModelDictList.append(newModelDict)
		i = i + paraListLen

	old_t = 0
	old_n = 0
	old_meanValue = 0
	last_t = culFormatedTrainData[-1][0]
	res = - meanValueFun_har(last_t, newModelDictList)
	zeroFlag = False
	for dataEle in culFormatedTrainData:
		t_i = dataEle[0]
		n_i = dataEle[1]
		meanValue = meanValueFun_har(t_i, newModelDictList)
		intervalMeanValue = meanValue - old_meanValue

		intervalN = n_i - old_n
		old_meanValue = meanValue
		old_n = n_i

		try:
			tempRes = 1
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / i)
				i += 1
			if tempRes == 0.0:
				zeroFlag = True
				tempRes = Decimal(1)
				i = 1
				while i <= intervalN:
					tempRes = tempRes * (Decimal(intervalMeanValue) / Decimal(i))
					i += 1
				tempRes = tempRes.ln()
			else:
				tempRes = math.log(tempRes)
		except Exception as e:
			"""
			debugStr = ""
			if t_i > 1:
				returnValue, returnValue2, finValue, deciList, meanValueList, nameList = meanValueFun_har_debug(t_i-1, newModelDictList)
				debugStr += "\n time : " + str(t_i-1)
				debugStr += "\n returnValue : " + str(returnValue)
				debugStr += "\n res : " + str(returnValue2)
				debugStr += "\n finValue : " + str(finValue)
				debugStr += "\n deciList 和 meanValueList :\n"
				j = 0
				for name in nameList:
					debugStr += str(name) + " : "+str(meanValueList[j]) + "   " + str(deciList[j]) + "\n"
					j += 1
			returnValue, returnValue2, finValue, deciList, meanValueList, nameList = meanValueFun_har_debug(t_i, newModelDictList)
			debugStr += "\n time : " + str(t_i)
			debugStr += "\n returnValue : " + str(returnValue)
			debugStr += "\n res : " + str(returnValue2)
			debugStr += "\n finValue : " + str(finValue)
			debugStr += "\n deciList 和 meanValueList :\n"
			j = 0
			for name in nameList:
				debugStr += str(name) + " : "+str(meanValueList[j]) + "   " + str(deciList[j]) + "\n"
				j += 1
			SRMtool.sendNoticeMail("信息",debugStr+"\n\n last_t : "+str(last_t)+"\n lastEstNum : "+str(-res)+"\n meanValue : "+str(meanValue)+"\n old_meanValue : "+str(old_meanValue)+"\n tempRes : "+str(float(tempRes))+"\n data : "+str(culFormatedTrainData)+"\n intervalMeanValue : "+str(intervalMeanValue)+"\n meanValue : "+str(meanValue)+"\n newModelDictList : "+str(newModelDictList)+"\n 错误详情:\n"+str(traceback.format_exc()))
			"""
			raise e
		if zeroFlag == True:
			res = Decimal(res) + Decimal(tempRes)
		else:
			res = res + tempRes
	return float(res)


# 自制负对数似然函数(组数据) (调和平均)
def negaLogLikelihoodFun_group_har(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_group_har(paraList, culFormatedTrainData, modelDictList)






# 自制平均值函数 (几何平均)
def meanValueFun_geo(time, modelDictList):
	if time == 0.0 or time == 0:
		return 0.0
	meanValueList = []
	finValue = -1
	if modelDictList == []:
		return finValue
	for modelDict in modelDictList:
		paraList = modelDict["paraList"]
		weight = modelDict["weight"]
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		meanValue = mymeanFun(time, paraList)
		meanValueList.append(meanValue**weight)
	finValue = 1
	for meanValue in meanValueList:
		finValue = finValue * meanValue
	return finValue


# 自制强度函数 (几何平均)
def intensityFun_geo(time, modelDictList):
	if modelDictList == []:
		return -1
	intensityValueList = []
	meanValuePowerList = []
	meanValueDiffList = []
	zeroFlag = False
	for modelDict in modelDictList:
		# 提取参数
		paraList = modelDict["paraList"]
		weight = modelDict["weight"]
		# 计算强度
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0:
			zeroFlag = True
			intensityValue = intensityFun_backup(time, paraList)
		intensityValueList.append(intensityValue)
		# 计算平均值
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		meanValue = mymeanFun(time, paraList)
		meanValueDiffList.append(weight * (meanValue**(weight-1)))
		meanValuePowerList.append(meanValue**weight)

	if zeroFlag == False:
		i = 0
		totalIntensity = 0
		modelLen = len(modelDictList)
		for modelDict in modelDictList:
			partA = meanValueDiffList[i] * intensityValueList[i]
			partB = 1
			j = 0
			while j < modelLen:
				if i == j:
					j += 1
					continue
				meanValuePower = meanValuePowerList[j]
				partB = partB * meanValuePower
				j += 1
			totalIntensity += partA * partB
			i += 1
	if zeroFlag == True:
		i = 0
		totalIntensity = Decimal(0)
		modelLen = len(modelDictList)
		for modelDict in modelDictList:
			partA = Decimal(meanValueDiffList[i]) * Decimal(intensityValueList[i])
			partB = 1
			j = 0
			while j < modelLen:
				if i == j:
					j += 1
					continue
				meanValuePower = meanValuePowerList[j]
				partB = partB * meanValuePower
				j += 1
			totalIntensity += partA * Decimal(partB)
			i += 1
	return float(totalIntensity)

# 自制对数强度函数 (几何平均)
def logIntensityFun_geo(time, modelDictList):
	if modelDictList == []:
		return -1
	intensityValueList = []
	meanValuePowerList = []
	meanValueDiffList = []
	zeroFlag = False

	for modelDict in modelDictList:
		# 提取参数
		paraList = modelDict["paraList"]
		weight = modelDict["weight"]
		# 计算强度
		myIntensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
		intensityValue = myIntensityFun(time, paraList)
		if intensityValue == 0.0:
			zeroFlag = True
			intensityValue = intensityFun_backup(time, paraList)
		intensityValueList.append(intensityValue)
		# 计算平均值
		mymeanFun, meanFun_backup = modelTool.meanValueFunction(modelDict)
		meanValue = mymeanFun(time, paraList)
		meanValueDiffList.append(weight * (meanValue**(weight-1)))
		meanValuePowerList.append(meanValue**weight)

	if zeroFlag == False:
		i = 0
		totalIntensity = 0
		modelLen = len(modelDictList)
		partAList = []
		partBList = []
		for modelDict in modelDictList:
			partA = meanValueDiffList[i] * intensityValueList[i]
			partB = 1
			j = 0
			while j < modelLen:
				if i == j:
					j += 1
					continue
				meanValuePower = meanValuePowerList[j]
				partB = partB * meanValuePower
				j += 1
			totalIntensity += partA * partB
			partAList.append(partA)
			partBList.append(partB)
			i += 1
		try:
			logValue = math.log(totalIntensity)
		except Exception as e:
			SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n partAList : "+str(partAList)+"\n partBList : "+str(partBList)+"\n meanValueDiffList : "+str(meanValueDiffList)+"\n meanValuePowerList : "+str(meanValuePowerList)+"\n modelDictList : "+str(modelDictList)+"\n 错误详情:\n"+str(traceback.format_exc()))
			raise e
	if zeroFlag == True:
		i = 0
		totalIntensity = Decimal(0)
		modelLen = len(modelDictList)
		for modelDict in modelDictList:
			partA = Decimal(meanValueDiffList[i]) * Decimal(intensityValueList[i])
			partB = 1
			j = 0
			while j < modelLen:
				if i == j:
					j += 1
					continue
				meanValuePower = meanValuePowerList[j]
				partB = partB * meanValuePower
				j += 1
			totalIntensity += partA * Decimal(partB)
			i += 1
		logValue = totalIntensity.ln()
	return float(logValue)

# 自制对数似然函数(时间数据) (几何平均)
def logLikelihoodFun_time_geo(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	weightList = []
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i+1 : i+1 + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		newModelDict["weight"] = paraList[i]
		newModelDictList.append(newModelDict)
		i = i + paraListLen + 1
		weightList.append(newModelDict["weight"])

	#if abs(sum(weightList)) < 1e-6:
	#	SRMtool.sendNoticeMail("权重数值错误","culFormatedTrainData : "+str(culFormatedTrainData)+"\n paraList : "+str(paraList)+"\n newModelDictList : "+str(newModelDictList)+"\n weightList : "+str(weightList))
	#	raise
	lastTime = culFormatedTrainData[-1][0]
	lastEstNum = meanValueFun_geo(lastTime, newModelDictList)
	totalIntensity = 0
	for time, num in culFormatedTrainData:
		try:
			lnintensity = logIntensityFun_geo(time, newModelDictList)
		except Exception as e:
			SRMtool.sendNoticeMail("信息","time : "+str(time)+"\n newModelDictList : "+str(newModelDictList)+"\n 错误详情:\n"+str(traceback.format_exc()))
			raise e
		totalIntensity = totalIntensity + lnintensity
	finValue = totalIntensity - lastEstNum
	return float(finValue)

# 自制负对数似然函数(时间数据) (几何平均)
def negaLogLikelihoodFun_time_geo(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_time_geo(paraList, culFormatedTrainData, modelDictList)

# 自制对数似然函数(组数据) (几何平均)
def logLikelihoodFun_group_geo(paraList, culFormatedTrainData, modelDictList):
	# 组装模型字典
	newModelDictList = []
	i = 0
	for modelDict in modelDictList:
		paraListLen = len(modelDict["paraList"])
		nowParaList = paraList[i+1 : i+1 + paraListLen]
		newModelDict = copy.deepcopy(modelDict)
		newModelDict["paraList"] = nowParaList
		newModelDict["weight"] = paraList[i]
		newModelDictList.append(newModelDict)
		i = i + paraListLen + 1

	old_t = 0
	old_n = 0
	old_meanValue = 0
	last_t = culFormatedTrainData[-1][0]
	res = - meanValueFun_geo(last_t, newModelDictList)
	zeroFlag = False
	for dataEle in culFormatedTrainData:
		t_i = dataEle[0]
		n_i = dataEle[1]
		meanValue = meanValueFun_geo(t_i, newModelDictList)
		intervalMeanValue = meanValue - old_meanValue

		intervalN = n_i - old_n
		old_meanValue = meanValue
		old_n = n_i

		try:
			tempRes = 1
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / i)
				i += 1
			if tempRes == 0.0:
				zeroFlag = True
				tempRes = Decimal(1)
				i = 1
				while i <= intervalN:
					tempRes = tempRes * (Decimal(intervalMeanValue) / Decimal(i))
					i += 1
				tempRes = tempRes.ln()
			else:
				tempRes = math.log(tempRes)
		except Exception as e:
			raise e
		if zeroFlag == True:
			res = Decimal(res) + Decimal(tempRes)
		else:
			res = res + tempRes
	return float(res)


# 自制负对数似然函数(组数据) (几何平均)
def negaLogLikelihoodFun_group_geo(paraList, culFormatedTrainData, modelDictList):
	return -1 * logLikelihoodFun_group_geo(paraList, culFormatedTrainData, modelDictList)


