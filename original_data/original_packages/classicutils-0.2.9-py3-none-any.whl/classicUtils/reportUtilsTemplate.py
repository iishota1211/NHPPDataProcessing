import xlsxwriter, statistics, copy
import numpy as np

def getNumFormat(wb, num_format = "0.00"):
	reportFormat = wb.add_format({
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
			'num_format': num_format
		})
	return reportFormat

def getRedNumFormat(wb):
	reportFormat = wb.add_format({
			'color' : 'red',
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
			'num_format': '0.00'
		})
	return reportFormat

def getBoldNumFormat(wb):
	reportFormat = wb.add_format({
			'bold': True,
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
			'num_format': '0.00'
		})
	return reportFormat


def getRedBoldNumFormat(wb):
	reportFormat = wb.add_format({
			'bold': True,
			'color' : 'red',
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
			'num_format': '0.00'
		})
	return reportFormat

def getGreenNumFormat(wb):
	reportFormat = wb.add_format({
			'color' : 'green',
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
			'num_format': '0.00'
		})
	return reportFormat

def getNormalFormat(wb):
	reportFormat = wb.add_format({
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
		})
	return reportFormat

def getRedNormalFormat(wb):
	reportFormat = wb.add_format({
			'color' : 'red',
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
		})
	return reportFormat

def getGreenNormalFormat(wb):
	reportFormat = wb.add_format({
			'color' : 'green',
			'align': 'centre',  # 水平对齐方式
			'valign': 'vcenter',  # 垂直对齐方式
		})
	return reportFormat

# 获取所有的methodName
def getMethodNameList(estimateDict, dictUniName):
	miniMethodList = None
	for dataType in estimateDict:
		for predInterval in estimateDict[dataType]:
			for dataName in estimateDict[dataType][predInterval]:
				if dictUniName not in estimateDict[dataType][predInterval][dataName]:
					continue
				singleEstDict = estimateDict[dataType][predInterval][dataName][dictUniName]
				methodNameList = []
				for methodName in singleEstDict:
					methodNameList.append(methodName)
				if miniMethodList is None:
					miniMethodList = methodNameList
				else:
					miniMethodList = list(set(miniMethodList) & set(methodNameList))
	return miniMethodList

def getMainMeasureNameWithModelType(predictDict, dictUniName, methodName, modelType):
	measureNameDict = dict()
	# 计算指标数量
	for dataType in predictDict:
		for predInterval in predictDict[dataType]:
			for dataName in predictDict[dataType][predInterval]:
				if dictUniName not in predictDict[dataType][predInterval][dataName]:
					continue
				singleEstDict = predictDict[dataType][predInterval][dataName][dictUniName]
				for modelName in singleEstDict[methodName][modelType]:
					if "measureNameList" not in singleEstDict[methodName][modelType][modelName]:
						continue
					measureNameList = singleEstDict[methodName][modelType][modelName]["measureNameList"]
					mainMeasureName = measureNameList[0]
					if mainMeasureName not in measureNameDict:
						measureNameDict[mainMeasureName] = 1
					else:
						measureNameDict[mainMeasureName] += 1
	# 找出主指标名称
	maxName = None
	maxCounter = 0
	for measureName in measureNameDict:
		nowCounter = measureNameDict[measureName]
		if nowCounter > maxCounter:
			maxCounter = nowCounter
			maxName = measureName

	return maxName

# 获取methodName的主指标名称
def getMainMeasureName(estimateDict, dictUniName, methodName):
	measureNameDict = dict()
	# 计算指标数量
	for dataType in estimateDict:
		for predInterval in estimateDict[dataType]:
			for dataName in estimateDict[dataType][predInterval]:
				if dictUniName not in estimateDict[dataType][predInterval][dataName]:
					continue
				singleEstDict = estimateDict[dataType][predInterval][dataName][dictUniName]
				for modelType in singleEstDict[methodName]:
					for modelName in singleEstDict[methodName][modelType]:
						if "measureNameList" not in singleEstDict[methodName][modelType][modelName]:
							continue
						measureNameList = singleEstDict[methodName][modelType][modelName]["measureNameList"]
						mainMeasureName = measureNameList[0]
						if mainMeasureName not in measureNameDict:
							measureNameDict[mainMeasureName] = 1
						else:
							measureNameDict[mainMeasureName] += 1
	# 找出主指标名称
	maxName = None
	maxCounter = 0
	for measureName in measureNameDict:
		nowCounter = measureNameDict[measureName]
		if nowCounter > maxCounter:
			maxCounter = nowCounter
			maxName = measureName

	return maxName

# 获取methodName的所有指标名称
def getMeasureNameList(estimateDict, dictUniName, methodName):
	miniMeasureList = None
	# 计算指标数量
	for dataType in estimateDict:
		for predInterval in estimateDict[dataType]:
			for dataName in estimateDict[dataType][predInterval]:
				if dictUniName not in estimateDict[dataType][predInterval][dataName]:
					continue
				singleEstDict = estimateDict[dataType][predInterval][dataName][dictUniName]
				for modelType in singleEstDict[methodName]:
					for modelName in singleEstDict[methodName][modelType]:
						if "measureNameList" not in singleEstDict[methodName][modelType][modelName]:
							continue
						measureNameList = singleEstDict[methodName][modelType][modelName]["measureNameList"]
						if miniMeasureList is None:
							miniMeasureList = measureNameList
						else:
							miniMeasureList = list(set(miniMeasureList) & set(measureNameList))
	return miniMeasureList

# 提取某个完整训练数据中所有模型的mainMeasureName列表
# 使用方式 : 
# Measure最小的模型的measureValue 	: miniMeasure = measureList[0][0]
# Measure最小的模型的index 			: miniMeasureIndex = measureList[0][1]
# Measure最小的模型的模型类别 		: miniMeasureModelType = modelIndexMateList[ miniMeasureIndex ][0]
# Measure最小的模型的模型名称 		: miniMeasureModelName = modelIndexMateList[ miniMeasureIndex ][1]
def getTrainDataMeasureList(estimateDict, dictUniName, dataType, dataName, predInterval, methodName, mainMeasureName):
	singleEstDict = estimateDict[dataType][predInterval][dataName][dictUniName]
	measureList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelType in singleEstDict[methodName]:
		for modelName in singleEstDict[methodName][modelType]:
			resDict = singleEstDict[methodName][modelType][modelName]
			measureValue = resDict["measureValueDict"][mainMeasureName]
			paraList = resDict["paraList"]
			MAE = -1
			if "culMAE" in resDict["measureValueDict"]:
				MAE = resDict["measureValueDict"]["culMAE"]
			if "alias" in resDict:
				alias = resDict["alias"]
			else:
				alias = None
			measureList.append([measureValue, modelIndex])
			modelIndexMateList.append([modelType, modelName, paraList, MAE, alias])
			modelIndex += 1
	if mainMeasureName == "LL":
		measureList = sorted(measureList, key=lambda x: -9999999999 if x[0] == "False" else x[0], reverse=True)
	else:
		measureList = sorted(measureList, key=lambda x: 9999999999 if x[0] == "False" else  x[0])
	return measureList, modelIndexMateList

def getTrainDataMeasureListWithModelType(predictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName, modelType):
	singleEstDict = predictDict[dataType][predInterval][dataName][dictUniName]
	measureList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelName in singleEstDict[methodName][modelType]:
		resDict = singleEstDict[methodName][modelType][modelName]
		measureValue = resDict["measureValueDict"][mainMeasureName]
		paraList = resDict["paraList"]
		MAE = -1
		if "culMAE" in resDict["measureValueDict"]:
			MAE = resDict["measureValueDict"]["culMAE"]
		if "alias" in resDict:
			alias = resDict["alias"]
		else:
			alias = None
		measureList.append([measureValue, modelIndex])
		modelIndexMateList.append([modelType, modelName, paraList, MAE, alias])
		modelIndex += 1
	if mainMeasureName == "LL":
		measureList = sorted(measureList, key=lambda x: -9999999999 if x[0] == "False" else x[0], reverse=True)
	else:
		measureList = sorted(measureList, key=lambda x: 9999999999 if x[0] == "False" else  x[0])
	return measureList, modelIndexMateList


# 提取某个完整训练数据中所有模型的mainMeasureName列表
# 使用方式 : 
# Measure最小的模型的measureValue 	: miniMeasure = measureList[0][0]
# Measure最小的模型的index 			: miniMeasureIndex = measureList[0][1]
# Measure最小的模型的模型类别 		: miniMeasureModelType = modelIndexMateList[ miniMeasureIndex ][0]
# Measure最小的模型的模型名称 		: miniMeasureModelName = modelIndexMateList[ miniMeasureIndex ][1]
def getTrainDataMeasureListForSim(estimateDict, dictUniName, dataType, dataName, predInterval, methodName, mainMeasureName, flag):
	singleEstDict = estimateDict[dataType][predInterval][dataName][flag][dictUniName]
	measureList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelType in singleEstDict[methodName]:
		for modelName in singleEstDict[methodName][modelType]:
			resDict = singleEstDict[methodName][modelType][modelName]
			measureValue = resDict["measureValueDict"][mainMeasureName]
			paraList = resDict["paraList"]
			MAE = -1
			if "culMAE" in resDict["measureValueDict"]:
				MAE = resDict["measureValueDict"]["culMAE"]
			if "alias" in resDict:
				alias = resDict["alias"]
			else:
				alias = None
			measureList.append([measureValue, modelIndex])
			modelIndexMateList.append([modelType, modelName, paraList, MAE, alias])
			modelIndex += 1
	if mainMeasureName == "LL":
		measureList = sorted(measureList, key=lambda x: -9999999999 if x[0] == "False" else x[0], reverse=True)
	else:
		measureList = sorted(measureList, key=lambda x: 9999999999 if x[0] == "False" else  x[0])
	return measureList, modelIndexMateList

def getTrainDataMeasureListWithModelTypeForSim(predictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName, modelType, flag):
	singleEstDict = predictDict[dataType][predInterval][dataName][flag][dictUniName]
	measureList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelName in singleEstDict[methodName][modelType]:
		resDict = singleEstDict[methodName][modelType][modelName]
		measureValue = resDict["measureValueDict"][mainMeasureName]
		paraList = resDict["paraList"]
		MAE = -1
		if "culMAE" in resDict["measureValueDict"]:
			MAE = resDict["measureValueDict"]["culMAE"]
		if "alias" in resDict:
			alias = resDict["alias"]
		else:
			alias = None
		measureList.append([measureValue, modelIndex])
		modelIndexMateList.append([modelType, modelName, paraList, MAE, alias])
		modelIndex += 1
	if mainMeasureName == "LL":
		measureList = sorted(measureList, key=lambda x: -9999999999 if x[0] == "False" else x[0], reverse=True)
	else:
		measureList = sorted(measureList, key=lambda x: 9999999999 if x[0] == "False" else  x[0])
	return measureList, modelIndexMateList

# 获取PMAE最小的结果
def getTrainDataMiniPMAEList(basePredictDict, dataType, dataName, predInterval, methodName, dictUniName, predResMeasureName = "culPMAE"):
	predictionDict = basePredictDict[dataType][predInterval][dataName][dictUniName]
	PMAEList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelType in predictionDict[methodName]:
		for modelName in predictionDict[methodName][modelType]:
			resDict = predictionDict[methodName][modelType][modelName]
			PMAE = resDict[predResMeasureName]
			paraList = resDict["paraList"]
			if "alias" in resDict:
				alias = resDict["alias"]
			else:
				alias = None
			PMAEList.append([PMAE, modelIndex])
			# 为了与getTrainDataMeasureList的输出接口保持风格一致, 特意连续输出两个 alias
			modelIndexMateList.append([modelType, modelName, paraList, alias, alias])
			modelIndex += 1
	PMAEList = sorted(PMAEList, key=lambda x: x[0])
	return PMAEList, modelIndexMateList

# 获取UniName名称列表
def getUniNameList(predictDict,dataType,predInterval):
	unUseUniNameList = ["culTrainData","culTestData","culFormatedTrainData","culFormatedTestData","optionPara",]
	miniUniNameList = None
	# 计算指标数量
	if dataType not in predictDict:
		return miniUniNameList
	if predInterval not in predictDict[dataType]:
		return miniUniNameList
	for dataName in predictDict[dataType][predInterval]:
		tempList = []
		for dictUniName in predictDict[dataType][predInterval][dataName]:
			if dictUniName in unUseUniNameList:
				continue
			tempList.append(dictUniName)
		if miniUniNameList is None:
			miniUniNameList = tempList
		else:
			miniUniNameList = list(set(miniUniNameList) & set(tempList))
	return miniUniNameList

# 转换带预处理格式的数据名称
def getPreprocessPara(dataName):
	realDataName = ""
	preprocessFlag = ""
	preprocessNumStr = "0"
	isPreprocess = False
	resList = dataName.split(";")
	if len(resList) == 3:
		isPreprocess = True
		preprocessFlag = resList[0]
		preprocessNumStr = resList[1]
		realDataName = resList[2]
	elif len(resList) == 1:
		realDataName = resList[0]
	else:
		raise
	return [isPreprocess, realDataName, preprocessFlag, preprocessNumStr]

# 将经过预处理的数据格式转换为更规范的格式。
# 原格式：
# dataDict[dataType][predInterval][flag;numStr;dataName][dictUniName][methodName][modelType][modelName][someMeasureList/someMeasure]
# 更规范的格式：
# dataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName]["originalList"/"median"/"maxValue"/"minValue"/...]
# "originalList" 表示原始的数据结果集合
def formatePreprocessData(oldDataDict, measureNameSelector = []):
	dataUniNameList = ["culTrainData","culTestData","culFormatedTrainData","culFormatedTestData","optionPara"]
	newDataDict = dict()
	# 汇总数据
	for dataType in oldDataDict:
		newDataDict[dataType] = dict()
		#if not isinstance(oldDataDict, dict):
		#	print(oldDataDict)
		for predInterval in oldDataDict[dataType]:
			newDataDict[dataType][predInterval] = dict()
			for oldDataName in oldDataDict[dataType][predInterval]:
				isPreprocess, realDataName, preprocessFlag, preprocessNumStr = getPreprocessPara(oldDataName)
				if isPreprocess == False:
					#print(oldDataName)
					continue

				nameList = newDataDict[dataType][predInterval]
				for tempName in nameList:
					if tempName in realDataName or realDataName in tempName:
						realDataName = tempName
						break

				for dictUniName in oldDataDict[dataType][predInterval][oldDataName]:
					if dictUniName in dataUniNameList:
						continue
					for methodName in oldDataDict[dataType][predInterval][oldDataName][dictUniName]:
						for modelType in oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName]:
							for modelName in oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName][modelType]:
								resDict = oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName][modelType][modelName]
								# 逐个尝试获取 measureValue
								tempMeasureDict = dict()
								if "estCostTime" in resDict:
									tempMeasureDict["estCostTime"] = resDict["estCostTime"]
								if "nonCulPMAE" in resDict:
									tempMeasureDict["nonCulPMAE"] = resDict["nonCulPMAE"]
								if "culPMAE" in resDict:
									tempMeasureDict["culPMAE"] = resDict["culPMAE"]
								if "measureValueDict" in resDict:
									measureValueDict = resDict["measureValueDict"]
									for measureName in measureValueDict:
										tempMeasureDict[measureName] = measureValueDict[measureName]
								#print(tempMeasureDict.keys())
								for measureName in tempMeasureDict:

									if measureNameSelector != [] and measureName not in measureNameSelector:
										#print("measureName : "+measureName)
										continue
									measureValue = tempMeasureDict[measureName]
									if realDataName not in newDataDict[dataType][predInterval]:
										newDataDict[dataType][predInterval][realDataName] = dict()
									if preprocessFlag not in newDataDict[dataType][predInterval][realDataName]:
										newDataDict[dataType][predInterval][realDataName][preprocessFlag] = dict()
									if dictUniName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag]:
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName] = dict()
									if methodName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName]:
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName] = dict()
									if modelType not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName]:
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType] = dict()
									if modelName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType]:
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName] = dict()
									# 单一数值型
									if not isinstance(measureValue, list):
										if measureName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName]:
											tempNewName = measureName
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName] = dict()
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"] = list()
										try:
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"].append(float(measureValue))

										except Exception as e:
											print("dataType : ", dataType)
											print("predInterval : ", predInterval)
											print("realDataName : ", realDataName)
											print("preprocessFlag : ", preprocessFlag)
											print("methodName : ", methodName)
											print("modelType : ", modelType)
											print("modelName : ", modelName)
											print("tempNewName : ", tempNewName)
											print("measureValue : ", measureValue)
											raise e
																			# 标准化列表型
									else:
										for nowTime, nowNum in measureValue:
											tempNewName = measureName + "-" + str(nowTime)
											if tempNewName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName]:
												newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName] = dict()
												newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"] = list()
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"].append(float(nowNum))
	# 计算中位数等
	for dataType in newDataDict:
		for predInterval in newDataDict[dataType]:
			for dataName in newDataDict[dataType][predInterval]:
				for flag in newDataDict[dataType][predInterval][dataName]:
					for dictUniName in newDataDict[dataType][predInterval][dataName][flag]:
						for methodName in newDataDict[dataType][predInterval][dataName][flag][dictUniName]:
							for modelType in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
								for modelName in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
									for measureName in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]:
										originalList = newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName]["originalList"]

										# 计算指标
										maxValue = max(originalList)
										minValue = min(originalList)
										avg = statistics.mean(originalList)
										median = statistics.median(originalList)

										try:
											q1 = np.percentile(originalList, 25)
										except Exception as e:
											print(measureName)
											print(originalList)
											raise e
										q3 = np.percentile(originalList, 75)
										p5 = np.percentile(originalList, 5)
										p95 = np.percentile(originalList, 95)
										# 总体方差
										try:
											pVar = statistics.pvariance(originalList)
											# 样本方差
											var = statistics.variance(originalList)
										except Exception as e:
											print("dataName : "+dataName)
											print("dictUniName : "+dictUniName)
											print("methodName : "+methodName)
											print("modelType : "+modelType)
											print("modelName : "+modelName)
											print("measureName : "+measureName)
											print("originalList : "+str(originalList))
											raise e
										

										# 汇总指标
										tempMeasureDict = dict()
										tempMeasureDict["maxValue"] = maxValue
										tempMeasureDict["minValue"] = minValue
										tempMeasureDict["average"] = avg
										tempMeasureDict["median"] = median
										tempMeasureDict["q1"] = q1
										tempMeasureDict["q3"] = q3
										tempMeasureDict["p5"] = p5
										tempMeasureDict["p95"] = p95
										tempMeasureDict["pVariance"] = pVar
										tempMeasureDict["variance"] = var

										# 格式化输出
										for tempMeasureName in tempMeasureDict:
											newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName][tempMeasureName] = tempMeasureDict[tempMeasureName]
	return newDataDict

# 将经过预处理的数据格式转换为更规范的格式。(模拟数据)
# 原格式：
# dataDict[dataType][predInterval][flag;numStr;dataName][dictUniName][methodName][modelType][modelName][someMeasureList/someMeasure]
# 更规范的格式：
# dataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName]["originalList"/"median"/"maxValue"/"minValue"/...]
# "originalList" 表示原始的数据结果集合
def formatePreprocessDataForSimData(oldDataDict, measureNameSelector = [], notUseUniNameList = []):
	dataUniNameList = ["culTrainData","culTestData","culFormatedTrainData","culFormatedTestData","optionPara"]
	newDataDict = dict()
	# 汇总数据
	for dataType in oldDataDict:
		newDataDict[dataType] = dict()
		for predInterval in oldDataDict[dataType]:
			newDataDict[dataType][predInterval] = dict()
			dataCounter = 1
			for oldDataName in oldDataDict[dataType][predInterval]:
				isPreprocess, realDataName, preprocessFlag, preprocessNumStr = getPreprocessPara(oldDataName)
				if isPreprocess == False:
					preprocessFlag = "original"
				realDataName = "simData"
				#print("dataCounter : ",dataCounter)
				dataCounter += 1
				for dictUniName in oldDataDict[dataType][predInterval][oldDataName]:
					if dictUniName in dataUniNameList or dictUniName in notUseUniNameList:
						continue
					#print(dictUniName)
					for methodName in oldDataDict[dataType][predInterval][oldDataName][dictUniName]:
						#print(methodName)
						for modelType in oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName]:
							for modelName in oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName][modelType]:
								resDict = oldDataDict[dataType][predInterval][oldDataName][dictUniName][methodName][modelType][modelName]
								# 逐个尝试获取 measureValue
								tempMeasureDict = dict()
								if "estCostTime" in resDict:
									tempMeasureDict["estCostTime"] = resDict["estCostTime"]
								if "nonCulPMAE" in resDict:
									tempMeasureDict["nonCulPMAE"] = resDict["nonCulPMAE"]
								if "culPMAE" in resDict:
									tempMeasureDict["culPMAE"] = resDict["culPMAE"]
								if "measureValueDict" in resDict:
									measureValueDict = resDict["measureValueDict"]
									for measureName in measureValueDict:
										tempMeasureDict[measureName] = measureValueDict[measureName]
								#print(tempMeasureDict.keys())
								for measureName in tempMeasureDict:
									
									if measureNameSelector != [] and measureName not in measureNameSelector:
										#print("measureName : "+measureName)
										continue
									#print("measureName : ",measureName)

									measureValue = tempMeasureDict[measureName]
									if realDataName not in newDataDict[dataType][predInterval]:
										#print("初始化 : ",realDataName)
										newDataDict[dataType][predInterval][realDataName] = dict()
									if preprocessFlag not in newDataDict[dataType][predInterval][realDataName]:
										#print("初始化 : ",preprocessFlag)
										newDataDict[dataType][predInterval][realDataName][preprocessFlag] = dict()
									if dictUniName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag]:
										#print("初始化 : ",dictUniName)
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName] = dict()
									if methodName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName]:
										#print("初始化 : ",methodName)
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName] = dict()
									if modelType not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName]:
										#print("初始化 : ",modelType)
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType] = dict()
									if modelName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType]:
										#print("初始化 : ",modelName)
										newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName] = dict()
									# 单一数值型
									if not isinstance(measureValue, list):

										if measureName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName]:
											#print("初始化 : ",measureName)
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][measureName] = dict()
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][measureName]["originalList"] = list()
										try:
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][measureName]["originalList"].append(float(measureValue))
											#print(dataType," ",predInterval," ",realDataName," ",preprocessFlag," ",dictUniName," ",methodName," ",modelType," ",modelName," ",measureName," originalList : ",measureValue)
											#print("len(originalList)",len(newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][measureName]["originalList"]))
										except Exception as e:
											print("dataType : ", dataType)
											print("predInterval : ", predInterval)
											print("realDataName : ", realDataName)
											print("preprocessFlag : ", preprocessFlag)
											print("methodName : ", methodName)
											print("modelType : ", modelType)
											print("modelName : ", modelName)
											print("tempNewName : ", tempNewName)
											print("measureValue : ", measureValue)
											raise e
									# 标准化列表型
									else:
										#print("is List")
										for nowTime, nowNum in measureValue:
											tempNewName = measureName + "-" + str(nowTime)
											if tempNewName not in newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName]:
												newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName] = dict()
												newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"] = list()
											newDataDict[dataType][predInterval][realDataName][preprocessFlag][dictUniName][methodName][modelType][modelName][tempNewName]["originalList"].append(float(nowNum))
								#exit()
	# 计算中位数等
	for dataType in newDataDict:
		for predInterval in newDataDict[dataType]:
			for dataName in newDataDict[dataType][predInterval]:
				for flag in newDataDict[dataType][predInterval][dataName]:
					for dictUniName in newDataDict[dataType][predInterval][dataName][flag]:
						for methodName in newDataDict[dataType][predInterval][dataName][flag][dictUniName]:
							for modelType in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
								for modelName in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
									for measureName in newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]:
										originalList = newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName]["originalList"]
										#if measureName == "KL_Divergence_fit":
										#	print(dataName," , ",methodName," , ",originalList)
										# 计算指标
										maxValue = max(originalList)
										minValue = min(originalList)
										avg = statistics.mean(originalList)
										median = statistics.median(originalList)

										try:
											q1 = np.percentile(originalList, 25)
										except Exception as e:
											print(measureName)
											print(originalList)
											raise e
										q3 = np.percentile(originalList, 75)
										p5 = np.percentile(originalList, 5)
										p95 = np.percentile(originalList, 95)
										minRes = min(originalList)
										maxRes = max(originalList)
										# 总体方差
										try:
											pVar = statistics.pvariance(originalList)
											# 样本方差
											var = statistics.variance(originalList)
										except Exception as e:
											print("dataName : "+dataName)
											print("dictUniName : "+dictUniName)
											print("methodName : "+methodName)
											print("modelType : "+modelType)
											print("modelName : "+modelName)
											print("measureName : "+measureName)
											print("originalList : "+str(originalList))
											raise e
										

										# 汇总指标
										tempMeasureDict = dict()
										tempMeasureDict["maxValue"] = maxValue
										tempMeasureDict["minValue"] = minValue
										tempMeasureDict["average"] = avg
										tempMeasureDict["median"] = median
										tempMeasureDict["min"] = minRes
										tempMeasureDict["max"] = maxRes
										tempMeasureDict["q1"] = q1
										tempMeasureDict["q3"] = q3
										tempMeasureDict["p5"] = p5
										tempMeasureDict["p95"] = p95
										tempMeasureDict["pVariance"] = pVar
										tempMeasureDict["variance"] = var

										# 格式化输出
										for tempMeasureName in tempMeasureDict:
											newDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName][tempMeasureName] = tempMeasureDict[tempMeasureName]
	return newDataDict

# 提取不含预处理的原始数据结果（如果有)
def formateDataWithoutPreprocess(oldDataDict):
	newDataDict = dict()
	# 汇总数据
	for dataType in oldDataDict:
		newDataDict[dataType] = dict()
		for predInterval in oldDataDict[dataType]:
			newDataDict[dataType][predInterval] = dict()
			for oldDataName in oldDataDict[dataType][predInterval]:
				isPreprocess, realDataName, preprocessFlag, preprocessNumStr = getPreprocessPara(oldDataName)
				if isPreprocess == True:
					continue
				newDataDict[dataType][predInterval][oldDataName] = copy.deepcopy(oldDataDict[dataType][predInterval][oldDataName])
	return newDataDict

def getMeasureNameListForPreprocessData(preprocessDataDict, dataType, predInterval):
	measureNameList = []
	for dataName in preprocessDataDict[dataType][predInterval]:
		for flag in preprocessDataDict[dataType][predInterval][dataName]:
			for dictUniName in preprocessDataDict[dataType][predInterval][dataName][flag]:
				for methodName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName]:
					for modelType in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
						for modelName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
							for measureName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]:
								if measureName != "originalList" and measureName not in measureNameList:
									measureNameList.append(measureName)
	return measureNameList

def getIndicatorListForPreprocessData(preprocessDataDict, dataType, predInterval):
	indicatorList = []
	for dataName in preprocessDataDict[dataType][predInterval]:
		for flag in preprocessDataDict[dataType][predInterval][dataName]:
			for dictUniName in preprocessDataDict[dataType][predInterval][dataName][flag]:
				for methodName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName]:
					for modelType in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
						for modelName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
							for measureName in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]:
								if measureName == "originalList":
									continue
								for indicator in preprocessDataDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][measureName]:
									if indicator not in indicatorList:
										indicatorList.append(indicator)
	return indicatorList

def getModelList(predictDict, uniNameList, dataType, predInterval, dataName = None):
	modelTypeList = []
	modelNameList = []
	modelList = []
	if dataName == None:
		for uniName in uniNameList:
			for nowDataName in predictDict[dataType][predInterval]:
				for methodName in predictDict[dataType][predInterval][nowDataName][uniName]:
					for modelType in predictDict[dataType][predInterval][nowDataName][uniName][methodName]:
						for modelName in predictDict[dataType][predInterval][nowDataName][uniName][methodName][modelType]:
							modelDict = dict()
							modelDict["modelType"] = modelType
							modelDict["modelName"] = modelName
							# 检查是否重复
							isSame = False
							for tempModelDict in modelList:
								tempModelType = tempModelDict["modelType"]
								tempModelName = tempModelDict["modelName"]
								if tempModelType == modelType and tempModelName == modelName:
									isSame = True
									break
							if isSame == False:
								modelList.append(modelDict)
	else:
		for uniName in uniNameList:
			for methodName in predictDict[dataType][predInterval][dataName][uniName]:
				for modelType in predictDict[dataType][predInterval][dataName][uniName][methodName]:
					for modelName in predictDict[dataType][predInterval][dataName][uniName][methodName][modelType]:
						modelDict = dict()
						modelDict["modelType"] = modelType
						modelDict["modelName"] = modelName
						# 检查是否重复
						isSame = False
						for tempModelDict in modelList:
							tempModelType = tempModelDict["modelType"]
							tempModelName = tempModelDict["modelName"]
							if tempModelType == modelType and tempModelName == modelName:
								isSame = True
								break
						if isSame == False:
							modelList.append(modelDict)
	#print(modelList)
	return modelList

def getModelTypeList(estimateDict, dictUniName, dataType, dataName, predInterval, methodName):
	modelTypeList = []
	for modelType in estimateDict[dataType][predInterval][dataName][dictUniName][methodName]:
		modelTypeList.append(modelType)
	return modelTypeList

def getTrainDataMeasureListWithModelType(estimateDict, dictUniName, dataType, dataName, predInterval, methodName, mainMeasureName, modelType):
	singleEstDict = estimateDict[dataType][predInterval][dataName][dictUniName]
	measureList = []
	modelIndexMateList = []
	modelIndex = 0
	for modelName in singleEstDict[methodName][modelType]:
		resDict = singleEstDict[methodName][modelType][modelName]
		measureValue = resDict["measureValueDict"][mainMeasureName]
		paraList = resDict["paraList"]
		MAE = -1
		if "culMAE" in resDict["measureValueDict"]:
			MAE = resDict["measureValueDict"]["culMAE"]
		if "alias" in resDict:
			alias = resDict["alias"]
		else:
			alias = None
		measureList.append([measureValue, modelIndex])
		modelIndexMateList.append([modelType, modelName, paraList, MAE, alias])
		modelIndex += 1
	if mainMeasureName == "LL":
		measureList = sorted(measureList, key=lambda x: -9999999999 if x[0] == "False" else x[0], reverse=True)
	else:
		measureList = sorted(measureList, key=lambda x: 9999999999 if x[0] == "False" else  x[0])
	return measureList, modelIndexMateList

# 移除 uniNameList 里的每一个 uniNameName 包含在 modelTypeToBeRemovedList 的结果
# 例如 uniNameList = ["classicMethod"], modelTypeToBeRemovedList = ["typeII", "Burr"]
# 表示移除 classicMethod 内的 typeII 和 Burr 类模型的所有结果

def removeModelType(usrPredDict_original, uniNameList, modelTypeToBeRemovedList):
	usrPredDict = dict()
	for dataType in usrPredDict_original:
		usrPredDict[dataType] = dict()
		for predInterval in usrPredDict_original[dataType]:
			usrPredDict[dataType][predInterval] = dict()
			for dataName in usrPredDict_original[dataType][predInterval]:
				usrPredDict[dataType][predInterval][dataName] = dict()
				for dictUniName in usrPredDict_original[dataType][predInterval][dataName]:
					if dictUniName not in uniNameList:
						usrPredDict[dataType][predInterval][dataName][dictUniName] = copy.deepcopy(usrPredDict_original[dataType][predInterval][dataName][dictUniName])
					else:
						usrPredDict[dataType][predInterval][dataName][dictUniName] = dict()
						singlePredDict = usrPredDict_original[dataType][predInterval][dataName][dictUniName]
						for methodName in singlePredDict:
							usrPredDict[dataType][predInterval][dataName][dictUniName][methodName] = dict()
							for modelType in singlePredDict[methodName]:
								if modelType not in modelTypeToBeRemovedList:
									usrPredDict[dataType][predInterval][dataName][dictUniName][methodName][modelType] = copy.deepcopy(singlePredDict[methodName][modelType])
	return usrPredDict


