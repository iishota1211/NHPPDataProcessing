import math
from scipy import integrate
from decimal import *

def lossFunForKL(nowTime, paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup):
	intensityA = intensityFunA(nowTime, paraListA)
	intensityB = intensityFunB(nowTime, paraListB)
	logPart = intensityA / intensityB
	if logPart > 0.0 :
		res = intensityA * math.log(logPart) + intensityB - intensityA
		if res != float("inf") and res != float("-inf") and math.isnan(res) == False:
			return res

	intensityA = intensityFunA_backup(nowTime, paraListA)
	intensityB = intensityFunB_backup(nowTime, paraListB)

	try:
		return float(intensityA * (intensityA / intensityB).ln() + intensityB - intensityA)
	except Exception as e:
		print("nowTime : ",nowTime)
		print("intensityA : ",intensityA)
		print("intensityB : ",intensityB)
		raise e

# NHPP的KL散度 intensityFunA(t, paraList)
def KL_Divergence(startTime, endTime, paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup,limitPara=100):
	KL_Res = integrate.quad(lossFunForKL, startTime, endTime, (paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup),limit = limitPara)[0]
	return KL_Res

def lossFunForH(nowTime, paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup):
	intensityA = intensityFunA(nowTime, paraListA)
	intensityB = intensityFunB(nowTime, paraListB)
	return (math.sqrt(intensityA) - math.sqrt(intensityB)) ** 2

# NHPP的Hellinger距离
def HellingerDist(startTime, endTime, paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup,limitPara=100):
	H_integratePart = integrate.quad(lossFunForH, startTime, endTime, (paraListA, intensityFunA, intensityFunA_backup, paraListB, intensityFunB, intensityFunB_backup),limit = limitPara)[0]
	return 1 - math.exp(-0.5 * H_integratePart)































