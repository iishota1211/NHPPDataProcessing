# Version 5
# 重写了原本的两个函数。
# def toCulData( dataList )
# def toNonCulData( dataList )
# 新增数据formatted函数。
# def toFormatTimeData(timeData, startNum = 1)
# def toFormatGroupData(groupData, startTime = 1)
# def toInverseFormatTimeData(timeData, startNum = 1)
# def toInverseFormatGroupData(groupData, startTime = 1)
#
# 新增timeData转groupData函数
# def timeDataToNonCulGroupData(timeData, endTime, intervalSum)
# def timeDataToCulGroupData(timeData, endTime, intervalSum)

#Version 4

import math,scipy,numpy,traceback,itertools,copy,random,sys,xlrd,time,os,re,smtplib
from types import FunctionType, CodeType
from itertools import product, chain
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from operator import itemgetter
from scipy import optimize
from decimal import *

#from 剩余时间估计模块 import timeRemain
# 函数列表
# 1.切割出前percentage的数据
# def cutPercentageData(data,percentage)
# 
# 2.根据强度函数点数据的面积估算平均值函数
# def intensityToMean(timeList,intensityList,lineType = "broken")
# 
# 3.比较 originData 和 tranData 的MSE 
# def MSE(originDatas,tranDatas)
#
# 4.转换成累积数据
# def toCulData(data)

def split_list(lst, threshold):
    """
    将 lst 按照阈值 threshold 拆分成子列表并返回列表 of 列表。
    保持原顺序。
    """
    n = len(lst)
    if n <= threshold:
        return [lst[:]]  # 不超过阈值，直接返回一个子列表

    k = math.ceil(n / threshold)  # 子列表数量
    chunks = []
    for i in range(k):
        start = i * threshold
        end = start + threshold
        chunks.append(lst[start:end])
    return chunks

def rebuild_list(chunks):
    """
    将子列表列表合并成一个列表，保持顺序。
    """
    # 方法一：使用 itertools.chain
    return list(chain.from_iterable(chunks))

    # 方法二：用 sum 也可以（不推荐大型数据时）
    # return sum(chunks, [])

global cacheDict_float
global cacheDict
cacheDict_float = dict()
cacheDict = dict()

def factorial_float(num):
    if num < 0:
        raise
    global cacheDict_float
    if isinstance(cacheDict_float, dict):
        pass
    else:
        cacheDict_float = dict()
    if str(num) in cacheDict_float:
        return cacheDict_float[str(num)]
    else:
        factorialNum = math.factorial(num)
        cacheDict_float[str(num)] = factorialNum
        return factorialNum

def factorial(num):
    if num < 0:
        raise
    global cacheDict
    if isinstance(cacheDict, dict):
        pass
    else:
        cacheDict = dict()
    if str(num) in cacheDict:
        return cacheDict[str(num)]
    else:
        if num == 0 or num == 1:
            factorialNum = Decimal(1)
        else:
            factorialNum = Decimal(1)
            i = 1
            while i <= num:
                factorialNum = factorialNum * Decimal(i)
                i += 1
        cacheDict[str(num)] = factorialNum
        return factorialNum

def toNonFormatedData(formatedData, dataType):
    nonFormatedData = []
    if dataType == "time":
        for nowTime, nowNum in formatedData:
            nonFormatedData.append(nowTime)
    elif dataType == "group":
        for nowTime, nowNum in formatedData:
            nonFormatedData.append(nowNum)
    else:
        raise
    return nonFormatedData

# 读取数据
def readData(fileName):
    with open(fileName, 'r') as f:
        data = f.readlines()
        dataList = []
        for line in data:
            odom = line.split()
            dataList.append(float(odom[1]))   
    return dataList

# 切割出前percentage的数据
# percentage 取值为 0 ～ 1 之间（不能取 0
# percentage 为 0.3 时，返回data的前30%的数据(四舍六入五平分)
# percentage 为 1 时，返回data本身
# 桥王实验的 mode 默认为 down
def cutPercentageData(data,percentage,mode = "down"):
    dataLength = len(data)
    cutPoint = int( round(dataLength * percentage) )
    cutPoint = math.floor(dataLength * percentage) # 旧版本
    if mode == "down": #向下取整
        cutPoint = math.floor(dataLength * percentage)
    elif mode == "up": #向上取整
        cutPoint = math.ceil(dataLength * percentage)
    elif mode == "round": #四舍五入
        cutPoint = round(dataLength * percentage)
    elif mode == "old": # 旧版本
        cutPoint = int( round(dataLength * percentage) )
    else:
        return False
    ahead_data = data[0: cutPoint]
    after_data = data[cutPoint:]
    if(len(ahead_data) + len(after_data) != len(data)):
        return False
    return (ahead_data,after_data)

#数据切割
#截取下标start到下标end之间的数据(包括所在下标)
def cutData(data,start,end):
    return data[ start : (end + 1)]

# 根据强度函数点数据的面积估算平均值函数
# (仅限连续时间的强度函数)
# lineType 取 "straight" 时, 强度函数的采样点与采样点之间视作直线连接 (即Naive估计)
# lineType 取 "broken" 时, 强度函数的采样点与采样点之间视作折线连接 (常规的做法)
def intensityToMean(timeList,intensityList,lineType = "broken"):
    if lineType != "straight" and lineType != "broken" :
        return False
    old_time = 0
    # 初始化强度值
    if lineType == "straight" :
        old_intensity = intensityList[0]
    if lineType == "broken" :
        old_intensity = 0

    # 逐一遍历强度值
    meanList = []
    index = 0
    total = 0
    while index < len(timeList) :
        if lineType == "straight" :
            meanValue = (timeList[index] - old_time) * intensityList[index]
        if lineType == "broken" :
            meanValue = ( (old_intensity + intensityList[index]) * (timeList[index] - old_time) ) / 2
        total = total + meanValue
        meanList.append(total)
        old_time = timeList[index]
        old_intensity = intensityList[index]
        index = index + 1

    return meanList

# 计算两条线的面积误差
def sizeMSE(timeList, estList, realList):
    if len(timeList) != len(estList) or len(timeList) != len(realList):
        return False
    oldTime = timeList[0]
    oldEst = estList[0]
    oldNum = realList[0]
    finSize = 0
    i = 1
    while i < len(timeList):
        nowTime = timeList[i]
        nowEst = estList[i]
        nowNum = realList[i]
        h = nowTime - oldTime
        a = nowEst - nowNum
        b = oldEst - oldNum
        if (a > 0) != (b > 0):
            finSize += h * (a*a + b*b) / (2*abs(a+b))
        else:
            finSize += abs(a + b)*h/2
        oldTime = nowTime
        oldEst = nowEst
        oldNum = nowNum
        i += 1
    return finSize

# 比较 originData 和 tranData 的MSE
# (比较点到点的物理距离,随着数据增加，值逐渐变小)
# 取自大师姐论文
def MSE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    length = len(originDatas)
    total = 0
    i = 0
    for data in originDatas:
        x =  tranDatas[i] - data
        total = total + x*x
        i = i + 1
    total = total ** 0.5
    return total / length

def newMSE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    length = len(originDatas)
    total = 0
    i = 0
    for data in originDatas:
        x =  tranDatas[i] - data
        total = total + x*x
        i = i + 1
    return total / length
    
# 比较 originData 和 tranData 的MSE
# (仅比较点到点的物理距离)
def realMSE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    length = len(originDatas)
    total = 0
    i = 0
    for data in originDatas:
        x =  abs(tranDatas[i] - data)
        total = total + x
        i = i + 1
    return total / length

def pMAE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    length = len(originDatas)
    total = 0
    i = 0
    for data in originDatas:
        x =  abs(tranDatas[i] - data)
        total = total + x
        i = i + 1
    return total / length

def rMSE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    total = 0
    i = 0
    for data in originDatas:
        x =  abs(tranDatas[i] - data)**2
        total += x
        i = i + 1
    return math.sqrt(total / i)

# 比较 originData 和 tranData 的MSE
# (仅比较点到点的物理距离)
def sqrtRealMSE(originDatas,tranDatas):
    if(len(originDatas) != len(tranDatas)):
        return False;
    length = len(originDatas)
    total = 0
    i = 0
    for data in originDatas:
        x =  abs(tranDatas[i] - data)
        total = total + x
        i = i + 1
    return  math.sqrt(total) / length

def fixedMSE(originDatas,tranDatas,distantList):
    if(len(originDatas) != len(tranDatas)):
        return False;
    total = 0
    i = 0
    for data in originDatas:
        x =  distantList[i] * abs(tranDatas[i] - data)
        total = total + x
        i = i + 1
    return total

# 转换成累积数据
def toCulData(nonCulDataList):
    culDataList = []
    culNowData = 0
    for nonCulData in nonCulDataList:
        culNowData = culNowData + nonCulData
        culDataList.append(culNowData)
    return culDataList

    # old 我以前到底是什么脑回路。写出这种脑瘫代码
    c_odata = [0]*len(data)
    i = 0;
    for x in data:
        if(i == 0):
            c_odata[i] = x;
        else :
            c_odata[i] = c_odata[i - 1] + x;
        i = i + 1;
    return c_odata;

# 转换成单日数据
def toTimeData(data):
    timeData = []
    old_data = 0
    for x in data:
        timeData.append(x-old_data)
        old_data = x
    return timeData

# 转换成单日数据(功能一样，换一个更好理解的名称)
def toNonCulData(culDataList):
    nonCulDataList = []
    oldData = 0
    for culData in culDataList:
        nonCulDataList.append(culData - oldData)
        oldData = culData
    return nonCulDataList

# 将时间序列格式的时间数据转换为标准格式数据
def toFormatTimeData(timeData, startNum = 1):
    formatData = []
    nowNum = startNum
    for nowTime in timeData:
        formatData.append([nowTime,nowNum])
        nowNum += 1
    return formatData
    
# 将时间序列格式的组数据转换为标准格式数据
def toFormatGroupData(groupData, startTime = 1):
    formatData = []
    nowTime = startTime
    for nowNum in groupData:
        formatData.append([nowTime,nowNum])
        nowTime += 1
    return formatData

# 将时间序列格式的时间数据转换为标准格式逆数据
def toInverseFormatTimeData(timeData, startNum = 1):
    formatData = []
    nowNum = startNum
    for nowTime in timeData:
        formatData.append([nowNum,nowTime])
        nowNum += 1
    return formatData
    
# 将时间序列格式的组数据转换为标准格式逆数据
def toInverseFormatGroupData(groupData, startTime = 1):
    formatData = []
    nowTime = startTime
    for nowNum in groupData:
        formatData.append([nowNum,nowTime,])
        nowTime += 1
    return formatData


# 修正一个时间点出现2个bug的情况
# (仅限累积数据使用)
def fixTimeData(data):
    fixData = []
    i = 1
    fixData.append(data[0])
    while i < len(data):
        if data[i] == data[i-1] and i != len(data)-1 :
            ti = (data[i+1] + data[i-1]) / 2
            fixData.append(ti)
        else :
            fixData.append(data[i])
        i = i + 1
    return fixData

#利用核函数计算数据的权值 now_day是天数，例如65，则返回1~64天，每天的数据相对于第65天的权值.h为带宽
#kernelMethod 为选择核方法，可选值为 boxcar,Gaussian,Epanechnikov,tricube
def KernelWeight(now_day,startDay,endDay,h,kernelMethod):
    if(startDay > endDay):
        return false;
    weights = [];
    denominator = 0;
    i = startDay;
    while i <= endDay:
        a = (i - now_day) / h;
        weight = Kernel(a, kernelMethod);
        denominator = denominator + weight;
        weights.append(weight);
        i = i + 1;
    i = 0;
    while i < endDay - startDay + 1:
        weights[i] = weights[i]/denominator;
        i = i + 1;
    return weights;

#核函数计算
def Kernel(x,kernelMethod):
    if(kernelMethod == 'boxcar'):
        return boxcarKernel(x);
    elif(kernelMethod == 'Gaussian'):
        return GaussianKernel(x);
    elif(kernelMethod == 'Epanechnikov'):
        return EpanechnikovKernel(x);
    elif(kernelMethod == 'tricube'):
        return tricubeKernel(x);
    elif(kernelMethod == 'Triangle'):
        return TriangleKernel(x)
    elif(kernelMethod == 'Triweigh'):
        return TriweighKernel(x)
    else:
        return False;

#核函数具体实现
def boxcarKernel(x):
    a = 0.5 * I(x);
    return a;

def GaussianKernel(x):
    a = -0.5 * x * x;
    b = math.exp(a);
    c = (math.pi * 2) ** -0.5
    d = c * b;
    return d;

def EpanechnikovKernel(x):
    a = 0.75 * (1 - x*x) * I(x);
    return a;

def tricubeKernel(x):
    a = 70/81;
    b = (1 - abs(x)**3)**3;
    c = a * b * I(x);
    return c;

def TriangleKernel(x):
    return (1- abs(x)) * I(x)

def TriweighKernel(x):
    a = 15/16;
    b = (1 - x * x)**2;
    c = a * b * I(x);
    return c;

def I(x):
    x = abs(x);
    if(x <= 1):
        return 1;
    return 0;

#SRATS参数读取
def getParameterList(filename):
    MethodNames = ['ExpSRM','GammaSRM','ParetoSRM','TruncNormalSRM','LogNormalSRM','TruncLogistSRM','LogLogistSRM','TruncEVMaxSRM','LogEVMaxSRM','TruncEVMinSRM','LogEVMinSRM']
    with open(filename, 'r') as f:
        data = f.readlines()
        ParameterList = []
        i = 0;
        j = 0;
        while (i < len(data)) and (j < len(MethodNames)):
            data[i]=data[i].strip('\n')
            if(data[i] != MethodNames[j]):
                i = i + 1;
                continue
            lists = []
            if(data[i] == 'ExpSRM'):
                lists.append(float(data[i + 1]))
                lists.append(float(data[i + 2]))
                lists.append(float(0))#仅形式上存在
            else:
                lists.append(float(data[i + 1]))
                lists.append(float(data[i + 2]))
                lists.append(float(data[i + 3]))
            ParameterList.append(lists);
            i = i + 1;
            j = j + 1;
    return ParameterList

def Exp_Gt(t,args):
    b = args[1]
    x = math.exp(-1 * b * t);
    return 1 - x;

def D_Exp_Gt(t,args):
    b = args[1]
    x = math.exp(-1 * b * t);
    return b * x;

def Gamma_Gt(t,args):
    b = args[1]
    c = args[2]
    s = symbols('s');
    return integrate(((c**b)*(s**(b-1))*exp(-1*c*s))/GammaFunction(b),(s,0,t)).evalf()

def Pareto_Gt(t,args):
    b = args[1]
    c = args[2]
    x = (c / (t + c)) ** b;
    return 1 - x;

def D_Pareto_Gt(t,args):
    b = args[1]
    c = args[2]
    x = b * c * ((c / (t+c))**(b-1))
    return x / ((c+t)**2);

#SRM函数
def NormalFunction(t,b,c):
    x = 1/(math.sqrt(2 * math.pi)*b);
    s = symbols('s');
    #此处存疑。到底是 2*(b**2) 还是 (2*b)**2.暂时按前者计算
    #更新：已验证，前者正确。
    y = integrate(exp(-1*(((s-c)**2))/(2*b*b)),(s,-oo,t)).evalf();
    return x * y;

def LogistFunction(t,b,c):
    #if -1 * (t - c)/b > 300:
    #    return 0.0
    x = math.exp(-1 * (t - c)/b);
    return 1 / (1 + x);

def EVFunction(t,b,c):
    x = -1 * (t - c)/b;
    #if(x >= 600):
    #    return 0.0
    y = -1 * math.exp(x)
    return math.exp(y);

#伽玛函数
def GammaFunction(x):
    if(x <= 0):
        return false;
    t = symbols('t');
    return integrate((t ** (x-1))*exp(-1*t), (t, 0, +oo)).evalf();


#SRM平均值计算
#ExpSRM的参数c仅为了与其他函数保持参数列表形式上的一致而设立，并未使用
def ExpSRM(t,a,b,c):
    def F(times,p2):
        x = math.exp(-1 * p2 * times);
        return 1 - x;
    return a * F(t,b);
    
def GammaSRM(t,a,b,c):
    def F(times,p2,p3):
        s = symbols('s');
        return integrate(((p3**p2)*(s**(p2-1))*exp(-1*p3*s))/GammaFunction(p2),(s,0,times)).evalf()
    return a * F(t,b,c)
    
def ParetoSRM(t,a,b,c):
    def F(times,p2,p3):
        x = (p3 / (times + p3)) ** p2;
        return 1 - x;
    return a * F(t,b,c);

def TruncNormalSRM(t,a,b,c):
    F0 = NormalFunction(0,b,c);
    return a * (NormalFunction(t,b,c) - F0) / (1 - F0);
    
def LogNormalSRM(t,a,b,c):
    return a * NormalFunction(math.log(t),b,c);

def TruncLogistSRM(t,a,b,c):
    F0 = LogistFunction(0,b,c);
    return a * (LogistFunction(t,b,c) - F0) / (1 - F0);
    
def LogLogistSRM(t,a,b,c):
    return a * LogistFunction(math.log(t),b,c);

def TruncEVMaxSRM(t,a,b,c):
    F0 = EVFunction(0,b,c);
    return a * (EVFunction(t,b,c) - F0) / (1 - F0);
    
def LogEVMaxSRM(t,a,b,c):
    return a * EVFunction(math.log(t),b,c);

def TruncEVMinSRM(t,a,b,c):
    F0 = EVFunction(0,b,c);
    return a * (F0 - EVFunction(-1*t,b,c)) / F0;

def LogEVMinSRM(t,a,b,c):
    return a * (1 - EVFunction(-1 * math.log(t),b,c));

# 自动生成最大似然估计的约束边界
# Sample:
# 创建一个不等式约束。consStr为一个中心值，consStr为中心值左右的范围。
# data 为list类型
# dataNameStr 为形参名,str类型. 例如:dataNameStr="xList". 与consStr中使用的数据名称一致即可.
# paraNameStr 为形参名,str类型. 例如:paraNameStr="paraList".与consStr中使用的参数名称一致即可.
# rangeBound 为list, 例如rangeBound = [-5,6]. 表示 约束范围 -5到6.
# consStr 为实际约束的数学式子, 遵循python语法.例如:
# consStr = "xList[0]*paraList[0] + math.log(xList[1])**paraList[1]"
# 其中, paraList需与paraNameStr设置的一致. dataNameStr将被替换为data中的实际数值。
def createCons(data, consStr, dataNameStr, paraNameStr, rangeBound):
    # 转换核心约束代码
    strList = re.split("("+dataNameStr+"\[[0-9]*\])",consStr)
    if len(strList) > 1:
        newStr = ""
        for myStr in strList:
            tempStr = myStr
            if re.search("("+dataNameStr+"\[[0-9]*\])", myStr) != None:
                
                tempStr = myStr.replace(dataNameStr , 'data')
                num = eval(tempStr)
                #num = locals()["data"][0]
                #print(num)
                tempStr = str(num)
            newStr += tempStr
    else:
        strList = re.split("("+dataNameStr+")",consStr)
        newStr = ""
        for myStr in strList:
            tempStr = myStr
            if re.search("("+dataNameStr+")", myStr) != None:
                
                tempStr = myStr.replace(dataNameStr , 'data')
                num = eval(tempStr)
                #num = locals()["data"][0]
                #print(num)
                tempStr = str(num)
            newStr += tempStr

    # 构建约束函数
    randomStr = str(random.randint(1,100000))
    #print(randomStr)
    code_1 = """
def consFun"""+randomStr+"""("""+paraNameStr+"""):
    total = """+newStr+"""
    return total - ("""+str(rangeBound[0])+""")
"""
    #print(code_1)
    #exit()
    foo_compile = compile(code_1 , "", "exec")
    foo_code = [ i for i in foo_compile.co_consts if isinstance(i, CodeType)][0]
    globals()['consFun'+randomStr] = FunctionType(foo_code, globals())
    consFun1 = globals()['consFun'+randomStr]
    cons1 = {'type': 'ineq', 'fun': consFun1, 'ineqFlag' : 'min'}

    randomStr = str(random.randint(1,100000))
    #print(randomStr)
    code_2 = """
def consFun"""+randomStr+"""("""+paraNameStr+"""):
    total = """+newStr+"""
    return - total + ("""+str(rangeBound[1])+""")
"""
    #print(code_2)
    foo_compile = compile(code_2 , "", "exec")
    foo_code = [ i for i in foo_compile.co_consts if isinstance(i, CodeType)][0]
    globals()['consFun'+randomStr] = FunctionType(foo_code, globals())
    consFun2 = globals()['consFun'+randomStr]
    cons2 = {'type': 'ineq', 'fun': consFun2, 'ineqFlag' : 'max'}

    #return [f_cons1,]
    return [cons1,cons2]


# 根据约束边界自动生成初始值
def findInitValue(consList, paraNum, bounds):
    x0 = []
    i = 0
    while i < paraNum:
        x0.append(1)
        i += 1
    funcList = []
    ineqFlagList = []
    for cons in consList:
        #print(cons)
        funcList.append(cons["fun"])
        ineqFlagList.append(cons["ineqFlag"])
    rootList = []
    leftRootList = []
    rightRootList = []
    index = 0
    for func in funcList:

        #print(func(x0))
        #def tempFunc(t,fun,y_values):
        #   return fun(t)-y_values
        #res = scipy.optimize.leastsq([tempFunc,], [x0,], args=(func,0))
        #print(index)
        #print(func([1,19.89749639,-2.38194004]))
        def l_fun(t,fun,y_values,paraNum):
            resList = []
            try:
                res = fun(t)-y_values
            except Exception as e:
                print(t)
                raise e
            resList.append(res)
            i = 0
            while i < paraNum - 1:
                resList.append(0)
                i += 1
            return resList
        def l_fun1(t,fun,y_values):
            resList = []
            try:
                res = fun(t)-y_values
            except Exception as e:
                print(t)
                raise e
            return res*res
        #res = scipy.optimize.leastsq(lambda t,fun,y_values: [fun(t)-y_values,0,0], x0, args=(func,0))
        #print(len(x0))
        #res = scipy.optimize.least_squares(l_fun, x0, args=(func,0,paraNum))
        #print(res[0])
        res1 = scipy.optimize.minimize(l_fun1, x0, args=(func,0),bounds=bounds)
        res = [res1.x,]
        #print(res1.x)
        #exit()
        #res = optimize.root(func,x0=[x0,])
        #print(res)
        #print(func(res[0]))
        rootList.append(res[0])
        if ineqFlagList[index] == 'min':
            leftRootList.append(res[0])
        elif ineqFlagList[index] == 'max':
            rightRootList.append(res[0])
        index += 1
    minX0 = []
    index = 0
    for xEle in x0:
        minValue = 999999999
        for rootEle in rightRootList:
            if rootEle[index] < minValue:
                minValue = rootEle[index]
        minX0.append(minValue)
        index += 1
    maxX0 = []
    index = 0
    for xEle in x0:
        maxValue = -999999999
        for rootEle in leftRootList:
            if rootEle[index] > maxValue:
                maxValue = rootEle[index]
        maxX0.append(maxValue)
        index += 1
    newX0 = []
    index = 0
    for xEle in x0:
        newX0.append((maxX0[index] + minX0[index]) / 2)
        index += 1
    #print("平均值")
    #print(newX0)
    #for func in funcList:
    #   print(func(newX0))
    #exit()
    return newX0

    #print(rootList)
    index = 0
    newX0 = []
    for xEle in x0:
        total = 0
        for rootEle in rootList:
            total += rootEle[index]
        total = total / len(rootList)
        newX0.append(total)
        index += 1
    print(newX0)
    for func in funcList:
        print(func(newX0))
    exit()

# 生成rangeBound范围内的所有初始值的组合
# rangeBound 内为指数项的范围。例如[-5,2] 表示从1e-5尝试到1e2的范围, 不包含负数和0.
# paraBounds 为各个参数的取值范围.
# 若希望包含0, 则将zeroFlag设为True.
# 若希望包含负数轴的对应的范围,例如 -1e-2到-1e-5, 则将negativeFlag设为True.
# 若希望开启高精度初始值(将初始值间隔减少一半),则将highAcc设置为True
def generateX0(paraSum, rangeBound, highAcc = 1, paraBounds = None, zeroFlag = False, negativeFlag = False, notGenList = []):
    if paraSum <= 1:
        return False
    highAcc = int(highAcc)
    if highAcc <= 0 or highAcc >= 21:
        return False
    if paraBounds != None:
        if len(paraBounds) != paraSum:
            return False
    expList = []
    revExpList = []
    i = rangeBound[0]
    while i <= rangeBound[1]:
        expList.append(10**i)
        if i < rangeBound[1]:
            j = 1
            while j < highAcc:
                expList.append( (10**(i+1)) * (j / highAcc) )
                j += 1
        i += 1
    if negativeFlag == True:
        revExpList = reversed(expList)
    finExpList = []
    for x in revExpList:
        finExpList.append(-x)
    if zeroFlag == True:
        finExpList.append(0)
    for x in expList:
        finExpList.append(x)

    productList = []
    productSum = 1
    i = 0
    while i < paraSum:
        if paraBounds == None:
            productList.append(copy.deepcopy(finExpList))
        else:
            bounds = paraBounds[i]
            tempList1 = []
            #print(bounds)
            if bounds[0] != None :
                minValue = bounds[0]
                for x in finExpList:
                    if x >= minValue:
                        tempList1.append(x)
            else : 
                tempList1 = copy.deepcopy(finExpList)
            tempList2 = []
            if bounds[1] != None :
                maxValue = bounds[1]
                for x in finExpList:
                    if x <= maxValue:
                        tempList2.append(x)
            else : 
                tempList2 = copy.deepcopy(finExpList)
            tempList = [x for x in tempList1 if x in tempList2]
            productList.append(tempList)
        #print(productList[i])
        productSum = productSum * len(productList[i])
        i += 1
    print("预计生成"+str(productSum)+"组参数.")
    #exit()
    if productSum > 300000000:
        print("参数组数量过大，也许会耗时较长或者内存溢出。")


    # 生成笛卡尔积
    result = list(product(*productList))
    # 若有想要排除的组合
    if notGenList != []:
        result = list(set(result) - set(notGenList))
        print("实际生成"+str(len(result))+"组参数.")
    print("参数生成完成.")
    #for x in result:
    #    print(x)
    return result

# 详细设定每一个para的暴力查找范围和设定并生成初始值
def generateX0_detail(paraSettingList, notGenList = []):
#def generateX0_detail(paraSum, rangeBound, highAcc = 1, paraBounds = None, zeroFlag = False, negativeFlag = False, notGenList = []):
    resBounds = []
    paraSum = len(paraSettingList)
    if paraSum <= 0:
        return False
    for paraSettingDict in paraSettingList:
        highAcc = paraSettingDict["acc"]
        highAcc = int(highAcc)
        if highAcc <= 0 or highAcc >= 21:
            return False

    productList = []
    productSum = 1
    for paraSettingDict in paraSettingList:
        rangeBound = paraSettingDict["range"]# = [1,5]
        bounds = paraSettingDict["bounds"]# = [10,None]
        negativeFlag = paraSettingDict["negativeFlag"]# = False
        zeroFlag = paraSettingDict["zeroFlag"]# = False
        highAcc = paraSettingDict["acc"]# = 1
        resBounds.append(bounds)
        expList = []
        revExpList = []
        i = rangeBound[0]
        while i <= rangeBound[1]:
            expList.append(10**i)
            if i < rangeBound[1]:
                j = 1
                while j < highAcc:
                    expList.append( (10**(i+1)) * (j / highAcc) )
                    j += 1
            i += 1
        if negativeFlag == True:
            revExpList = reversed(expList)
        finExpList = []
        for x in revExpList:
            finExpList.append(-x)
        if zeroFlag == True:
            finExpList.append(0)
        for x in expList:
            finExpList.append(x)

        tempList1 = []
        #print(bounds)
        if bounds[0] != None :
            minValue = bounds[0]
            for x in finExpList:
                if x >= minValue:
                    tempList1.append(x)
        else : 
            tempList1 = copy.deepcopy(finExpList)
        tempList2 = []
        if bounds[1] != None :
            maxValue = bounds[1]
            for x in finExpList:
                if x <= maxValue:
                    tempList2.append(x)
        else : 
            tempList2 = copy.deepcopy(finExpList)
        tempList = [x for x in tempList1 if x in tempList2]
        productList.append(tempList)
        productSum = productSum * len(productList[-1])
    print("预计生成"+str(productSum)+"组参数.")
    #exit()
    if productSum > 300000000:
        print("参数组数量过大，也许会耗时较长或者内存溢出。")


    # 生成笛卡尔积
    result = list(product(*productList))
    # 若有想要排除的组合
    if notGenList != []:
        result = list(set(result) - set(notGenList))
        print("实际生成"+str(len(result))+"组参数.")
    # 若有想要排除的组合
    #if notGenList != []:
    #    result = list(set(result) - set(notGenList))
    #    print("实际生成"+str(len(result))+"组参数.")
    print("参数生成完成.")
    #for x in result:
    #    print(x)
    return [result,resBounds]

# 自动探索InitValueList内提供的所有的x0. negLikelihoodFunc为似然函数的负数。
# args 与 bounds 为提供给scipy的参数
# methodsList的可选值有 ["Nelder-Mead","Powell","CG","BFGS","Newton-CG","L-BFGS-B","TNC","COBYLA","SLSQP","trust-constr","dogleg","trust-ncg","trust-krylov","trust-exact"]
def tryAllInitValue(InitValueList, negLikelihoodFunc, args, bounds, methodList = ["Nelder-Mead",], maxiter = 10000):
    resList = list()
    successFlag = False
    #timer = timeRemain.timer(len(InitValueList) * len(methodList))
    i = 1
    for methodName in methodList:
        print(methodName)
        tempFlag = False
        for x0 in InitValueList:
            #print(str(round( 100 * (i / (len(InitValueList) * len(methodList))), 3))+ "% " + str(i)+" / "+ str(len(InitValueList) * len(methodList)))
            #i += 1
            try:
                #timer.show()
                #print(negLikelihoodFunc(x0,args))
                res = scipy.optimize.minimize(fun=negLikelihoodFunc, x0=x0, args=args, method = methodName, bounds=bounds,options={'maxiter': maxiter, 'disp': False})
            except Exception as e:
                print(e)
                #exit()
                continue
                pass
            else:
                successFlag = True
                tempFlag = True
                #print(res)
                #exit()
                tempList = [res.fun,res.x,methodName]
                #print(tempList)
                resList.append(tempList)
            continue
        print(tempFlag)
    if successFlag == False:
        return False
    #print(len(resList))
    #print(resList[0])
    print("查找完成。开始对结果进行排序...")
    #exit()
    sorted_d = sorted(resList, key=lambda x: x[0])
    return sorted_d

# 从元素下标start开始从列表paraList中取batchSize个元素
def batchListEle(paraList, batchSize, start = 0):
    while start < len(paraList):
      end = min(start + batchSize, len(paraList))  # 保证不足 batchSize 个元素时取完剩余的所有元素
      batch = paraList[start:end]
      #print(batch)
      start += batchSize
      return (batch, start)

# spark 版         
# 自动探索InitValueList内提供的所有的x0. negLikelihoodFunc为似然函数的负数。
# args 与 bounds 为提供给scipy的参数
# methodsList的可选值有 ["Nelder-Mead","Powell","CG","BFGS","Newton-CG","L-BFGS-B","TNC","COBYLA","SLSQP","trust-constr","dogleg","trust-ncg","trust-krylov","trust-exact"]
# 如果开启tryMode,则会在探索到100个Success时自动停止,取100个Success里面的最优结果
def tryAllInitValue_spark(sc ,InitValueList, logLikelihoodFunc, args, bounds, methodList = ["",], trySumMode = False, tryMseModeDict = None, maxiter = 10000, debugMsg = []):
    #debug start
    if len(debugMsg) >= 2:
        debugFileName = debugMsg[1]
    start_time = time.time()  # 获取代码开始执行的时间
    #debug end

    def my_func_try(argsList):
        try:
            logLikelihoodFunc = argsList[0]
            x0 = argsList[1]
            args = argsList[2]
            methodName = argsList[3]
            bounds = argsList[4]
            maxiter = argsList[5]
            debugMsg = argsList[6]
            print("start " + methodName)
            for msg in debugMsg:
                print(msg)
            def negLikelihoodFunc(args, formatedData, meanValueFun, intensityFun):
                return -logLikelihoodFunc(args, formatedData, meanValueFun, intensityFun)
            start_time = time.time()  # 获取代码开始执行的时间
            #res = optimize.minimize(fun=negLikelihoodFunc, x0=x0, args=args, method = methodName, bounds=bounds,options={'maxiter': maxiter, 'disp': False})
            res = optimize.minimize(fun=negLikelihoodFunc, x0=x0, args=args, method = methodName, bounds=bounds)
        
        except Exception as e:
            traceback.print_exc()
            print("Fail : " + str(e))
            end_time = time.time()  # 获取代码结束执行的时间
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            print(executionTime)
            return [False,False,False,False,executionTime,argsList]
        else:
            end_time = time.time()  # 获取代码结束执行的时间
            realMseValue = 999999
            if argsList[7] == True:
                tryMseModeDict = argsList[8]
                realMseFun = tryMseModeDict["realMseFun"]
                meanValueFun = tryMseModeDict["meanValueFun"]
                testData = tryMseModeDict["testData"]
                otherArgs = tryMseModeDict["otherArgs"]
                realData = []
                estList = []
                """ # 关闭realMSE计算 （太过耗时）
                i = 1
                for Xele in testData:
                    est = meanValueFun(Xele,res.x,otherArgs)
                    estList.append(est)
                    realData.append(i)
                    i += 1
                realMseValue = realMseFun(realData,estList)
                """
                if realMseValue < 10:
                    print("成功发现还不错的结果！")
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            print("正式查找Success!")
            print(executionTime)
            return [res.fun,res.x,methodName,realMseValue,executionTime,argsList]
    paraList = []
    tryMseModeFlag = False
    if tryMseModeDict != None:
        if tryMseModeDict["status"] == True:
            tryMseModeFlag = True
    for methodName in methodList:
        tempFlag = False
        for x0 in InitValueList:
            tempList = []
            tempList.append(logLikelihoodFunc)
            tempList.append(x0)
            tempList.append(args)
            tempList.append(methodName)
            tempList.append(bounds)
            tempList.append(maxiter)
            tempList.append(debugMsg)
            if tryMseModeFlag == True :
                tempList.append(True)
                tryMseModeDict["realMseFun"] = realMSE
                tempList.append(tryMseModeDict)
            else:
                tempList.append(False)
            paraList.append(tempList)
    if trySumMode == False and tryMseModeFlag == False:

        """
        #debug start
        textContent = "发现"+str(len(paraList))+"个待计算参数列表。\n\n"
        for x in paraList:
            textContent += str(x[1])+"\n"
        sendNoticeMail(debugMsg[0]+"正式查找参数准备完成 at" +nowTime(),textContent)
        #debug end
        """
        print()
        print("开始进行探索！")
        print(paraList[0])

        #debug start
        with open(debugFileName, "a") as f:
            end_time = time.time()  # 获取代码结束执行的时间
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            f.write("v0.4\n")
            f.write("本次预准备所需时长 : "+str(executionTime)+" ms\n")
            f.write("本次探索的初始值数量 : "+str(len(paraList))+"\n")
            f.close()
        start_time = time.time()  # 获取代码开始执行的时间
        #debug end

        paraRDD = sc.parallelize(paraList)
        predictionRDD = paraRDD.map(lambda argsList: my_func_try(argsList))
        tempResList = predictionRDD.collect()

        #debug start
        with open(debugFileName, "a") as f:
            end_time = time.time()  # 获取代码结束执行的时间
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            f.write("本次探索所需时长 : "+str(executionTime)+" ms\n")
            f.close()
        start_time = time.time()  # 获取代码开始执行的时间
        #debug end


        resList = []
        executionTimeList = []
        # 去除空结果
        for res in tempResList:
            executionTimeList.append([res[0],res[4]])
            if res[0] != False:
                resList.append(res)
                #executionTimeList.append(res[3])
        #debug start

        with open(debugFileName, "a") as f:
            end_time = time.time()  # 获取代码结束执行的时间
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            f.write("本次探索时长详细 : \n")
            for estRes,exeTime in executionTimeList:
                f.write(str(estRes)+" : "+str(exeTime)+"\n")
            f.close()
        start_time = time.time()  # 获取代码开始执行的时间
        #debug end

        print("查找完成。开始对结果进行排序...")
        sorted_d = sorted(resList, key=lambda x: x[0])

        #debug start
        with open(debugFileName, "a") as f:
            end_time = time.time()  # 获取代码结束执行的时间
            executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
            f.write("本次排序所需时长 : "+str(executionTime)+" ms\n")
            f.close()
        start_time = time.time()  # 获取代码开始执行的时间
        #debug end

        return sorted_d

    if trySumMode == True and tryMseModeFlag == False:
        random.shuffle(paraList)
        start = 0
        batchSize = 160
        totalSum = batchSize
        paraListLen = len(paraList)
        resList = []
        tryList,start = batchListEle(paraList,batchSize,start)

        successCounter = len(resList)
        # 获取当前运行文件所在目录的路径
        dir_path = os.path.dirname(os.path.abspath(__file__))
        now_Time = nowTime()
        print(dir_path)
        with open(dir_path + "/temp/" + now_Time + ".txt", "w") as file:
            file.write(str(successCounter))

        while totalSum < paraListLen:
            paraRDD = sc.parallelize(tryList)
            predictionRDD = paraRDD.map(lambda argsList: my_func_try(argsList))
            tempResList = predictionRDD.collect()
            # 去除空结果
            for res in tempResList:
                if res[0] != False:
                    resList.append(res)
                    successCounter = len(resList)
                    with open(dir_path + "/temp/" + now_Time + ".txt", "w") as file:
                        file.write(str(successCounter))
            if len(resList) >= 50:
                print("成功组合数已达50。查找完成。开始对结果进行排序...")
                sorted_d = sorted(resList, key=lambda x: x[0])
                return sorted_d
            tryList,start = batchListEle(paraList,batchSize,start)
            totalSum += batchSize
        sorted_d = sorted(resList, key=lambda x: x[0])
        return sorted_d

    if trySumMode == False and tryMseModeFlag == True:
        meanValueFun = tryMseModeDict["meanValueFun"]
        testData = tryMseModeDict["testData"]
        otherArgs = tryMseModeDict["otherArgs"]
        batchSize = tryMseModeDict["batchSize"]
        mseBaseLine = tryMseModeDict["mseBaseLine"]
        random.shuffle(paraList)
        start = 0
        #batchSize = 240
        totalSum = 0
        paraListLen = len(paraList)
        resList = []
        while totalSum < paraListLen:
            tryList,start = batchListEle(paraList,batchSize,start)
            paraRDD = sc.parallelize(tryList)
            predictionRDD = paraRDD.map(lambda argsList: my_func_try(argsList))
            tempResList = predictionRDD.collect()
            tempResList_noNone = []
            # 去除空结果
            for res in tempResList:
                if res[0] != False:
                    resList.append(res)
                    tempResList_noNone.append(res)
            for res in tempResList_noNone:
                realMseValue = res[3]
                if realMseValue <= mseBaseLine:
                    tryMseList = []
                    tryMseList.append(res)
                    print("已提前找到结果！")
                    return tryMseList
            #tryList,start = batchListEle(paraList,batchSize,start)
            totalSum += batchSize
        sorted_d = sorted(resList, key=lambda x: x[0])
        return sorted_d
        

def readXlsxData(fileName,dataCol = 0):
    data = xlrd.open_workbook(fileName)
    st = data.sheet_by_index(0)
    #读取一整列的数据
    timeList = [st.cell_value(i, dataCol) for i in range(0, st.nrows)]
    return timeList

def log( x ):
    numStr = '%.5e'%x
    numList = numStr.split("e")
    print(numList)
    real = round(float(numList[0]),10)
    print(real)
    exp = float(numList[-1])
    print(exp)
    res = exp * math.log(real)
    print(res)
    exit(0)

def approx(x, goal, tol = 1e-16):
    if abs(goal - x) < 1e-15:
        #print("approx yes")
        return goal - tol
    else:
        return x

# groupData 为累计值，从t=1开始
def LLF_group(groupData,args,meanValueFun):
    t = 1
    lastSum = 0
    total = 0
    #print("t=0 : "+str(meanValueFun(0,args)))
    for faultSum in groupData:

        partA = (faultSum - lastSum)
        #print("interval N : "+str(partA))
        partB = meanValueFun(t,args) - meanValueFun(t - 1,args)
        #print("intervalMeanValue = "+str(partB))
        #if partB == 0.0:
        #    partB = 1e-300
        try:
            lnPart = math.log(partB)
        except Exception as e:
            print("t : "+str(t))
            print(meanValueFun(t,args))
            print(meanValueFun(t - 1,args))
            print(partB)
            print("对数似然函数 lnPart 出错")
            raise e
        powerPart = 0
        i = 1
        while i <=  partA:
            try:
                powerPart += math.log(i)
            except Exception as e:
                print("对数似然函数 powerPart 出错")
                raise e
            i += 1
        #print("powerPart : "+str(powerPart))

        #print("tempRes:"+str((partA * lnPart) - powerPart))
        total += (partA * lnPart) - powerPart
        lastSum = faultSum
        t += 1
    #print(-meanValueFun(len(groupData),args))
    total = total - meanValueFun(len(groupData),args)
    return total

def str2List(paraStr):
    if paraStr == "False" or paraStr == 0 or paraStr == "FALSE":
        return False
    paraList = []
    strList = paraStr.split()
    strList[0] = strList[0][1:]
    strList[-1] = strList[-1][0:-1]
    for x in strList:
        try:
            if x[-1] == ',':
                x = x[:-1]
            float_x = float(x)
        except Exception as e:
            continue
        else:
            paraList.append(float_x)
    return paraList

def nowTime():
    return str(time.strftime('%Y_%m%d_%H%M_%S_',time.localtime(time.time())))

#wu.jingchi@outlook.com
#edgetyo@gmail.com
def sendNoticeMail(title, textContent = "", RECIPIENT_EMAIL_ADDRESS = "wu.jingchi@outlook.com"):
    try:
        SENDER_EMAIL_ADDRESS = 'qqq2410999202@gmail.com'
        SENDER_EMAIL_PASSWORD = 'rwtkerdrecnvhpmn'
        #RECIPIENT_EMAIL_ADDRESS = 'wu.jingchi@outlook.com'

        #SENDER_EMAIL_ADDRESS = 'wu.jingchi@outlook.com'
        #SENDER_EMAIL_PASSWORD = 'wJc19961221'
        #RECIPIENT_EMAIL_ADDRESS = 'd220580@hiroshima-u.ac.jp'
        #print("\n\n\n开始发送！！！\n开始发送！！！\n开始发送！！！\n开始发送！！！\n开始发送！！！\n\n\n")
        message = MIMEMultipart()
        message['From'] = SENDER_EMAIL_ADDRESS
        message['To'] = RECIPIENT_EMAIL_ADDRESS
        message['Subject'] = title
        body = textContent
        message.attach(MIMEText(body, 'plain'))

        smtp_server = smtplib.SMTP('smtp.gmail.com', 587)
        #smtp_server = smtplib.SMTP('smtp.office365.com', 587)
        smtp_server.starttls()
        smtp_server.login(SENDER_EMAIL_ADDRESS, SENDER_EMAIL_PASSWORD)
        text = message.as_string()
        smtp_server.sendmail(SENDER_EMAIL_ADDRESS, RECIPIENT_EMAIL_ADDRESS, text)
        #smtp_server.sendmail(SENDER_EMAIL_ADDRESS, "manga2410999202@gmail.com", text)
        smtp_server.quit()
        #print("\n\n\n成功发送！！！\n成功发送！！！\n成功发送！！！\n成功发送！！！\n成功发送！！！\n\n\n")
    except Exception as e:
        print(traceback.format_exc())
        print("邮件发送失败")

# 根据似然函数计算结果决定初始值
# sc 为spark的句柄
# logLikelihoodFun(t, DataFormat, meanValueFunction, intensityFunction(option) ) 为目标似然函数
# funArgs = [meanValueFunction, intensityFunction(option)] 为logLikelihoodFun的参数。
# paraSettingList 为可以被SRMtool.generateX0_detail()识别的同名参数
# groupDataFormat 为数据。具体格式为 groupDataFormat = [ [t1,n1], [t2,n2], ..., [tn,nN] ]
# rangeLimit 表示paraSettingList中的range参数绝对值的最大值
# accLimit 表示paraSettingList中的acc参数绝对值的最大值
# finishSum 表示探索到 finishSum 数量以上的参数时就结束程序。finishSum 为None时表示探索完全样本空间。
def findInitValue_spark(sc, logLikelihoodFun, paraSettingList, oriGroupDataFormat, rangeLimit, accLimit, finishSum, debugInfo = None,funArgs = None, scaleCoe = 0):
    start_time = time.time()  # 获取代码开始执行的时间
    if funArgs == None or funArgs == []:
        funArgs = [None,None]
    if len(funArgs) == 1:
        funArgs.append(None)
    # spark计算用函数
    def testFun(argsList):
        goalFun = argsList[0]
        args = argsList[1]
        groupDataFormat = argsList[2]
        funArgs = argsList[3]
        debugInfo = argsList[4]
        meanValueFun = funArgs[0]
        intensityFun = funArgs[1]
        basePath = debugInfo[0]
        appName = debugInfo[1]
        dataSet = debugInfo[2]
        modelName = debugInfo[3]
        print("预查找 "+modelName+" "+dataSet+" "+str(args)+" 开始计算:")
        try:
            res = -goalFun(args, groupDataFormat,meanValueFun,intensityFun)
            print(modelName+" "+dataSet+" "+str(args)+" 计算结果 : "+str(res))

            """
            # debug start
            debugMsg = argsList[4]
            debugFileName = debugMsg[0]
            debugIndex = debugMsg[1]
            with open(debugFileName, "a") as f:
                f.write(str(debugIndex)+",")
                f.close()
            # debug end
            """

            #res = -est_model.LLF(args, groupDataFormat)
            if -999999999 < res and res < 999999999:
                print("预查找Success")
                print(res)
                print(args)
                print("\n\n")
                return [res,args]
            else:
                return [False,False]
        except Exception as e:
            """
            # debug start
            debugMsg = argsList[4]
            debugFileName = debugMsg[0]
            debugIndex = debugMsg[1]
            with open(debugFileName, "a") as f:
                f.write(str(debugIndex)+",")
                f.close()
            # debug end
            """

            #exc_type, exc_value, exc_traceback = sys.exc_info()
            # print the exception message and traceback information
            #print("Exception: ", e)
            print("findInitValue_spark中spark计算用函数testFun()出错！")
            traceback.print_exc()
            print()
            #print("exc_traceback: ")
            #print(exc_traceback)
            #print("extract_tb:")
            #print(traceback.extract_tb(exc_traceback))
            return [False,False]

    # 尺度极限。组数据时用不上。时间数据时也许可用。暂时保留接口。
    scaleList = [scaleCoe,]
    """
    scaleLimit = 0
    i = 1
    while i <= scaleLimit:
        scaleList.append(-1 * i)
        scaleList.append(i)
        i += 1
    """
    scaleResList = []
    scaleParaList = []
    if debugInfo != None:
        now_time = nowTime()
        basePath = debugInfo[0]
        appName = debugInfo[1]
        dataSet = debugInfo[2]
        modelName = debugInfo[3]
        preExecutionTime = debugInfo[4]

    for nowScale in scaleList:
        # 调整数据尺度
        groupDataFormat = []
        for dataEle in oriGroupDataFormat:
            t_i = dataEle[0]
            n_i = dataEle[1] * ( 10 ** nowScale)
            groupDataFormat.append([t_i, n_i])
    
        # 初始化各类值
        tempParaSettingList = copy.deepcopy(paraSettingList)
        testFlag = True
        oldInitValueList = []
        tempResList = []
        tempParaList = []

        end_time = time.time()  # 获取代码结束执行的时间
        executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
        # debug start
        if debugInfo != None:
            debugFileName = basePath + "debug/" + now_time+appName+"("+modelName+","+dataSet+")(nowScale="+str(nowScale)+").txt"
            with open(debugFileName, "w") as f:
                f.write("outsidePreTime : "+str(preExecutionTime)+" ms\n")
                f.write("insidePreTime : "+str(executionTime)+" ms\n")
                f.write("start\n")
            f.close()
        # debug end
        start_time = time.time()  # 获取代码开始执行的时间
        
        isEerlyFinish = False
        while testFlag == True:
            initValueList,bounds = generateX0_detail(tempParaSettingList,oldInitValueList)
            
            # debug start
            if debugInfo != None:
                with open(debugFileName, "a") as f:
                    for tempParaSetting in tempParaSettingList:
                        print("paraSetting")
                        for key in tempParaSetting:
                            f.write(str(key)+" : "+str(tempParaSetting[key])+"\n")
                    """
                    initIndex = 0
                    while initIndex < 6:
                        f.write(str(initValueList[initIndex])+"\n")
                        initIndex += 1
                    """
                    end_time = time.time()  # 获取代码结束执行的时间
                    executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
                    f.write("计算尝试参数所需时长 : "+str(executionTime)+" ms\n")
                    f.write("本次尝试数量 : " + str(len(initValueList))+"\n")
                    f.close()
            # debug end


            start_time = time.time()  # 获取代码开始执行的时间
            
            oldInitValueList += initValueList
            sparkList = []
            debugIndex = 0
            for x0 in initValueList:
                tempList = []
                tempList.append(logLikelihoodFun)
                tempList.append(x0)
                tempList.append(groupDataFormat)
                tempList.append(funArgs)
                tempList.append(debugInfo)
                """
                # debug start
                if debugInfo != None:
                    tempList.append([debugFileName,debugIndex])
                    with open(debugFileName, "a") as f:
                        f.write(str(debugIndex)+" : "+str(x0)+"\n")
                        f.close()
                    debugIndex += 1
                # debug end
                """
                sparkList.append(tempList)

            """
            # debug start
            if debugInfo != None:
                with open(debugFileName, "a") as f:
                    f.write("已完成 : ")
                    f.close()
            # debug end
            """

            paraRDD = sc.parallelize(sparkList)
            predictionRDD = paraRDD.map(lambda argsList: testFun(argsList))
            tempSparkResList = predictionRDD.collect()
            resList = []
            # 去除空结果
            for res in tempSparkResList:
                if res[0] != False:
                    resList.append(res)

            # debug start
            if debugInfo != None:
                with open(debugFileName, "a") as f:
                    end_time = time.time()  # 获取代码结束执行的时间
                    executionTime = (end_time - start_time)*1000  # 计算执行准备时长，单位为毫秒
                    f.write("本次探索所需时长 : "+str(executionTime)+" ms\n")
                    f.write("本次结果发现数 : " + str(len(resList))+"\n")
                    f.write("累积结果发现数 : " + str(len(resList)+len(tempResList))+"\n\n")
                    f.close()
            # debug end
            
            if len(resList) != 0:
                # 输出结果
                # return resList
                for res in resList:
                    tempDict = dict()
                    tempDict["res"] = res[0]
                    tempDict["para"] = res[1]
                    tempDict["scaleCoe"] = scaleCoe
                    tempResList.append(tempDict)
                    tempParaList.append(res[1])
                if finishSum != None:
                    if len(tempResList) >= finishSum:
                        #scaleResList.append(tempResList)
                        #scaleParaList.append(tempParaList)
                        testFlag = False
                        isEerlyFinish = True
                        break
            if len(resList) == 0 or isEerlyFinish == False:
                #扩大范围或者精度继续查找
                nextParaSettingList = []
                for para_setting in tempParaSettingList:
                    next_para_setting = copy.deepcopy(para_setting)
                    miniRange = next_para_setting["range"][0]
                    maxRange = next_para_setting["range"][1]
                    if abs(miniRange) >= rangeLimit and abs(maxRange) >= rangeLimit:
                        acc = next_para_setting["acc"]
                        if acc < accLimit:
                            next_para_setting["acc"] = acc + 1
                        else:
                            #scaleResList.append(tempResList)
                            #scaleParaList.append(tempParaList)
                            testFlag = False
                    if abs(miniRange) < rangeLimit:
                        miniRange = miniRange - 1
                    if abs(maxRange) < rangeLimit:
                        maxRange = maxRange + 1
                    next_para_setting["range"] = [miniRange, maxRange]
                    
                    nextParaSettingList.append(next_para_setting)
                tempParaSettingList = nextParaSettingList
        # 排序
        print("预查找排序开始")
        #sorted_data = sorted(tempResList, key=itemgetter('res'), reverse=True)   
        sorted_data = sorted(tempResList, key=itemgetter('res'),)
        scaleResList.append(sorted_data)
    # 暂时 scaleLimit 锁定为0, 因此只输出 scale = 0 时的结果
    return scaleResList[0]
    return [scaleResList[0],scaleParaList[0]]

def timeDataToNonCulGroupData(timeData, endTime, intervalSum):
    intervalTime = endTime / intervalSum
    i = 1
    groupData = []
    while i <= intervalSum:
        counter = 0
        for nowTime in timeData:
            if (i-1)*intervalTime < nowTime and nowTime <= (i)*intervalTime:
                counter += 1
        groupData.append(counter)
        i += 1
    return groupData

def timeDataToCulGroupData(timeData, endTime, intervalSum):
    nonCulGroupData = timeDataToNonCulGroupData(timeData, endTime, intervalSum)
    return toCulData(nonCulGroupData)








