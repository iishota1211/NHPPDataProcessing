# 函数图像保存模块 v2.0
# 新增plotbox图像模式

# 函数图像保存模块 v1.2
# 1.根据已知函数生成图像:
#   generateFuncPlot(function,start,end,step)
# 2.根据函数离散取值生成图像:
#   showPicList(x_list,y_list)
#
# 函数图像保存模块 v1.1
# 1. generateFuncPlotByList() 新增根据点列表生成图像功能. 
# 2. 剩余时间估计代码模块化. 
# 3. 自带分割数据函数.可以将函数分割为n等份，方便分别处理.
# 4. readCutPic() 可以读取分割函数图像
# 
# 函数图像保存模块 v1.0
# 1. generateFuncPlot() 保存函数图像模块:可设置起始与结束区间，取点间隔.


import sys

from classicUtils import timeRemain
import matplotlib.pyplot as plt
#import matplotlib.rcParams as rcParams

# picPropertyDict属性:
# picPropertyDict["picTitle"] 	= string 标题
# picPropertyDict["ylabel"]		= string y轴标签
# picPropertyDict["savePicNameList"] = list 图片保存地址
def showPlotboxPicList(dataList, labelList, picPropertyDict):
	if "picTitle" in picPropertyDict:
		picTitle = picPropertyDict["picTitle"]
	else:
		picTitle = "plotbox sample"

	if "ylabel" in picPropertyDict:
		ylabel = picPropertyDict["ylabel"]
	else:
		ylabel = "Observations"

	if "dpi" in picPropertyDict:
		dpi = picPropertyDict["dpi"]
	else:
		dpi = 300

	# 创建箱型图
	fig, ax = plt.subplots()
	bplot = ax.boxplot(dataList,)

	# 给每个箱型图添加名称
	ax.set_xticklabels(labelList)

	# 添加一些图表标签
	ax.set_title(picTitle)
	ax.set_ylabel(ylabel)

	if "savePicNameList" in picPropertyDict:
		savePicNameList = picPropertyDict["savePicNameList"]
		for savePicName in savePicNameList:
			plt.savefig(savePicName, bbox_inches='tight', pad_inches=0, dpi=dpi)
	
	plt.show()


# picPropertyDict属性:
# picPropertyDict["picTitle"] 	= string 标题
# picPropertyDict["figsize"] 	= 图片大小
# picPropertyDict["xInterval"] 	= x轴间距
# picPropertyDict["yInterval"] 	= x轴间距
# picPropertyDict["lineList"] 	= lineList 辅助线列表
# picPropertyDict["xLabel"]		= x轴标签
# picPropertyDict["yLabel"]		= y轴标签
# 	lineList = [lineDict, lineDict] 
# 		lineDict["startPoint"] 	= 
# 		lineDict["endPoint"] 	= 
# 		lineDict["color"] 		= 
# 		lineDict["lineWidth"] 	= 
# 		lineDict["lineStyle"] 	=
# picPropertyDict["savePicNameList"] = list 图片保存地址
# 
# propertyList属性: 逐条线设置显示效果
# propertyList = [lineProperty,]
# 	lineProperty["type"] = #线段类型
# 	lineProperty["color"] = #线段颜色
# 	lineProperty["lineWidth"] = 
# 	lineProperty["makerSize"] = 
# 	lineProperty["lineStyle"] = 
# 	lineProperty["showPoint"] = 
# 
# 
# 显示图像
def showPicList(x_list,y_list,label_list = None,picPropertyDict = None,propertyList=[]):
	#plt.figure(dpi=1200)
	if len(x_list) != len(y_list):
		return False
	if picPropertyDict == None:
		picPropertyDict = dict()
	if "picTitle" in picPropertyDict:
		picTitle = picPropertyDict["picTitle"]
	else:
		picTitle = None
	if "figsize" in picPropertyDict:
		figsize = picPropertyDict["figsize"]
	else:
		figsize = None
	if figsize != None:
		plt.rcParams['figure.figsize'] = figsize
		#plt.figure(figsize=figsize)
	if "dpi" in picPropertyDict:
		dpi = picPropertyDict["dpi"]
	else:
		dpi = 300

	# 调节xy轴刻度间距
	ax = plt.axes()
	if "xInterval" in picPropertyDict:
		xInterval = picPropertyDict["xInterval"]
	else:
		xInterval = None
	if xInterval != None:
		x_major_locator=plt.MultipleLocator(xInterval)
		ax.xaxis.set_major_locator(x_major_locator)
	if "yInterval" in picPropertyDict:
		yInterval = picPropertyDict["yInterval"]
	else:
		yInterval = None
	if yInterval != None:
		y_major_locator=plt.MultipleLocator(yInterval)
		ax.yaxis.set_major_locator(y_major_locator)

	#plt.axis('off')
	colors = plt.rcParams["axes.prop_cycle"]()
	lineStyles = ["--","-.",":","-"]
	lineStyleCounter = 0
	# 添加辅助线
	if "lineList" in picPropertyDict:
		lineList = picPropertyDict["lineList"]
	else:
		lineList = []
	for lineDict in lineList:
		startPoint_x,startPoint_y = lineDict["startPoint"]
		endPoint_x,endPoint_y = lineDict["endPoint"]
		#print(endPoint_x)
		#print(endPoint_y)
		if "color" in lineDict:
			color = lineDict["color"]
		else:
			color = next(colors)["color"]
		if "lineWidth" in lineDict:
			lineWidth = lineDict["lineWidth"]
		else:
			lineWidth = 1.0
		lineStyle = "-"
		if "lineStyle" in lineDict:
			if lineDict["lineStyle"] == True:
				lineStyle = lineStyles[lineStyleCounter]
				lineStyleCounter += 1
				if lineStyleCounter == len(lineStyles):
					lineStyleCounter = 0
		#print("add_line")
		plt.gca().add_line(plt.Line2D((startPoint_x, endPoint_x), (startPoint_y, endPoint_y), color = color, linewidth=lineWidth,linestyle=lineStyle))
	# 绘制数据
	#colors = plt.rcParams["axes.prop_cycle"]()
	makers = ["*","o","d","^","s","1","+","x","|",]
	markerCounter = 0
	lineStyles = ["--","-.",":","-"]
	lineStyleCounter = 0
	index = 0
	while index < len(x_list):
		label = ""
		if(label_list != None):
			#print(label_list)
			#print(index)
			#print(len(x_list))
			label = label_list[index]

		#print(label)
		if propertyList == []:
			plt.plot(x_list[index], y_list[index],label=label)
		else:
			nowProperty = propertyList[index]
			#print(nowProperty)
			picType = nowProperty["type"]
			if picType == "plot":
				if "color" in nowProperty:
					color = nowProperty["color"]
				else:
					color = next(colors)["color"]
				if "lineWidth" in nowProperty:
					lineWidth = nowProperty["lineWidth"]
				else:
					lineWidth = 1.0
				if "makerSize" in nowProperty:
					makerSize = nowProperty["makerSize"]
				else:
					makerSize = lineWidth * 3
				lineStyle = "-"
				if "lineStyle" in nowProperty:
					if nowProperty["lineStyle"] == True:
						lineStyle = lineStyles[lineStyleCounter]
						lineStyleCounter += 1
						if lineStyleCounter == len(lineStyles):
							lineStyleCounter = 0
				marker = ""
				if "showPoint" in nowProperty:
					if nowProperty["showPoint"] == True:
						marker = makers[markerCounter]
						markerCounter += 1
						if markerCounter == len(makers):
							markerCounter = 0
				xyInverse = False
				if "xyInverse" in picPropertyDict:
					xyInverse = picPropertyDict["xyInverse"]
				if xyInverse == False:
					plt.plot(x_list[index], y_list[index],label=label,color=color,linewidth=lineWidth,linestyle=lineStyle,marker=marker,ms=makerSize)
				else :
					plt.plot(y_list[index], x_list[index] ,label=label,color=color,linewidth=lineWidth,linestyle=lineStyle,marker=marker,ms=makerSize)
			if picType == "bar":
				#print("bar")
				if "color" in nowProperty:
					color = nowProperty["color"]
				else:
					color = next(colors)["color"]
				if "edgecolor" in nowProperty:
					edgecolor = nowProperty["edgecolor"]
				else:
					edgecolor = color
				if "width" in nowProperty:
					width = nowProperty["width"]
				else:
					width = 0.5
				xyInverse = False
				if "xyInverse" in picPropertyDict:
					xyInverse = picPropertyDict["xyInverse"]
				if xyInverse == False:
					plt.bar(x_list[index], y_list[index],label=label, color=color, edgecolor=edgecolor, width=width )
				else:
					plt.bar(x_list[index], y_list[index], label=label, color=color, edgecolor=edgecolor, width=width,)
				
			if picType == "scatter":
				if "color" in nowProperty:
					color = nowProperty["color"]
				else:
					color = next(colors)["color"]
				if "size" in nowProperty:
					size = nowProperty["size"]
				else:
					size = None
				xyInverse = False
				if "xyInverse" in picPropertyDict:
					xyInverse = picPropertyDict["xyInverse"]
				if xyInverse == False:
					plt.scatter(x_list[index], y_list[index],label=label,color=color,s=size)
				else: 
					plt.scatter(y_list[index],x_list[index],label=label,color=color,s=size)
				
		#print(y_list[index])
		index = index + 1
	if "titleFontSize" in picPropertyDict:
		titleFontSize = picPropertyDict['titleFontSize']
	else:
		titleFontSize = 12
	plt.rcParams["font.size"] = titleFontSize
	#print("titleFontSize : "+str(titleFontSize))
	if picTitle != None:
		plt.title(picTitle, fontsize=titleFontSize)
	#else:
	#	plt.title("Title", fontsize=titleFontSize)

	if "xFontSize" in picPropertyDict:
		xFontSize = picPropertyDict['xFontSize']
	else:
		xFontSize = 12

	if "yFontSize" in picPropertyDict:
		yFontSize = picPropertyDict['yFontSize']
	else:
		yFontSize = 12

	xLabel = picPropertyDict["xLabel"]
	yLabel = picPropertyDict["yLabel"]
	plt.xlabel(xLabel,fontsize = xFontSize)  # 设置x轴标签
	plt.ylabel(yLabel,fontsize = yFontSize)  # 设置y轴标签

	plt.legend()
	if "savePicNameList" in picPropertyDict:
		savePicNameList = picPropertyDict["savePicNameList"]
	else:
		savePicNameList = []
	for savePicName in savePicNameList:
		plt.savefig(savePicName, bbox_inches='tight', pad_inches=0, dpi=dpi)
	plt.show()

# 生成函数图像
def generateFuncPlot(function,start,end,step,ifSave = False, fileName = None, ifShow = True):
	#print("开始计算函数值...")
	i = start
	totalSum = 0
	while i <= end:
		i = i + step
		totalSum = totalSum + 1
	timer = timeRemain.timer(totalSum)

	x = []
	y = []
	i = start
	timer.setOnlyLongTask(True)
	counter = 0;
	ifNav = False
	# 计算函数值
	while i <= end:
		x.append(i)
		res = function(i)
		#if(res < 0):
		#	ifNav = True
		y.append(res)
		i = i + step
		counter = counter + 1
		#timer.printTimeRemain(counter)
	if ifNav :
		print("有负数！")

	# 保存函数值
	if(ifSave):
		print("开始保存")
		f = open(fileName,'w')
		i = 0
		while i < len(x):
			f.write(str(x[i])+"	"+str(y[i])+"\n")
			i = i + 1
		f.close()
	# 显示图像预览
	if(ifShow):
		fig = plt.figure()
		ax = fig.add_subplot(111)
		ax.plot(x, y)
		plt.show()



def readCutPic(fileName, NumStart, NumEnd):
	x = []
	y = []
	i = NumStart
	scaleCoe1 = 2**(-14)
	scaleCoe2 = 2**(14)
	while i <= NumEnd:
		cut_fileName = fileName+str(i)+".txt"
		print(i)
		with open(cut_fileName, 'r') as f:
			data = f.readlines()
			for line in data:
				odom = line.split()
				x.append(scaleCoe2*float(odom[0]))
				y.append(scaleCoe1*float(odom[1]))  
		i = i + 1
	'''
	for item in x:
		print(item)
	'''
	fig = plt.figure()
	ax = fig.add_subplot(111)
	ax.plot(x, y)
	plt.show()


def cutData(dataList, n):
	if n > len(dataList):
		return False
	subDataLen = int(len(dataList)/n)
	subDataList = []
	dataCounter = 0
	while dataCounter < len(dataList):
		counter = 0
		subData = []
		while counter < subDataLen and dataCounter < len(dataList):
			subData.append(dataList[dataCounter])
			counter = counter + 1
			dataCounter = dataCounter + 1
		subDataList.append(subData)
	if len(subDataList) > n:
		subDataList[len(subDataList)-2] += subDataList[len(subDataList)-1]
		subDataList = subDataList[0:len(subDataList)-1]
	return subDataList

def generateFuncPlotByList(function,pointList,ifSave = False, fileName = None, ifShow = True):
	print("开始计算函数值...")
	totalSum = len(pointList)
	timer = timeRemain.timer(totalSum)
	counter = 0;
	y = []
	x = []
	# 计算函数值
	for xPoint in pointList:
		res = function(xPoint)
		y.append(res)
		x.append(xPoint)
		counter = counter + 1
		timer.show()
		
	# 保存函数值
	if(ifSave):
		print("开始保存")
		f = open(fileName,'w')
		i = 0
		while i < len(x):
			f.write(str(x[i])+"	"+str(y[i])+"\n")
			i = i + 1
		f.close()
	# 显示图像预览
	if(ifShow):
		fig = plt.figure()
		ax = fig.add_subplot(111)
		ax.plot(x, y)
		plt.show()
	pass


# 读取函数图像
def readFuncPlot(fileName):
	with open(fileName, 'r') as f:
		data = f.readlines()
		x = []
		y = []
		for line in data:
			odom = line.split()
			x.append(float(odom[0]))
			y.append(float(odom[1]))  
	fig = plt.figure()
	ax = fig.add_subplot(111)
	ax.plot(x, y)
	plt.show()

# 读取图像文件
def readPicFile(fileName):
	with open(fileName, 'r') as f:
		data = f.readlines()
		x = []
		y = []
		for line in data:
			odom = line.split()
			if(odom == []):
				continue
			x.append(float(odom[0]))
			y.append(float(odom[1]))  
	return [x,y]

# 显示图像
def showPic(x,y):
	fig = plt.figure()
	ax = fig.add_subplot(111)
	ax.plot(x, y)
	plt.show()


def intensityToMean(fileName):
	with open(fileName, 'r') as f:
		data = f.readlines()
		x = []
		y = []
		for line in data:
			odom = line.split()
			x.append(float(odom[0]))
			y.append(float(odom[1]))  
	new_y = []
	total_intensity = 0
	new_y.append(0)
	for intensity in y:
		total_intensity += intensity
		new_y.append(total_intensity)
	new_y.pop()
	print("开始保存")
	f = open("c_"+fileName,'w')
	i = 0
	while i < len(x):
		f.write(str(x[i])+"	"+str(new_y[i])+"\n")
		i = i + 1
	f.close()
	# 显示图像预览
	fig = plt.figure()
	ax = fig.add_subplot(111)
	ax.plot(x, new_y)
	plt.show()

