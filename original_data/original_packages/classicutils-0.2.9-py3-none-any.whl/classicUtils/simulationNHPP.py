from classicUtils import modelTool, SRMtool
import random, math, scipy

import numpy as np
from scipy import optimize
import numpy as np

# 目前实现了4种生成时间数据NHPP的方法:
#
# thinning法 	: createNHPPbyTime_ThinningForInterval	(paraList, modelDict, simulationEndTime)
# firstX0 为查找初始值
# 逆时间法 	 	: createNHPPbyTime_Inverse				(paraList, modelDict, simulationEndTime, firstX0)
# 逆时间区间法 	: createNHPPbyTime_InverExp				(paraList, modelDict, simulationEndTime)
# 在该方法中, paraList 里的 a参数 未发挥作用,会被忽略. 取代而之的是 expectN. 注意, 该值只能取整数
# 等分布法 		: createNHPPbyTime_sameDistri			(paraList, modelDict, simulationEndTime, expectN)

# 获得 0-1之间的随机值。遵循均匀分布。
def getU():
	while True:
		now = random.uniform(0, 1)
		if now != 0.0 and now != 1.0:
			return now

# 分段 thinning
def getMaxIntensityForInterval(modelDict, paraList, startTime, endTime):
	if startTime == 0.0:
		startTime = 0.000001
	intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)

	intensity2 = float(intensityFun_backup(startTime, paraList))
	intensity3 = float(intensityFun_backup(endTime, paraList))
	
	intensityList = []
	intensityList.append(intensity2)
	intensityList.append(intensity3)

	parameterBounds = []
	timeBound = [startTime, endTime]
	parameterBounds.append(timeBound)

	# 开始推参
	x0 = startTime + ((endTime-startTime)/2)
	#print("startTime : ",startTime," endTime : ",endTime," x0 : ",x0)
	res = scipy.optimize.minimize(lossFun3, x0=x0, args=(paraList,intensityFun), method = "Nelder-Mead", bounds=parameterBounds)
	
	intensityList.append(float(-res.fun))

	maxIntensity = max(intensityList)
	return maxIntensity

def createHPPForInterval(nowTime, endTime, intensity):
	timeList = []
	#nowTime = 0
	while True:
		intervalTime = -math.log(1-getU()) / intensity
		if nowTime + intervalTime > endTime:
			break
		else:
			nowTime += intervalTime
			timeList.append(float(nowTime))
	return timeList

def lossFun2(x, paraL, y, func):
	res = float(func(x[0], paraL)) - y
	if res < 0:
		#print("x : ", x, " func(x, paraL)) : ", func(x, paraL), " y :", y, " tempRes : ", res, " finRes : ", -res*1000)
		return -res*10000
	else:
		#print("x : ", x, " func(x, paraL)) : ", func(x, paraL), " y :", y, " tempRes : ", res, " finRes : ", res)
		return res

def lossFun3(time, paraList, intensityFun):
	res = -float(intensityFun(time[0],paraList))
	return res

def newLossFun1(t, paraList, startTime, meanValueFun, y):
	t = float(t)
	m1 = meanValueFun(startTime + t, paraList)
	m2 = meanValueFun(startTime, paraList)
	f = 1 - math.exp(m2 - m1)
	res = f - y


	if y > 0.5:
		if res > 0:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",res*10000)
			return res*1000000
		else:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",-res)
			return -res
	else:
		if res < 0:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",-res*10000)
		
			return -res*1000000
		else:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",res)
			return res

def newLossFun2(t, paraList, m2, meanValueFun, y):
	t = float(t)
	m1 = meanValueFun(t, paraList)
	f = m1 / m2
	res = float(f) - y
	#return abs(res)
	if y > 0.5:
		if res > 0:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",res*10000)
			return res*1000000
		else:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",-res)
			return -res
	else:
		if res < 0:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",-res*10000)
		
			return -res*1000000
		else:
			#print("t : ", t," f : ",f," y : ",y," tempRes : ",res, "finRes : ",res)
			return res

# 求 meanValueFun 的反函数
def tranToNHPP(nowTempTime, meanValueFun, paraList, initX0):
	res = optimize.minimize(lossFun2, x0 = initX0, args=(paraList, nowTempTime, meanValueFun),bounds=[[1e-15,None],], method="Nelder-Mead")
	if float(res.x[0]) == 1e-15:
		res = optimize.minimize(lossFun2, x0 = initX0, args=(paraList, nowTempTime, meanValueFun),bounds=[[None,None],], method="Nelder-Mead")
	return float(res.x[0])

# 分段 thinning
def createNHPPbyTime_ThinningForInterval(paraList, modelDict, simulationEndTime = 100000):
	intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
	partSum = 100
	intervalTime = simulationEndTime / partSum
	oldTime = 0
	nowTime = intervalTime
	counter = 0
	HPP_List = []
	intensityList = []
	totalLen = 0
	# 生成分段HPP
	while counter < partSum:
		maxIntensity = getMaxIntensityForInterval(modelDict, paraList, oldTime, nowTime) * 1.1
		intensityList.append(maxIntensity)
		HPP = createHPPForInterval(oldTime, nowTime, maxIntensity)
		HPP_List.append(HPP)
		totalLen += len(HPP)
		oldTime = nowTime
		nowTime += intervalTime
		counter += 1
	# 生成分段NHPP
	timeList_NHPP = []
	counter = 0
	while counter < partSum:
		HPP = HPP_List[counter]
		maxIntensity = intensityList[counter]
		for nowTime in HPP:
			nowIntensity = intensityFun(nowTime, paraList)
			deleteProbability = 1 - (nowIntensity / maxIntensity)
			if nowIntensity > maxIntensity:
				print("counter : ",counter)
				print("maxIntensity : ",maxIntensity)
				print("nowIntensity : ",nowIntensity)
				raise
			checkNum = getU()
			# 保留数据
			if checkNum > deleteProbability:
				timeList_NHPP.append(nowTime)
		counter += 1
	#print("totalLen : ", totalLen)
	#print(timeList_NHPP)
	#print(len(timeList_NHPP))
	return timeList_NHPP

# inverse Time-scale transformation (Method I in Lewis)
def createNHPPbyTime_Inverse(paraList, modelDict, simulationEndTime, firstX0):
	#print("createNHPPbyTime_Inverse")
	timeList = []
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	nowTempTime = 0
	intensity = 1
	counter = 1
	oldTime = firstX0
	while True:
		# 强度为 1 的事件发生时间
		intervalTime = -math.log(1-getU()) / intensity
		nowTempTime += intervalTime
		# 平均值函数为 meanValueFun 的时间发生事件
		initX0 = oldTime
		resTime = tranToNHPP(nowTempTime, meanValueFun, paraList, initX0)
		oldTime = resTime
		if resTime == 1e-15 or resTime <= 0.0:
			print("intervalTime : ",intervalTime," nowTempTime : ",nowTempTime," initX0 : ",initX0," resTime : ", resTime)	
			print("modelDict : ",modelDict)
			print("paraList : ",paraList)
			print("counter : ",counter)
			print("abs(resTime - initX0) : ",abs(resTime - initX0))
			print("firstX0 : ",firstX0)

			SRMtool.sendNoticeMail("错误","firstX0 = "+str(firstX0)+"\ncounter = "+str(counter)+" \nintervalTime = "+str(intervalTime)+"\nnowTempTime = "+str(nowTempTime)+" \nmodelDict = "+str(modelDict)+" \nparaList = " +str(paraList)+" \ninitX0 = "+str(initX0))

			raise

		#exit()
		#if counter == 1:
		#	exit()
		if resTime > simulationEndTime:
			break
		else:
			timeList.append(resTime)

			# debug
			#break
		counter += 1
	#exit()
	#print(timeList)
	#print(len(timeList))
	return timeList

# inverse Exp distriction (Method II in Lewis)
def createNHPPbyTime_InverExp(paraList, modelDict, simulationEndTime):
	#print("createNHPPbyTime_InverExp")
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	timeList = []
	oldTime = 0
	while True:
		
		
		timeBound1 = [None,None]
		timeBound2 = [1e-15,None]
		y = getU()
		#y = 0.1

		flag = False
		timeBoundList = [timeBound1, timeBound2]
		initX0List = [(simulationEndTime - oldTime)/10000, (simulationEndTime - oldTime)/500, (simulationEndTime - oldTime)/10, (simulationEndTime - oldTime)/2, oldTime * 0.1, oldTime * 0.5]
		for timeBound in timeBoundList:
			parameterBounds = []
			parameterBounds.append(timeBound)
			for initX0 in initX0List:
				res = optimize.minimize(newLossFun1, x0 = initX0, args=(paraList, oldTime, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")
				if abs((simulationEndTime - oldTime) - float(res.x[0])) <= 1e-15 or abs(initX0 - float(res.x[0])) <= 1e-15 or float(res.x[0]) <= 1e-15:
					continue
				else:
					flag = True
					break
			if flag == True:
				break
		if flag == False:
			msgStr = "initX0 = "+str((simulationEndTime - oldTime)/10000)+"\nparaList = "+str(paraList)+"\noldTime = "+str(oldTime)+"\nmodelDict = "+str(modelDict)+"\ny = "+str(y)+"\nsimulationEndTime = "+str(simulationEndTime)
			SRMtool.sendNoticeMail("反函数错误", msgStr)
			raise
		"""
		initX0 = (simulationEndTime - oldTime)/10000
		# 开始推参
		res = optimize.minimize(newLossFun1, x0 = initX0, args=(paraList, oldTime, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")
		if abs((simulationEndTime - oldTime) - float(res.x[0])) <= 1e-15 or abs(initX0 - float(res.x[0])) <= 1e-15 or abs(float(res.x[0])) <= 1e-15:
			initX0 = (simulationEndTime - oldTime)*0.5
			res = optimize.minimize(newLossFun1, x0 = initX0, args=(paraList, oldTime, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")
			if abs((simulationEndTime - oldTime) - float(res.x[0])) <= 1e-15 or abs(initX0 - float(res.x[0])) <= 1e-15 or abs(float(res.x[0])) <= 1e-15:
				msgStr = "initX0 = "+str(initX0)+"\nparaList = "+str(paraList)+"\noldTime = "+str(oldTime)+"\nmodelDict = "+str(modelDict)+"\ny = "+str(y)
				SRMtool.sendNoticeMail("反函数错误", msgStr)
				res = optimize.minimize(newLossFun1_log, x0 = initX0, args=(paraList, oldTime, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")
				raise
		"""
		oldTime += float(res.x[0])
		if oldTime < simulationEndTime:
			timeList.append(oldTime)
		else:
			break
	if timeList[-1] > simulationEndTime:
		raise
	#print(timeList)
	#print(len(timeList))
	#print("simulationEndTime : ",simulationEndTime)
	return timeList

# inverse Exp distriction (Method III in Lewis)
def createNHPPbyTime_sameDistri(paraList, modelDict, simulationEndTime, expectN):
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	resamplingSum = np.random.poisson(expectN)
	m2 = meanValueFun(simulationEndTime, paraList)
	timeList = []
	for x in range(resamplingSum):
		parameterBounds = []
		#timeBound = [1e-15,simulationEndTime]
		timeBound = [None,None]
		parameterBounds.append(timeBound)
		y = getU()
		initX0 = simulationEndTime / 2
		# 开始推参
		res = optimize.minimize(newLossFun2, x0 = initX0, args=(paraList, m2, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")	
		if float(res.x[0]) <= 0.0 or float(res.x[0]) > simulationEndTime:
			parameterBounds = []
			timeBound = [1e-15,simulationEndTime]
			parameterBounds.append(timeBound)
			res = optimize.minimize(newLossFun2, x0 = initX0, args=(paraList, m2, meanValueFun, y),bounds=parameterBounds, method="Nelder-Mead")
		if float(res.x[0]) <= 0.0 or float(res.x[0]) > simulationEndTime or float(res.x[0]) == 1e-15 or res.x[0] == 1e-15 or float(res.x[0]) == simulationEndTime or res.x[0] == simulationEndTime:
			print("initX0 : ",initX0," modelDict : ", modelDict, " paraList : ",paraList ," m2 : ",m2," y: ", y)
			SRMtool.sendNoticeMail("错误","simulationEndTime = "+str(simulationEndTime)+"\ninitX0 = "+str(initX0)+"\n modelDict = "+str(modelDict)+"\nparaList = "+str(paraList)+"\nm2 = "+str(m2)+"\ny= "+str( y))
			raise
		timeList.append(float(res.x[0]))
	sortedtimeList = sorted(timeList, key=lambda x: x)
	#print(sortedtimeList)
	#print(len(sortedtimeList))
	return sortedtimeList





































