import xlsxwriter,math,os, copy
import numpy as np
from classicUtils import reportUtilsTemplate, SRMtool, linePlot

# reportName 为保存报告的完整路径。包括目录+名称.例如 "/home/hello/spark/fileName.xlsx"

# 基础数据集信息
def saveBaseDataSet(dataSetDict, reportName):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	ws_Base = wb.add_worksheet("完整数据集基础情况")
	ws_trainBase = wb.add_worksheet("训练数据集基础情况")
	ws_testBase = wb.add_worksheet("验证数据集基础情况")
	# 保存数据
	trainBaseCol = 0
	testBaseCol = 0
	baseCol = 0
	for dataType in dataSetDict:
		if dataType == "time":
			dataTypeName = "时间"
		elif dataType == "group":
			dataTypeName = "组"
		failNumCol = 1
		failTimeCol = 0

		ws_Base.merge_range(0, baseCol, 0, baseCol+2, "完整数据", normal)
		ws_Base.write(1, baseCol, dataTypeName, normal)
		ws_Base.write(1, baseCol+1, "故障总数", normal)
		ws_Base.write(1, baseCol+2, "测试时间", normal)
		ws_Base.set_column(baseCol+2, baseCol+2, 12)

		for predInterval in dataSetDict[dataType]:
			dataNameSum = len(dataSetDict[dataType][predInterval])
			col = 0
			ws_trainBase.merge_range(0, trainBaseCol, 0, trainBaseCol+2,  "预测阶段:"+str(int(predInterval*100))+"%", normal)
			ws_trainBase.write(1, trainBaseCol, dataTypeName, normal)
			ws_trainBase.write(1, trainBaseCol+1, "故障总数", normal)
			ws_trainBase.write(1, trainBaseCol+2, "测试时间", normal)
			ws_trainBase.set_column(trainBaseCol+2, trainBaseCol+2, 12)

			ws_testBase.merge_range(0, testBaseCol, 0, testBaseCol+4, "预测阶段:"+str(int(predInterval*100))+"%", normal)
			ws_testBase.write(1, testBaseCol, dataTypeName, normal)
			ws_testBase.write(1, testBaseCol+1, "训练集故障总数", normal)
			ws_testBase.write(1, testBaseCol+2, "训练集测试时间", normal)
			ws_testBase.write(1, testBaseCol+3, "预测集故障总数", normal)
			ws_testBase.write(1, testBaseCol+4, "预测集测试时间", normal)
			ws_testBase.set_column(testBaseCol+1, testBaseCol+4, 15)

			ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName)
			# 写入训练数据
			ws.merge_range(0, col, 0, col+dataNameSum-1, "Train Data", normal)
			# 写入数据名
			trainBaseRow = 2
			testBaseRow = 2
			for dataName in dataSetDict[dataType][predInterval]:
				ws_trainBase.write(trainBaseRow, trainBaseCol, dataName, normal)
				ws_testBase.write(testBaseRow, testBaseCol, dataName, normal)
				ws.write(1, col, dataName, normal)
				culTrainData = dataSetDict[dataType][predInterval][dataName]["culTrainData"]
				culFormatedTrainData = dataSetDict[dataType][predInterval][dataName]["culFormatedTrainData"]
				# 写入基本信息
				ws_trainBase.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
				ws_trainBase.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)
				ws_testBase.write(testBaseRow, testBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
				ws_testBase.write(testBaseRow, testBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)
				# 写入数据
				row = 2
				for trainData in culTrainData:
					ws.write(row, col, trainData, normal)
					row += 1
				col += 1
				trainBaseRow += 1
				testBaseRow += 1
			# 写入测试数据
			ws.merge_range(0, col, 0, col+dataNameSum-1, "Test Data", normal)
			# 写入数据名
			testBaseRow = 2
			for dataName in dataSetDict[dataType][predInterval]:
				ws.write(1, col, dataName, normal)
				culTestData = dataSetDict[dataType][predInterval][dataName]["culTestData"]
				culFormatedTestData = dataSetDict[dataType][predInterval][dataName]["culFormatedTestData"]
				culFormatedTrainData = dataSetDict[dataType][predInterval][dataName]["culFormatedTrainData"]
				# 写入基本信息
				ws_Base.write(testBaseRow, baseCol, dataName, normal)
				if len(culFormatedTestData) > 0:
					ws_testBase.write(testBaseRow, testBaseCol+3, culFormatedTestData[-1][failNumCol] - culFormatedTrainData[-1][failNumCol], normal)
					ws_testBase.write(testBaseRow, testBaseCol+4, culFormatedTestData[-1][failTimeCol] - culFormatedTrainData[-1][failTimeCol], normal)
					ws_Base.write(testBaseRow, baseCol+1, culFormatedTestData[-1][failNumCol], normal)
					ws_Base.write(testBaseRow, baseCol+2, culFormatedTestData[-1][failTimeCol], normal)
				# 写入数据
				row = 2
				for testData in culTestData:
					ws.write(row, col, testData, normal)
					row += 1
				col += 1
				testBaseRow += 1
			trainBaseCol += 3
			testBaseCol += 5
		baseCol += 3
	wb.close()
	return reportName

# 基础估计结果
def saveEstimateBaseResult(estimateDict, reportName, dictUniName):
	# 保存数据集
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	# 保存数据
	for dataType in estimateDict:
		if dataType == "time":
			dataTypeName = "时间"
		elif dataType == "group":
			dataTypeName = "组"
		failNumCol = 1
		failTimeCol = 0
		for predInterval in estimateDict[dataType]:
			methodNameList = reportUtilsTemplate.getMethodNameList(estimateDict, dictUniName)
			for methodName in methodNameList:
				measureNameList = reportUtilsTemplate.getMeasureNameList(estimateDict, dictUniName, methodName)
				measureLen = len(measureNameList)
				ws_trainBase_diff = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"("+str(methodName)+")新")
				trainBaseCol = 0
				for dataName in estimateDict[dataType][predInterval]:
					dataDict = estimateDict[dataType][predInterval][dataName]
					# 写入估计指标
					methodLen = len(dataDict[dictUniName])
					trainBaseRow = 2
					ws_trainBase_diff.merge_range(0, trainBaseCol, 0, trainBaseCol+measureLen+3-1, dataName, normal)
					ws_trainBase_diff.write(1, trainBaseCol, "Model Type", normal)
					ws_trainBase_diff.write(1, trainBaseCol+1, "Model Name", normal)
					measureNameIndex = 1
					for measureName in measureNameList:
						ws_trainBase_diff.write(1, trainBaseCol+1+measureNameIndex, measureName, normal)
						measureNameIndex += 1
					ws_trainBase_diff.write(1, trainBaseCol+1+measureNameIndex, "estCostTime", normal)
					measureNameIndex += 1
					measureNameIndex = 1
					for measureName in measureNameList:
						trainBaseRow = 2
						for modelType in dataDict[dictUniName][methodName]:
							for modelName in dataDict[dictUniName][methodName][modelType]:
								ws_trainBase_diff.write(trainBaseRow, trainBaseCol, modelType, normal)
								ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1, modelName, normal)
								resDict = dataDict[dictUniName][methodName][modelType][modelName]
								try:
									measureValue = resDict["measureValueDict"][measureName]
									if measureValue == float("inf"):
										measureValue = "inf"
									elif measureValue == float("-inf"):
										measureValue = "-inf"
									elif isinstance(measureValue, str):
										pass
									elif isinstance(measureValue, list):
										measureValue = str(measureValue)
									elif math.isnan(measureValue):
										measureValue = "Nan"
									ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1+measureNameIndex, measureValue, numFormat)
								except Exception as e:
									print("当前状态:")
									print("methodName : "+methodName)
									print("measureNameList : "+str(measureNameList))
									print("measureName : "+measureName)
									print("measureValue : "+str(measureValue))
									raise e
								trainBaseRow += 1
						measureNameIndex += 1
					trainBaseRow = 2
					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							ws_trainBase_diff.write(trainBaseRow, trainBaseCol, modelType, normal)
							ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1, modelName, normal)
							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							try:
								estCostTime = resDict["estCostTime"]
								ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1+measureNameIndex, estCostTime, numFormat)
							except Exception as e:
								raise e
							trainBaseRow += 1

					trainBaseCol = trainBaseCol+measureLen+3
			ws_trainBase = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"旧")
			ws_trainBase_para = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"参数")
			trainBaseCol = 0
			for dataName in estimateDict[dataType][predInterval]:
				dataDict = estimateDict[dataType][predInterval][dataName]
				# 写入估计指标
				methodLen = len(dataDict[dictUniName])
				trainBaseRow = 2
				ws_trainBase.merge_range(0, trainBaseCol, 0, trainBaseCol+2*methodLen+2-1, dataName, normal)
				ws_trainBase.write(1, trainBaseCol, "Model Type", normal)
				ws_trainBase.write(1, trainBaseCol+1, "Model Name", normal)
				ws_trainBase_para.merge_range(0, trainBaseCol, 0, trainBaseCol+2*methodLen+2-1, dataName, normal)
				ws_trainBase_para.write(1, trainBaseCol, "Model Type", normal)
				ws_trainBase_para.write(1, trainBaseCol+1, "Model Name", normal)
				measureNameIndex = 1
				for methodName in dataDict[dictUniName]:
					ws_trainBase.write(1, trainBaseCol+1+measureNameIndex, methodName, normal)
					ws_trainBase_para.write(1, trainBaseCol+1+measureNameIndex, methodName, normal)
					measureNameIndex += 1
				for methodName in dataDict[dictUniName]:
					ws_trainBase.write(1, trainBaseCol+1+measureNameIndex, "MAE ("+methodName+")", normal)
					ws_trainBase_para.write(1, trainBaseCol+1+measureNameIndex, methodName+"参数", normal)
					measureNameIndex += 1

				measureNameIndex = 1
				for methodName in dataDict[dictUniName]:
					trainBaseRow = 2
					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							ws_trainBase.write(trainBaseRow, trainBaseCol, modelType, normal)
							ws_trainBase.write(trainBaseRow, trainBaseCol+1, modelName, normal)
							ws_trainBase_para.write(trainBaseRow, trainBaseCol, modelType, normal)
							ws_trainBase_para.write(trainBaseRow, trainBaseCol+1, modelName, normal)
							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							measureName = resDict["measureNameList"][0]
							measureValue = resDict["measureValueDict"][measureName]
							measureStr = str(measureValue) + " ("+measureName+")"
							measureStr = str(len(dataDict[dictUniName][methodName][modelType]))
							try:
								measureValue = float(measureValue)
								if measureValue == float("inf"):
									measureValue = "inf"
								elif measureValue == float("-inf"):
									measureValue = "-inf"
								elif isinstance(measureValue, str):
									pass
								elif isinstance(measureValue, list):
									measureValue = str(measureValue)
								elif math.isnan(measureValue):
									measureValue = "Nan"
								ws_trainBase.write(trainBaseRow, trainBaseCol+1+measureNameIndex, measureValue, numFormat)
								ws_trainBase_para.write(trainBaseRow, trainBaseCol+1+measureNameIndex, measureValue, numFormat)
							except Exception as e:
								print(measureName)
								print(measureValue)
								print(type(measureValue))
								raise e
							if "culMAE" in resDict["measureValueDict"]:
								MAE = resDict["measureValueDict"]["culMAE"]
								if MAE == float("inf"):
									MAE = "inf"
								elif MAE == float("-inf"):
									MAE = "-inf"
								elif isinstance(MAE, str):
									pass
								elif isinstance(MAE, list):
									MAE = str(MAE)
								elif math.isnan(MAE):
									MAE = "Nan"
							else:
								MAE = "False"
							paraList = resDict["paraList"]
							ws_trainBase.write(trainBaseRow, trainBaseCol+1+measureNameIndex+methodLen, MAE, numFormat)
							ws_trainBase_para.write(trainBaseRow, trainBaseCol+1+measureNameIndex+methodLen, str(paraList), normal)
							trainBaseRow += 1
					measureNameIndex += 1
				trainBaseCol = trainBaseCol+2*methodLen+2

				# 写入训练数据
				col = 0
				ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+dataName+"详情")
				ws.merge_range(0, col, 0, col+1, "Train Data", normal)
				ws.write(1, col, "Time", normal)
				ws.write(1, col+1, "Number", normal)
				culFormatedTrainData = dataDict["culFormatedTrainData"]
				culFormatedTestData = dataDict["culFormatedTestData"]
				tempFormatedData = culFormatedTrainData + culFormatedTestData
				realFailNum = culFormatedTrainData[-1][failNumCol]
				realFailTime = culFormatedTrainData[-1][failTimeCol]
				row = 2
				i = 0
				for x,y in culFormatedTrainData:
					if dataType == "time":
						ws.write(row, col, x, normal)
						ws.write(row, col+1, y, normal)
					else:
						ws.write(row, col, x, normal)
						ws.write(row, col+1, y, normal)
					i += 1
					row += 1
				col += 2
				# 写入估计值
				for methodName in dataDict[dictUniName]:
					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							estModelName = modelType+" "+modelName+" "+methodName
							ws.merge_range(0, col, 0, col+1, estModelName, normal)
							ws.write(1, col, "Time", normal)
							ws.write(1, col+1, "Number", normal)
							culFormatedEstData = resDict["culFormatedEstData"]
							culEstimationValueList = []
							for time,num in culFormatedEstData:
								culEstimationValueList.append(num)
							row = 2
							i = 0
							for x,y in culFormatedTrainData:
								if i < len(culEstimationValueList):
									est = culEstimationValueList[i]
								else:
									est = -1
								if est == float("inf"):
									est = "inf"
								elif est == float("-inf"):
									est = "-inf"
								elif isinstance(est, str):
									pass
								elif isinstance(est, list):
									est = str(est)
								elif math.isnan(est):
									est = "Nan"

								if dataType == "time":
									ws.write(row, col, x, normal)
									ws.write(row, col+1, est, numFormat)			
								else:
									ws.write(row, col, x, normal)
									ws.write(row, col+1, est, numFormat)
								row += 1
								i += 1
							col += 2
	wb.close()
	return reportName

# 最佳measureValue结果
def saveEstimateBestResult(estimateDict, reportName, dictUniName, mainMeasureOnly = True):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldFormat = reportUtilsTemplate.getBoldNumFormat(wb)
	methodNameList = reportUtilsTemplate.getMethodNameList(estimateDict, dictUniName)
	for methodName in methodNameList:
		if mainMeasureOnly == True:
			mainMeasureName = reportUtilsTemplate.getMainMeasureName(estimateDict, dictUniName, methodName)
			measureNameList = [mainMeasureName,]
		else:
			measureNameList = reportUtilsTemplate.getMeasureNameList(estimateDict, dictUniName, methodName)
		for measureName in measureNameList:
			ws = wb.add_worksheet(methodName+"指标值 ("+str(measureName)+")")
			trainBaseCol = 0
			for dataType in estimateDict:
				if dataType == "time":
					dataTypeName = "时间"
				elif dataType == "group":
					dataTypeName = "组"
				failNumCol = 1
				failTimeCol = 0
				for predInterval in estimateDict[dataType]:
					for dataName in estimateDict[dataType][predInterval]:
						modelTypeList = reportUtilsTemplate.getModelTypeList(estimateDict, dictUniName, dataType, dataName, predInterval, methodName)
						break
					ws.write(1, trainBaseCol, dataTypeName, normal)
					ws.write(1, trainBaseCol+1, "故障总数", normal)
					ws.write(1, trainBaseCol+2, "测试时间", normal)
					ws.set_column(trainBaseCol+2, trainBaseCol+2, 12)

					modelTypeCol = trainBaseCol+3
					for modelType in modelTypeList:
						#ws.write(1, modelTypeCol, "模型类别", normal)
						#ws.write(1, modelTypeCol + 1, "模型名称", normal)
						ws.write(1, modelTypeCol, modelType, normal)
						ws.write(1, modelTypeCol + 1, measureName, normal)
						modelTypeCol += 2
					ws.merge_range(0, trainBaseCol, 0, modelTypeCol - 1,  "预测阶段:"+str(int(predInterval*100))+"%", normal)
					
					trainBaseRow = 2
					for dataName in estimateDict[dataType][predInterval]:
						ws.write(trainBaseRow, trainBaseCol, dataName, normal)
						dataDict = estimateDict[dataType][predInterval][dataName]
						culFormatedTrainData = dataDict["culFormatedTrainData"]
						ws.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
						ws.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)

						modelTypeCol = trainBaseCol+3
						baselineRes = float("inf")
						boldResList = []
						for modelType in dataDict[dictUniName][methodName]:

							# 获得完整训练数据的Measure列表
							measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureListWithModelType(estimateDict, dictUniName, dataType, dataName, predInterval, methodName, measureName, modelType)
							# measureValue最小的模型的measureValue
							measureValue = measureList[0][0]
							# measureValue最小的模型的index
							miniMeasureIndex = measureList[0][1]
							# measureValue最小的模型的模型类别
							modelType = modelIndexMateList[ miniMeasureIndex ][0]
							# measureValue最小的模型的模型名称
							modelName = modelIndexMateList[ miniMeasureIndex ][1]
							# measureValue最小的模型的参数
							paraList = modelIndexMateList[ miniMeasureIndex ][2]
							# measureValue最小的模型的MAE
							MAE = modelIndexMateList[ miniMeasureIndex ][3]
							
							# 写入基本信息
							#ws.write(trainBaseRow, modelTypeCol, modelType, normal)
							ws.write(trainBaseRow, modelTypeCol, "("+modelName+")", normal)
							if measureValue == float("inf"):
								measureValue = "inf"
							elif measureValue == float("-inf"):
								measureValue = "-inf"
							elif isinstance(measureValue, str):
								pass
							elif isinstance(measureValue, list):
								measureValue = str(measureValue)
							elif math.isnan(measureValue):
								measureValue = "Nan"
							ws.write(trainBaseRow, modelTypeCol+1, measureValue, numFormat)

							# 记录加粗结果
							if isinstance(measureValue, str) == False and isinstance(measureValue, list) == False and math.isnan(measureValue) == False:
								if measureName == "LL":
									tempValue = round(-measureValue,3)
								else:
									tempValue = round(measureValue,3)

								if tempValue < baselineRes:
									baselineRes = tempValue
									boldResList = []
									boldResList.append([trainBaseRow, modelTypeCol+1, measureValue])
								elif tempValue == baselineRes:
									boldResList.append([trainBaseRow, modelTypeCol+1, measureValue])

							modelTypeCol += 2
						for trainBaseRow, modelTypeCol, measureValue in boldResList:
							ws.write(trainBaseRow, modelTypeCol, measureValue, boldFormat)
						trainBaseRow += 1
					trainBaseCol += 3 + len(modelTypeList) * 2
	wb.close()

# 基础预测结果
def savePredictBaseResult(basePredictDict, reportName, dictUniName):
	# 保存数据集
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	# 保存数据
	baseCol = 0
	for dataType in basePredictDict:
		if dataType == "time":
			dataTypeName = "时间"
		elif dataType == "group":
			dataTypeName = "组"
		for predInterval in basePredictDict[dataType]:
			ws_trainBase = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"总结")
			trainBaseCol = 0
			for dataName in basePredictDict[dataType][predInterval]:
				dataDict = basePredictDict[dataType][predInterval][dataName]
				# 写入训练数据
				col = 0
				ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+dataName+"详情")
				ws.merge_range(0, col, 0, col+1, "Test Data", normal)
				ws.write(1, col, "Time", normal)
				ws.write(1, col+1, "Number", normal)
				lastTrainData = dataDict["culFormatedTrainData"][-1]
				culFormatedTestData = dataDict["culFormatedTestData"]
				row = 2
				ws.write(row, col, lastTrainData[0], normal)
				ws.write(row, col+1, lastTrainData[1], normal)
				row += 1
				for x,y in culFormatedTestData:
					if dataType == "time":
						ws.write(row, col, x, normal)
						ws.write(row, col+1, y, normal)
					else:
						ws.write(row, col, x, normal)
						ws.write(row, col+1, y, normal)
					row += 1
				col += 2
				# 写入预测值
				for methodName in dataDict[dictUniName]:
					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							predModelName = modelType+" "+modelName+" "+methodName
							ws.merge_range(0, col, 0, col+1, predModelName, normal)
							ws.write(1, col, "Time", normal)
							ws.write(1, col+1, "Number", normal)
							culFormatedPredData = resDict["culFormatedPredData"]
							culPredValueList = []
							row = 2
							realList = []
							i = 0
							ws.write(row, col, lastTrainData[0], normal)
							ws.write(row, col+1, lastTrainData[1], normal)
							row += 1
							for x,y in culFormatedTestData:
								if i < len(culFormatedPredData):
									culPredValue = culFormatedPredData[i][1]
								else:
									culPredValue = -1

								culPredValueStr = culPredValue
								if culPredValue == float("inf"):
									culPredValueStr = "inf"
								elif culPredValue == float("-inf"):
									culPredValueStr = "-inf"
								elif isinstance(culPredValue, str):
									culPredValueStr = "str"
								elif math.isnan(culPredValue):
									culPredValueStr = "Nan"

								if dataType == "time":
									ws.write(row, col, x, normal)
									ws.write(row, col+1, culPredValueStr, numFormat)
									realList.append(y)
								else:
									ws.write(row, col, x, normal)
									ws.write(row, col+1, culPredValueStr, numFormat)
									realList.append(y)
								culPredValueList.append(culPredValue)
								row += 1
								i += 1
							# 校验PMAE用
							if len(culPredValueList) != 0 and -1 not in culPredValueList:
								if dataType == "time":
									try:
										PMAE = SRMtool.realMSE(realList, culPredValueList)
										ws.write(row, col, PMAE, numFormat)
									except Exception as e:
										PMAE = 99999999
										ws.write(row, col, PMAE, numFormat)
									
								else:
									try:
										PMAE = SRMtool.realMSE(realList, culPredValueList)
										ws.write(row, col, PMAE, numFormat)
									except Exception as e:
										PMAE = 99999999
										ws.write(row, col, PMAE, numFormat)
									
							col += 2
				# 写入预测指标
				trainBaseRow = 2
				methodNameList = reportUtilsTemplate.getMethodNameList(basePredictDict, dictUniName)
				ws_trainBase.merge_range(0, trainBaseCol, 0, trainBaseCol+len(methodNameList)+2-1, dataName, normal)
				ws_trainBase.write(1, trainBaseCol, "Model Type", normal)
				ws_trainBase.write(1, trainBaseCol+1, "Model Name", normal)
				measureNameIndex = 1
				for measureName in methodNameList:
					ws_trainBase.write(1, trainBaseCol+1+measureNameIndex, "PMAE("+measureName+")", normal)
					measureNameIndex += 1

				measureNameIndex = 1
				for methodName in dataDict[dictUniName]:
					trainBaseRow = 2
					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							ws_trainBase.write(trainBaseRow, trainBaseCol, modelType, normal)
							ws_trainBase.write(trainBaseRow, trainBaseCol+1, modelName, normal)
							PMAE = resDict["culPMAE"]
							if PMAE == 9999999:
								PMAE = "False"
							elif PMAE > 1e8:
								PMAE = "Inf"

							if PMAE == float("inf"):
								PMAE = "inf"
							elif PMAE == float("-inf"):
								PMAE = "-inf"
							elif isinstance(PMAE, str):
								PMAE = "str"
							elif math.isnan(PMAE):
								PMAE = "Nan"

							ws_trainBase.write(trainBaseRow, trainBaseCol+1+measureNameIndex, PMAE, numFormat)
							trainBaseRow += 1
					measureNameIndex += 1
				trainBaseCol = trainBaseCol+len(methodNameList)+2
	wb.close()
	return reportName

# 最小PMAE结果
def savePredictBestResult(basePredictDict, reportName, dictUniName):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	methodNameList = reportUtilsTemplate.getMethodNameList(basePredictDict, dictUniName)
	for methodName in methodNameList:
		ws = wb.add_worksheet(methodName+"的PMAE值")
		ws_para = wb.add_worksheet(methodName+"参数")
		trainBaseCol = 0
		for dataType in basePredictDict:
			if dataType == "time":
				dataTypeName = "时间"
				failTimeCol = 0
				failNumCol = 1
			elif dataType == "group":
				dataTypeName = "组"
				failTimeCol = 0
				failNumCol = 1
			for predInterval in basePredictDict[dataType]:
				ws.merge_range(0, trainBaseCol, 0, trainBaseCol+5,  "预测阶段:"+str(int(predInterval*100))+"%", normal)
				ws.write(1, trainBaseCol, dataTypeName, normal)
				ws.write(1, trainBaseCol+1, "故障总数", normal)
				ws.write(1, trainBaseCol+2, "测试时间", normal)
				ws.write(1, trainBaseCol+3, "模型类别", normal)
				ws.write(1, trainBaseCol+4, "模型名称", normal)
				ws.write(1, trainBaseCol+5, "PMAE", normal)
				ws.set_column(trainBaseCol+2, trainBaseCol+2, 12)

				ws_para.merge_range(0, trainBaseCol, 0, trainBaseCol+5,  "预测阶段:"+str(int(predInterval*100))+"%", normal)
				ws_para.write(1, trainBaseCol, dataTypeName, normal)
				ws_para.write(1, trainBaseCol+1, "故障总数", normal)
				ws_para.write(1, trainBaseCol+2, "测试时间", normal)
				ws_para.write(1, trainBaseCol+3, "模型类别", normal)
				ws_para.write(1, trainBaseCol+4, "模型名称", normal)
				ws_para.write(1, trainBaseCol+5, "参数", normal)
				ws_para.set_column(trainBaseCol+2, trainBaseCol+2, 12)

				trainBaseRow = 2
				for dataName in basePredictDict[dataType][predInterval]:
					ws.write(trainBaseRow, trainBaseCol, dataName, normal)
					ws_para.write(trainBaseRow, trainBaseCol, dataName, normal)
					dataDict = basePredictDict[dataType][predInterval][dataName]
					# 获得完整训练数据的Measure列表
					measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMiniPMAEList(basePredictDict, dataType, dataName, predInterval, methodName, dictUniName)
					# PMAE最小的模型的PMAE
					miniPMAE = measureList[0][0]
					# PMAE最小的模型的index
					miniPMAEIndex = measureList[0][1]
					# PMAE最小的模型的模型类别
					modelType = modelIndexMateList[ miniPMAEIndex ][0]
					# PMAE最小的模型的模型名称
					modelName = modelIndexMateList[ miniPMAEIndex ][1]
					# PMAE最小的模型的参数
					paraList = modelIndexMateList[ miniPMAEIndex ][2]
					culFormatedTrainData = dataDict["culFormatedTrainData"]

					if miniPMAE == float("inf"):
						miniPMAE = "inf"
					elif miniPMAE == float("-inf"):
						miniPMAE = "-inf"
					elif isinstance(miniPMAE, str):
						miniPMAE = "str"
					elif math.isnan(miniPMAE):
						miniPMAE = "Nan"

					# 写入基本信息
					ws.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
					ws.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)
					ws.write(trainBaseRow, trainBaseCol+3, modelType, normal)
					
					modelName = str(round(miniPMAE,2))+" ("+modelName+")"
					ws.write(trainBaseRow, trainBaseCol+4, modelName, normal)

					ws.write(trainBaseRow, trainBaseCol+4, modelName, normal)
					ws.write(trainBaseRow, trainBaseCol+5, miniPMAE, numFormat)

					ws_para.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
					ws_para.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)
					ws_para.write(trainBaseRow, trainBaseCol+3, modelType, normal)
					ws_para.write(trainBaseRow, trainBaseCol+4, modelName, normal)
					ws_para.write(trainBaseRow, trainBaseCol+5, str(paraList), normal)
					trainBaseRow += 1
				trainBaseCol += 6
	wb.close()

# 最佳measureValue的PMAE结果
# mainMeasureOnly 表示只显示主指标的结果
def savePredictMeasureMiniResult(basePredictDict, reportName, dictUniName, mainMeasureOnly = True):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	methodNameList = reportUtilsTemplate.getMethodNameList(basePredictDict, dictUniName)
	for methodName in methodNameList:
		if mainMeasureOnly == True:
			mainMeasureName = reportUtilsTemplate.getMainMeasureName(basePredictDict, dictUniName, methodName)
			measureNameList = [mainMeasureName,]
		else:
			measureNameList = reportUtilsTemplate.getMeasureNameList(basePredictDict, dictUniName, methodName)
		for measureName in measureNameList:
			ws = wb.add_worksheet(methodName+" ("+measureName+") 的PMAE值")
			trainBaseCol = 0
			for dataType in basePredictDict:
				if dataType == "time":
					dataTypeName = "时间"
				elif dataType == "group":
					dataTypeName = "组"
				failTimeCol = 0
				failNumCol = 1
				for predInterval in basePredictDict[dataType]:
					ws.merge_range(0, trainBaseCol, 0, trainBaseCol+6,  "预测阶段:"+str(int(predInterval*100))+"%", normal)
					ws.write(1, trainBaseCol, dataTypeName, normal)
					ws.write(1, trainBaseCol+1, "故障总数", normal)
					ws.write(1, trainBaseCol+2, "测试时间", normal)
					ws.write(1, trainBaseCol+3, "模型类别", normal)
					ws.write(1, trainBaseCol+4, "模型名称", normal)
					ws.write(1, trainBaseCol+5, measureName, normal)
					ws.write(1, trainBaseCol+6, "PMAE", normal)
					ws.set_column(trainBaseCol+2, trainBaseCol+2, 12)

					trainBaseRow = 2
					for dataName in basePredictDict[dataType][predInterval]:
						ws.write(trainBaseRow, trainBaseCol, dataName, normal)
						dataDict = basePredictDict[dataType][predInterval][dataName]
						# 获得完整训练数据的Measure列表
						measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(basePredictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName)
						# measureValue最小的模型的measureValue
						minimeasureValue = measureList[0][0]
						# measureValue最小的模型的index
						minimeasureValueIndex = measureList[0][1]
						# measureValue最小的模型的模型类别
						modelType = modelIndexMateList[ minimeasureValueIndex ][0]
						# measureValue最小的模型的模型名称
						modelName = modelIndexMateList[ minimeasureValueIndex ][1]
						# measureValue最小的模型的参数
						paraList = modelIndexMateList[ minimeasureValueIndex ][2]
						culFormatedTrainData = dataDict["culFormatedTrainData"]
						PMAE = dataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
						# 写入基本信息
						ws.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failNumCol], normal)
						ws.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failTimeCol], normal)
						ws.write(trainBaseRow, trainBaseCol+3, modelType, normal)



						if minimeasureValue == float("inf"):
							minimeasureValue = "inf"
						elif minimeasureValue == float("-inf"):
							minimeasureValue = "-inf"
						elif isinstance(minimeasureValue, str):
							pass
						elif isinstance(minimeasureValue, list):
							minimeasureValue = str(minimeasureValue)
						elif math.isnan(minimeasureValue):
							minimeasureValue = "Nan"

						if PMAE == float("inf"):
							PMAE = "inf"
						elif PMAE == float("-inf"):
							PMAE = "-inf"
						elif isinstance(PMAE, str):
							PMAE = "str"
						elif math.isnan(PMAE):
							PMAE = "Nan"

						modelName = str(round(PMAE,2))+" ("+modelName+")"
						ws.write(trainBaseRow, trainBaseCol+4, modelName, normal)
										
						ws.write(trainBaseRow, trainBaseCol+5, minimeasureValue, numFormat)
						ws.write(trainBaseRow, trainBaseCol+6, PMAE, numFormat)
						trainBaseRow += 1
					trainBaseCol += 7
	wb.close()

# 比较不同推参方法的最佳measureValue的PMAE结果
#
# uniMethodList 用于确定比较结果的对象. 
# 可以留空. 此时表示比较predictDict内所有的结果字典
# uniMethodList 可以接受以下两种格式的输入:
# 第一种:
# uniMethodList = [dictUniName, ...,]
# 此时只比较uniMethodList内的dictUniName字典之间的结果
# 第二种:
# uniMethodList = [uniMethodDict, ...,]
# uniMethodDict["dictUniName"] 		# 预测结果保存字典
# uniMethodDict["methodName"] 		# 推参方法. 留空时表示比较dictUniName下所有的推参方法
# uniMethodDict["measureName"] 		# 模型选择指标. 留空时则只考虑主指标
# uniMethodDict["nameTitle"] 		# 展示用名称 / 推参方法名称. 留空时则默认等于 "methodName (measureName)"
# 第一种输入等同于第二种输入除了dictUniName全留空的情形.
# 
# showModelName 决定是否展示具有最佳measureValue的"模型名称"(不同于"推参方法名称")
#
# baselineDict用于确定所有模型都会与之比较的对象。
# 超越baseline模型的结果会加粗。baselineDict的格式与uniMethodDict相同
#
# inOnePage = True 时会让不同预测阶段的结果都集中在同一页显示
#
# compareMode = 0 表示比较时为宽松模式，小于等于best结果就可以计数。允许存在多个相同的最佳结果
# compareMode = 1 表示比较时为严格模式，必须小于best结果才可以计数
def savePredictResultComparisonWithMeasureMiniResult(predictDict, reportName, uniMethodList = [], showModelName = True, baselineDict = None, inOnePage = False, compareMode = 1):

	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in predictDict:
		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"
		failTimeCol = 0
		failNumCol = 1

		onePageOffset_dataDetail = 0
		onePageOffset_predRes = 0
		if inOnePage == True:
			# 按照数据类别以及预测区间划分工作簿
			ws = wb.add_worksheet(dataTypeName+"(累计PMAE)")
			ws_single = wb.add_worksheet(dataTypeName+"(单日PMAE)")
			predLen = len(predictDict[dataType])
			totalCulBestList = []
			totalNonCulBestList = []
			totalCulBaselineList = []
			totalNonCulBaselineList = []

		# 记录超越baseline模型结果的平均改善(全体预测阶段)
		outBaselineCulAverImproList_totalPhase = []
		outBaselineNonCulAverImproList_totalPhase = []
		# 记录超越baseline模型结果的平均恶化(全体预测阶段)
		outBaselineCulAverWorsenList_totalPhase = []
		outBaselineNonCulAverWorsenList_totalPhase = []

		for predInterval in predictDict[dataType]:
			if inOnePage == False:
				# 按照数据类别以及预测区间划分工作簿
				ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(累计PMAE)")
				ws_single = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(单日PMAE)")
				predLen = 1
			# 写入数据集基本信息
			trainBaseCol = 0

			ws.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Testing Time", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Fault Num", normal)
			ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

			ws_single.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Testing Time", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Fault Num", normal)
			ws_single.set_column(trainBaseCol+1, trainBaseCol+1, 12)
			# 数据集序号
			dataIndex = 1
			# 数据名称所在行
			if showModelName == True:
				dataRow = 2*dataIndex-1
			else:
				dataRow = dataIndex
			# 起始列
			initCol = 3
			# 写入标题
			ws.write(0, initCol, "Data Set", normal)
			ws_single.write(0, initCol, "Data Set", normal)
			# 确认 uniMethodList 类型
			if uniMethodList == []:
				finalUniMethodList = reportUtilsTemplate.getUniNameList(predictDict,dataType,predInterval)
			else:
				finalUniMethodList = uniMethodList
			# 记录每个方法在不同数据集拿到最佳结果的次数
			bestCulCounterList = []
			bestNonCulCounterList = []
			# 记录超越baseline模型结果的次数
			outBaselineCulCounterList = []
			outBaselineNonCulCounterList = []
			# 记录低于baseline模型结果的次数
			underBaselineCulCounterList = []
			underBaselineNonCulCounterList = []
			# 记录超越baseline模型结果的平均改善(不同预测阶段)
			outBaselineCulAverImproList_diffPhase = []
			outBaselineNonCulAverImproList_diffPhase = []
			# 记录超越baseline模型结果的平均恶化(不同预测阶段)
			outBaselineCulAverWorsenList_diffPhase = []
			outBaselineNonCulAverWorsenList_diffPhase = []
			# 初始化数据集基本信息行号
			trainBaseRow = 2
			# 开始遍历数据集
			for dataName in predictDict[dataType][predInterval]:
				# 估计值非法时跳过统计
				nanFlag = False
				

				singleDataDict = predictDict[dataType][predInterval][dataName]
				
				# 查找baseline模型的结果
				baselineModelCulRes = -1
				baselineModelNonCulRes = -1
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					baselineUniName = baselineDict["dictUniName"]
					baselineMethodName = baselineDict["methodName"]
					# 模型选择指标
					baselineMeasureName = reportUtilsTemplate.getMainMeasureName(predictDict, baselineUniName, baselineMethodName)
					# 获得完整训练数据的Measure列表
					measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(predictDict, baselineUniName, dataType, dataName, predInterval, baselineMethodName, baselineMeasureName)
					# measureValue最小的模型的index
					minimeasureValueIndex = measureList[0][1]
					# measureValue最小的模型的模型类别
					modelType = modelIndexMateList[ minimeasureValueIndex ][0]
					# measureValue最小的模型的模型名称
					modelName = modelIndexMateList[ minimeasureValueIndex ][1]
					# 预测性能结果
					baselineModelCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["culPMAE"]
					baselineModelNonCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["nonCulPMAE"]
				# 待比较方法下标
				methodCol = 1
				bestCulMethodDict = None
				bestCulMethodDict_addList = []
				bestNonCulMethodDict = None
				bestNonCulMethodDict_addList = []
				boldMethodCulList = []
				boldMethodCulList_addList = []
				boldMethodNonCulList = []
				boldMethodNonCulList_addList = []
				# 逐个写入待比较方法
				for uniMethodEle in finalUniMethodList:
					# 推参方法
					methodNameList = []
					# 预测结果保存字典
					if isinstance(uniMethodEle, str):
						#print("uniMethodEle : ",uniMethodEle)
						#print(predictDict[dataType][predInterval][dataName].keys())
						dictUniName = uniMethodEle
						#print(predictDict[dataType][predInterval][dataName][dictUniName].keys())
						for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
							#print("methodName : ",methodName)
							methodNameList.append(methodName)
					elif isinstance(uniMethodEle, dict):
						dictUniName = uniMethodEle["dictUniName"]
						if "methodName" not in uniMethodEle:
							for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
								methodNameList.append(methodName)
						else:
							methodName = uniMethodEle["methodName"]
							methodNameList.append(methodName)
					else:
						raise
					for methodName in methodNameList:
						modelTypeList = reportUtilsTemplate.getModelTypeList(predictDict, dictUniName, dataType, dataName, predInterval, methodName)
						for modelType in modelTypeList:
							# 模型选择指标
							if isinstance(uniMethodEle, str):
								#print("methodName : ",methodName)
								measureName = reportUtilsTemplate.getMainMeasureNameWithModelType(predictDict, dictUniName, methodName, modelType)
							elif isinstance(uniMethodEle, dict):
								if "measureName" not in uniMethodEle:
									measureName = reportUtilsTemplate.getMainMeasureNameWithModelType(predictDict, dictUniName, methodName, modelType)
								else:
									measureName = uniMethodEle["measureName"]
							# 展示用名称 / 推参方法名称
							if isinstance(uniMethodEle, str):
								nameTitle = modelType + "-" + methodName + " (" + measureName+")"
							elif isinstance(uniMethodEle, dict):
								if "nameTitle" not in uniMethodEle:
									nameTitle = modelType + "-" + methodName + " (" + measureName+")"
								else:
									nameTitle = uniMethodEle["nameTitle"]
							# 获得完整训练数据的Measure列表
							measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureListWithModelType(predictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName, modelType)
							# measureValue最小的模型的measureValue
							minimeasureValue = measureList[0][0]
							# measureValue最小的模型的index
							minimeasureValueIndex = measureList[0][1]
							# measureValue最小的模型的模型类别
							modelType = modelIndexMateList[ minimeasureValueIndex ][0]
							# measureValue最小的模型的模型名称
							modelName = modelIndexMateList[ minimeasureValueIndex ][1]
							# measureValue最小的模型的参数
							paraList = modelIndexMateList[ minimeasureValueIndex ][2]
							# 模型的别称(用于生成报告时模型的名称显示)
							alias = modelIndexMateList[ minimeasureValueIndex ][4]
							if alias is None:
								modelNameStr = "("+modelType+"-"+modelName+")"
							else:
								modelNameStr = "("+alias+")"
							# 预测性能结果
							culPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
							nonCulPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["nonCulPMAE"]
							
							if minimeasureValue == float("inf"):
								nanFlag = True
								continue
							elif minimeasureValue == float("-inf"):
								nanFlag = True
								continue
							elif isinstance(minimeasureValue, str):
								nanFlag = True
								continue
							elif math.isnan(minimeasureValue):
								nanFlag = True
								continue


							if culPMAE == float("inf"):
								culPMAE = "inf"
								continue
							elif culPMAE == float("-inf"):
								culPMAE = "-inf"
								continue
							elif isinstance(culPMAE, str):
								culPMAE = "str"
								continue
							elif math.isnan(culPMAE):
								culPMAE = "Nan"
								continue

							# 性能指标所在行与列
							resRow = dataRow + onePageOffset_predRes
							resCol = methodCol + initCol
							# 写入 推参方法名称
							ws.write(0, resCol, nameTitle, normal)
							ws_single.write(0, resCol, nameTitle, normal)
							# 写入 预测性能指标
							ws.write(resRow, resCol, culPMAE, numFormat)
							ws_single.write(resRow, resCol, nonCulPMAE, numFormat)
							if showModelName == True:
								# 写入 模型名称
								ws.write(dataRow+1, resCol, modelNameStr, normal)
								ws_single.write(dataRow+1, resCol, modelNameStr, normal)
							# 记录 最佳模型(累计PMAE)
							if bestCulMethodDict is None:
								bestCulMethodDict = dict()
								bestCulMethodDict["row"] = resRow
								bestCulMethodDict["col"] = resCol
								bestCulMethodDict["methodCol"] = methodCol
								bestCulMethodDict["predResult"] = culPMAE
							# 更新 最佳模型(累计PMAE)
							elif round(culPMAE,2) < round(bestCulMethodDict["predResult"],2):
								bestCulMethodDict["row"] = resRow
								bestCulMethodDict["col"] = resCol
								bestCulMethodDict["methodCol"] = methodCol
								bestCulMethodDict["predResult"] = culPMAE

								for tempDict in bestCulMethodDict_addList:
									if bestCulMethodDict["predResult"] < tempDict["predResult"]:
										bestCulMethodDict_addList = []
										break
							elif compareMode == 0 and round(culPMAE,2) == round(bestCulMethodDict["predResult"],2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["methodCol"] = methodCol
								tempDict["predResult"] = culPMAE
								bestCulMethodDict_addList.append(tempDict)
							# 记录 最佳模型(单日PMAE)
							if bestNonCulMethodDict is None:
								bestNonCulMethodDict = dict()
								bestNonCulMethodDict["row"] = resRow
								bestNonCulMethodDict["col"] = resCol
								bestNonCulMethodDict["methodCol"] = methodCol
								bestNonCulMethodDict["predResult"] = nonCulPMAE
							# 更新 最佳模型(单日PMAE)
							elif round(nonCulPMAE,2) < round(bestNonCulMethodDict["predResult"],2):
								bestNonCulMethodDict["row"] = resRow
								bestNonCulMethodDict["col"] = resCol
								bestNonCulMethodDict["methodCol"] = methodCol
								bestNonCulMethodDict["predResult"] = nonCulPMAE

								for tempDict in bestNonCulMethodDict_addList:
									if bestNonCulMethodDict["predResult"] < tempDict["predResult"]:
										bestNonCulMethodDict_addList = []
										break
							elif compareMode == 0 and round(nonCulPMAE,2) == round(bestNonCulMethodDict["predResult"],2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["methodCol"] = methodCol
								tempDict["predResult"] = nonCulPMAE
								bestNonCulMethodDict_addList.append(tempDict)
							# 初始化 最佳次数计数器
							if len(bestCulCounterList) < methodCol:
								bestCulCounterList.append(0)
							if len(bestNonCulCounterList) < methodCol:
								bestNonCulCounterList.append(0)

							# 与baseline相比PMAE的平均变化
							diffCulPMAE = abs(round(baselineModelCulRes,2) - round(culPMAE,2))
							# 初始化 超越baseline模型次数计数器
							if len(outBaselineCulCounterList) < methodCol:
								if round(culPMAE,2) < round(baselineModelCulRes,2):
									outBaselineCulMethodDict = dict()
									outBaselineCulMethodDict["row"] = resRow
									outBaselineCulMethodDict["col"] = resCol
									outBaselineCulMethodDict["predResult"] = culPMAE
									boldMethodCulList.append(outBaselineCulMethodDict)
									outBaselineCulCounterList.append(1)
									underBaselineCulCounterList.append(0)
									# 记录PMAE平均改善与恶化
									outBaselineCulAverImproList_diffPhase.append(diffCulPMAE)
									outBaselineCulAverWorsenList_diffPhase.append(0)
								else:
									outBaselineCulCounterList.append(0)
									underBaselineCulCounterList.append(1)
									# 记录PMAE平均改善与恶化
									outBaselineCulAverImproList_diffPhase.append(0)
									outBaselineCulAverWorsenList_diffPhase.append(diffCulPMAE)
							# 更新 超越baseline模型次数计数器
							elif round(culPMAE,2) < round(baselineModelCulRes,2):
								outBaselineCulMethodDict = dict()
								outBaselineCulMethodDict["row"] = resRow
								outBaselineCulMethodDict["col"] = resCol
								outBaselineCulMethodDict["predResult"] = culPMAE
								boldMethodCulList.append(outBaselineCulMethodDict)
								outBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
							elif compareMode == 0 and round(culPMAE,2) == round(baselineModelCulRes,2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["predResult"] = culPMAE
								boldMethodCulList_addList.append(tempDict)
								outBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
							else:
								underBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均恶化
								outBaselineCulAverWorsenList_diffPhase[methodCol - 1] += diffCulPMAE
							# 与baseline相比PMAE的平均变化
							diffNonCulPMAE = abs(round(baselineModelNonCulRes,2) - round(nonCulPMAE,2))
							# 初始化 超越baseline模型次数计数器
							if len(outBaselineNonCulCounterList) < methodCol:
								if round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
									outBaselineNonCulMethodDict = dict()
									outBaselineNonCulMethodDict["row"] = resRow
									outBaselineNonCulMethodDict["col"] = resCol
									outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
									boldMethodNonCulList.append(outBaselineNonCulMethodDict)
									outBaselineNonCulCounterList.append(1)
									underBaselineNonCulCounterList.append(0)
									# 记录PMAE平均改善与恶化
									outBaselineNonCulAverImproList_diffPhase.append(diffNonCulPMAE)
									outBaselineNonCulAverWorsenList_diffPhase.append(0)
								else:
									outBaselineNonCulCounterList.append(0)
									underBaselineNonCulCounterList.append(1)
									# 记录PMAE平均改善与恶化
									outBaselineNonCulAverImproList_diffPhase.append(0)
									outBaselineNonCulAverWorsenList_diffPhase.append(diffNonCulPMAE)
							# 更新 超越baseline模型次数计数器
							elif round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
								outBaselineNonCulMethodDict = dict()
								outBaselineNonCulMethodDict["row"] = resRow
								outBaselineNonCulMethodDict["col"] = resCol
								outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
								boldMethodNonCulList.append(outBaselineNonCulMethodDict)
								outBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
							elif compareMode == 0 and round(nonCulPMAE,2) == round(baselineModelNonCulRes,2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["predResult"] = nonCulPMAE
								boldMethodNonCulList_addList.append(tempDict)
								outBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
							else:
								underBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均恶化
								outBaselineNonCulAverWorsenList_diffPhase[methodCol - 1] += diffNonCulPMAE
							methodCol += 1

				if nanFlag== True:
					continue

				# 最左侧写入数据集名称
				if showModelName == True:
					if onePageOffset_dataDetail == 0:
						#print("inOnePage : "+str(inOnePage))
						#print("predLen : "+str(predLen))
						#print("dataRow : "+str(dataRow))
						#print("merge_range : "+str(dataRow)+" ~ "+str(dataRow + 1 + (predLen-1)*2))
						ws.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
				else:
					if inOnePage == False:
						ws.write(dataRow, initCol, dataName, normal)
						ws_single.write(dataRow, initCol, dataName, normal)
					elif onePageOffset_dataDetail == 0:
						ws.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
				# 数据集基本信息处同样写入数据集名称
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				culFormatedTrainData = singleDataDict["culFormatedTrainData"]
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)




				# 加粗超越baseline模型的结果
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					#print("A")
					for boldMethodDict in boldMethodCulList:
						ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					for boldMethodDict in boldMethodNonCulList:
						ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					# 加粗相同结果
					if compareMode == 0:
						for boldMethodDict in boldMethodCulList_addList:
							ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
						for boldMethodDict in boldMethodNonCulList_addList:
							ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redBoldNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redBoldNum)
					# 加红相同结果
					if compareMode == 0:
						for bestMethodDict in bestCulMethodDict_addList:
							ws.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
						for bestMethodDict in bestNonCulMethodDict_addList:
							ws_single.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
				else:
					#print("B")
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redNum)
					# 加红相同结果
					if compareMode == 0:
						for bestMethodDict in bestCulMethodDict_addList:
							ws.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
						for bestMethodDict in bestNonCulMethodDict_addList:
							ws_single.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
				
				# 更新最佳次数计数器
				bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += 1
				bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += 1
				if compareMode == 0:
					bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += len(bestCulMethodDict_addList)
					bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += len(bestNonCulMethodDict_addList)
				
				# 更新数据集序号
				dataIndex += 1
				# 更新数据名称所在行
				if showModelName == True:
					if inOnePage == False:
						dataRow = 2*dataIndex-1
					else:
						#dataRow_old = dataRow
						dataRow += predLen*2
						#print("updata dataRow: "+str(dataRow_old)+" -> "+str(dataRow))
				else:
					if inOnePage == False:
						dataRow = dataIndex
					else:
						dataRow += predLen
				# 更新数据集基本信息行号
				trainBaseRow += 1


			
				

			# 写入最佳次数
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, bestCulCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, bestNonCulCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineCulCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineNonCulCounter, normal)
					i += 1

			# 写入不同预测阶段平均改善误差
			ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			i = 1
			for outCulCounter in outBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverImproList_diffPhase[i-1]
				if outCulCounter == 0:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, round(diffCulPMAEinTestingPhase / outCulCounter,2), normal)
				i += 1
			i = 1
			for outNonCulCounter in outBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverImproList_diffPhase[i-1]
				if outNonCulCounter == 0:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, round( diffNonCulPMAEinTestingPhase / outNonCulCounter,3), normal)
				i += 1

			# 写入不同预测阶段平均恶化误差
			ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			i = 1
			for underCulCounter in underBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverWorsenList_diffPhase[i-1]
				if underCulCounter == 0:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round(diffCulPMAEinTestingPhase / underCulCounter,2), normal)
				i += 1
			i = 1
			for underNonCulCounter in underBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverWorsenList_diffPhase[i-1]
				if underNonCulCounter == 0:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round( diffNonCulPMAEinTestingPhase / underNonCulCounter,3), normal)
				i += 1


			if inOnePage == True:
				onePageOffset_dataDetail += trainBaseRow
				onePageOffset_predRes += 1
				totalCulBestList.append(bestCulCounterList)
				totalNonCulBestList.append(bestNonCulCounterList)
				totalCulBaselineList.append(outBaselineCulCounterList)
				totalNonCulBaselineList.append(outBaselineNonCulCounterList)

		# 写入总体平均改善误差


		# 写入总体平均恶化误差


		# 记录总和
		if inOnePage == True:
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalCulBestList[j][i-1]
					j += 1
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, totalCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalNonCulBestList[j][i-1]
					j += 1
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, totalCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalCulBaselineList[j][i-1]
						j += 1
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalNonCulBaselineList[j][i-1]
						j += 1
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1


	wb.close()

# 相同模型不同推参方法的PMAE结果比较
#
# uniMethodList 用于确定比较结果的对象. 
# 可以留空. 此时表示比较predictDict内所有的结果字典
# uniMethodList 可以接受以下两种格式的输入:
# 第一种:
# uniMethodList = [dictUniName, ...,]
# 此时只比较uniMethodList内的dictUniName字典之间的结果
# 第二种:
# uniMethodList = [uniMethodDict, ...,]
# uniMethodDict["dictUniName"] 		# 预测结果保存字典
# uniMethodDict["methodName"] 		# 推参方法. 留空时表示比较dictUniName下所有的推参方法
# uniMethodDict["measureName"] 		# 模型选择指标. 留空时则只考虑主指标
# uniMethodDict["nameTitle"] 		# 展示用名称 / 推参方法名称. 留空时则默认等于 "methodName (measureName)"
# 第一种输入等同于第二种输入除了dictUniName全留空的情形.
# 
# showModelName 决定是否展示具有最佳measureValue的"模型名称"(不同于"推参方法名称")
#
# baselineDict用于确定所有模型都会与之比较的对象。
# 超越baseline模型的结果会加粗。baselineDict的格式与uniMethodDict相同
#
# inOnePage = True 时会让不同预测阶段的结果都集中在同一页显示
#
# compareMode = 0 表示比较时为宽松模式，小于等于best结果就可以计数。允许存在多个相同的最佳结果
# compareMode = 1 表示比较时为严格模式，必须小于best结果才可以计数
def savePredictResultComparisonWithDiffModels(predictDict, reportName, uniMethodList = [], showModelName = True, baselineDict = None, compareMode = 1):
	inOnePage = False

	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in predictDict:
		if dataType == "time":
			dataTypeName = "T"
		elif dataType == "group":
			dataTypeName = "G"
		failTimeCol = 0
		failNumCol = 1

		onePageOffset_dataDetail = 0
		onePageOffset_predRes = 0

		# 记录超越baseline模型结果的平均改善(全体预测阶段)
		outBaselineCulAverImproList_totalPhase = []
		outBaselineNonCulAverImproList_totalPhase = []
		# 记录超越baseline模型结果的平均恶化(全体预测阶段)
		outBaselineCulAverWorsenList_totalPhase = []
		outBaselineNonCulAverWorsenList_totalPhase = []

		for predInterval in predictDict[dataType]:

			# 获取所有的模型列表
			finalUniMethodList = reportUtilsTemplate.getUniNameList(predictDict,dataType,predInterval)
			modelList = reportUtilsTemplate.getModelList(predictDict, finalUniMethodList, dataType, predInterval)
			#print(modelList)
			for modelDict in modelList:
				nowModelType = modelDict["modelType"]
				nowModelName = modelDict["modelName"]

				modelStr = nowModelType + "-" + nowModelName

				if inOnePage == False:
					# 按照数据类别以及预测区间划分工作簿
					ws = wb.add_worksheet(modelStr+str(int(predInterval*100))+"%"+dataTypeName+"(累PMAE")
					ws_single = wb.add_worksheet(modelStr+str(int(predInterval*100))+"%"+dataTypeName+"(单PMAE")
					predLen = 1
				# 写入数据集基本信息
				trainBaseCol = 0

				ws.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
				ws.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
				ws.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Testing Time", normal)
				ws.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Fault Num", normal)
				ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

				ws_single.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
				ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
				ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Testing Time", normal)
				ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Fault Num", normal)
				ws_single.set_column(trainBaseCol+1, trainBaseCol+1, 12)
				# 数据集序号
				dataIndex = 1
				# 数据名称所在行
				if showModelName == True:
					dataRow = 2*dataIndex-1
				else:
					dataRow = dataIndex
				# 起始列
				initCol = 3
				# 写入标题
				ws.write(0, initCol, "Data Set", normal)
				ws_single.write(0, initCol, "Data Set", normal)
				# 确认 uniMethodList 类型
				if uniMethodList == []:
					finalUniMethodList = reportUtilsTemplate.getUniNameList(predictDict,dataType,predInterval)
				else:
					finalUniMethodList = uniMethodList
				# 记录每个方法在不同数据集拿到最佳结果的次数
				bestCulCounterList = []
				bestNonCulCounterList = []
				# 记录超越baseline模型结果的次数
				outBaselineCulCounterList = []
				outBaselineNonCulCounterList = []
				# 记录低于baseline模型结果的次数
				underBaselineCulCounterList = []
				underBaselineNonCulCounterList = []
				# 记录超越baseline模型结果的平均改善(不同预测阶段)
				outBaselineCulAverImproList_diffPhase = []
				outBaselineNonCulAverImproList_diffPhase = []
				# 记录超越baseline模型结果的平均恶化(不同预测阶段)
				outBaselineCulAverWorsenList_diffPhase = []
				outBaselineNonCulAverWorsenList_diffPhase = []
				# 初始化数据集基本信息行号
				trainBaseRow = 2
				# 开始遍历数据集
				for dataName in predictDict[dataType][predInterval]:
					# 估计值非法时跳过统计
					nanFlag = False
					

					singleDataDict = predictDict[dataType][predInterval][dataName]
					
					# 查找baseline模型的结果
					baselineModelCulRes = -1
					baselineModelNonCulRes = -1
					if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
						baselineUniName = baselineDict["dictUniName"]
						baselineMethodName = baselineDict["methodName"]
						# 预测性能结果
						baselineModelCulRes = singleDataDict[baselineUniName][baselineMethodName][nowModelType][nowModelName]["culPMAE"]
						baselineModelNonCulRes = singleDataDict[baselineUniName][baselineMethodName][nowModelType][nowModelName]["nonCulPMAE"]
					# 待比较方法下标
					methodCol = 1
					bestCulMethodDict = None
					bestCulMethodDict_addList = []
					bestNonCulMethodDict = None
					bestNonCulMethodDict_addList = []
					boldMethodCulList = []
					boldMethodCulList_addList = []
					boldMethodNonCulList = []
					boldMethodNonCulList_addList = []
					# 逐个写入待比较方法
					for uniMethodEle in finalUniMethodList:
						# 推参方法
						methodNameList = []
						# 预测结果保存字典
						if isinstance(uniMethodEle, str):
							#print("uniMethodEle : ",uniMethodEle)
							#print(predictDict[dataType][predInterval][dataName].keys())
							dictUniName = uniMethodEle
							#print(predictDict[dataType][predInterval][dataName][dictUniName].keys())
							for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
								#print("methodName : ",methodName)
								methodNameList.append(methodName)
						elif isinstance(uniMethodEle, dict):
							dictUniName = uniMethodEle["dictUniName"]
							if "methodName" not in uniMethodEle:
								for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
									methodNameList.append(methodName)
							else:
								methodName = uniMethodEle["methodName"]
								methodNameList.append(methodName)
						else:
							raise
						for methodName in methodNameList:
							# 模型选择指标
							if isinstance(uniMethodEle, str):
								#print("methodName : ",methodName)
								measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
							elif isinstance(uniMethodEle, dict):
								if "measureName" not in uniMethodEle:
									measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
								else:
									measureName = uniMethodEle["measureName"]
							# 展示用名称 / 推参方法名称
							if isinstance(uniMethodEle, str):
								nameTitle = methodName + " ("+measureName+")"
							elif isinstance(uniMethodEle, dict):
								if "nameTitle" not in uniMethodEle:
									nameTitle = methodName + " ("+measureName+")"
								else:
									nameTitle = uniMethodEle["nameTitle"]

							modelNameStr = "("+nowModelType+"-"+nowModelName+")"
							# 预测性能结果
							minimeasureValue = singleDataDict[dictUniName][methodName][nowModelType][nowModelName]["measureValueDict"][measureName]
							culPMAE = singleDataDict[dictUniName][methodName][nowModelType][nowModelName]["culPMAE"]
							nonCulPMAE = singleDataDict[dictUniName][methodName][nowModelType][nowModelName]["nonCulPMAE"]
							
							if minimeasureValue == float("inf"):
								nanFlag = True
								continue
							elif minimeasureValue == float("-inf"):
								nanFlag = True
								continue
							elif isinstance(minimeasureValue, str):
								nanFlag = True
								continue
							elif math.isnan(minimeasureValue):
								nanFlag = True
								continue


							if culPMAE == float("inf"):
								culPMAE = "inf"
								continue
							elif culPMAE == float("-inf"):
								culPMAE = "-inf"
								continue
							elif isinstance(culPMAE, str):
								culPMAE = "str"
								continue
							elif math.isnan(culPMAE):
								culPMAE = "Nan"
								continue

							# 性能指标所在行与列
							resRow = dataRow + onePageOffset_predRes
							resCol = methodCol + initCol
							# 写入 推参方法名称
							ws.write(0, resCol, nameTitle, normal)
							ws_single.write(0, resCol, nameTitle, normal)
							# 写入 预测性能指标
							ws.write(resRow, resCol, culPMAE, numFormat)
							ws_single.write(resRow, resCol, nonCulPMAE, numFormat)
							if showModelName == True:
								# 写入 模型名称
								ws.write(dataRow+1, resCol, modelNameStr, normal)
								ws_single.write(dataRow+1, resCol, modelNameStr, normal)
							# 记录 最佳模型(累计PMAE)
							if bestCulMethodDict is None:
								bestCulMethodDict = dict()
								bestCulMethodDict["row"] = resRow
								bestCulMethodDict["col"] = resCol
								bestCulMethodDict["methodCol"] = methodCol
								bestCulMethodDict["predResult"] = culPMAE
							# 更新 最佳模型(累计PMAE)
							elif round(culPMAE,2) < round(bestCulMethodDict["predResult"],2):
								bestCulMethodDict["row"] = resRow
								bestCulMethodDict["col"] = resCol
								bestCulMethodDict["methodCol"] = methodCol
								bestCulMethodDict["predResult"] = culPMAE

								for tempDict in bestCulMethodDict_addList:
									if bestCulMethodDict["predResult"] < tempDict["predResult"]:
										bestCulMethodDict_addList = []
										break
							elif compareMode == 0 and round(culPMAE,2) == round(bestCulMethodDict["predResult"],2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["methodCol"] = methodCol
								tempDict["predResult"] = culPMAE
								bestCulMethodDict_addList.append(tempDict)
							# 记录 最佳模型(单日PMAE)
							if bestNonCulMethodDict is None:
								bestNonCulMethodDict = dict()
								bestNonCulMethodDict["row"] = resRow
								bestNonCulMethodDict["col"] = resCol
								bestNonCulMethodDict["methodCol"] = methodCol
								bestNonCulMethodDict["predResult"] = nonCulPMAE
							# 更新 最佳模型(单日PMAE)
							elif round(nonCulPMAE,2) < round(bestNonCulMethodDict["predResult"],2):
								bestNonCulMethodDict["row"] = resRow
								bestNonCulMethodDict["col"] = resCol
								bestNonCulMethodDict["methodCol"] = methodCol
								bestNonCulMethodDict["predResult"] = nonCulPMAE

								for tempDict in bestNonCulMethodDict_addList:
									if bestNonCulMethodDict["predResult"] < tempDict["predResult"]:
										bestNonCulMethodDict_addList = []
										break
							elif compareMode == 0 and round(nonCulPMAE,2) == round(bestNonCulMethodDict["predResult"],2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["methodCol"] = methodCol
								tempDict["predResult"] = nonCulPMAE
								bestNonCulMethodDict_addList.append(tempDict)
							# 初始化 最佳次数计数器
							if len(bestCulCounterList) < methodCol:
								bestCulCounterList.append(0)
							if len(bestNonCulCounterList) < methodCol:
								bestNonCulCounterList.append(0)

							# 与baseline相比PMAE的平均变化
							diffCulPMAE = abs(round(baselineModelCulRes,2) - round(culPMAE,2))
							# 初始化 超越baseline模型次数计数器
							if len(outBaselineCulCounterList) < methodCol:
								if round(culPMAE,2) < round(baselineModelCulRes,2):
									outBaselineCulMethodDict = dict()
									outBaselineCulMethodDict["row"] = resRow
									outBaselineCulMethodDict["col"] = resCol
									outBaselineCulMethodDict["predResult"] = culPMAE
									boldMethodCulList.append(outBaselineCulMethodDict)
									outBaselineCulCounterList.append(1)
									underBaselineCulCounterList.append(0)
									# 记录PMAE平均改善与恶化
									outBaselineCulAverImproList_diffPhase.append(diffCulPMAE)
									outBaselineCulAverWorsenList_diffPhase.append(0)
								else:
									outBaselineCulCounterList.append(0)
									underBaselineCulCounterList.append(1)
									# 记录PMAE平均改善与恶化
									outBaselineCulAverImproList_diffPhase.append(0)
									outBaselineCulAverWorsenList_diffPhase.append(diffCulPMAE)
							# 更新 超越baseline模型次数计数器
							elif round(culPMAE,2) < round(baselineModelCulRes,2):
								outBaselineCulMethodDict = dict()
								outBaselineCulMethodDict["row"] = resRow
								outBaselineCulMethodDict["col"] = resCol
								outBaselineCulMethodDict["predResult"] = culPMAE
								boldMethodCulList.append(outBaselineCulMethodDict)
								outBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
							elif compareMode == 0 and round(culPMAE,2) == round(baselineModelCulRes,2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["predResult"] = culPMAE
								boldMethodCulList_addList.append(tempDict)
								outBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
							else:
								underBaselineCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均恶化
								outBaselineCulAverWorsenList_diffPhase[methodCol - 1] += diffCulPMAE
							# 与baseline相比PMAE的平均变化
							diffNonCulPMAE = abs(round(baselineModelNonCulRes,2) - round(nonCulPMAE,2))
							# 初始化 超越baseline模型次数计数器
							if len(outBaselineNonCulCounterList) < methodCol:
								if round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
									outBaselineNonCulMethodDict = dict()
									outBaselineNonCulMethodDict["row"] = resRow
									outBaselineNonCulMethodDict["col"] = resCol
									outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
									boldMethodNonCulList.append(outBaselineNonCulMethodDict)
									outBaselineNonCulCounterList.append(1)
									underBaselineNonCulCounterList.append(0)
									# 记录PMAE平均改善与恶化
									outBaselineNonCulAverImproList_diffPhase.append(diffNonCulPMAE)
									outBaselineNonCulAverWorsenList_diffPhase.append(0)
								else:
									outBaselineNonCulCounterList.append(0)
									underBaselineNonCulCounterList.append(1)
									# 记录PMAE平均改善与恶化
									outBaselineNonCulAverImproList_diffPhase.append(0)
									outBaselineNonCulAverWorsenList_diffPhase.append(diffNonCulPMAE)
							# 更新 超越baseline模型次数计数器
							elif round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
								outBaselineNonCulMethodDict = dict()
								outBaselineNonCulMethodDict["row"] = resRow
								outBaselineNonCulMethodDict["col"] = resCol
								outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
								boldMethodNonCulList.append(outBaselineNonCulMethodDict)
								outBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
							elif compareMode == 0 and round(nonCulPMAE,2) == round(baselineModelNonCulRes,2):
								tempDict = dict()
								tempDict["row"] = resRow
								tempDict["col"] = resCol
								tempDict["predResult"] = nonCulPMAE
								boldMethodNonCulList_addList.append(tempDict)
								outBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均改善
								outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
							else:
								underBaselineNonCulCounterList[methodCol - 1] += 1
								# 记录PMAE平均恶化
								outBaselineNonCulAverWorsenList_diffPhase[methodCol - 1] += diffNonCulPMAE
							methodCol += 1

					if nanFlag== True:
						continue

					# 最左侧写入数据集名称
					if showModelName == True:
						if onePageOffset_dataDetail == 0:
							#print("inOnePage : "+str(inOnePage))
							#print("predLen : "+str(predLen))
							#print("dataRow : "+str(dataRow))
							#print("merge_range : "+str(dataRow)+" ~ "+str(dataRow + 1 + (predLen-1)*2))
							ws.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
							ws_single.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
					else:
						if inOnePage == False:
							ws.write(dataRow, initCol, dataName, normal)
							ws_single.write(dataRow, initCol, dataName, normal)
						elif onePageOffset_dataDetail == 0:
							ws.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
							ws_single.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
					# 数据集基本信息处同样写入数据集名称
					ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
					ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
					culFormatedTrainData = singleDataDict["culFormatedTrainData"]
					ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
					ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
					ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
					ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)




					# 加粗超越baseline模型的结果
					if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
						#print("A")
						for boldMethodDict in boldMethodCulList:
							ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
						for boldMethodDict in boldMethodNonCulList:
							ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
						# 加粗相同结果
						if compareMode == 0:
							for boldMethodDict in boldMethodCulList_addList:
								ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
							for boldMethodDict in boldMethodNonCulList_addList:
								ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
						# 加红同一数据集下的最佳结果
						ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redBoldNum)
						ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redBoldNum)
						# 加红相同结果
						if compareMode == 0:
							for bestMethodDict in bestCulMethodDict_addList:
								ws.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
							for bestMethodDict in bestNonCulMethodDict_addList:
								ws_single.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
					else:
						#print("B")
						# 加红同一数据集下的最佳结果
						ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redNum)
						ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redNum)
						# 加红相同结果
						if compareMode == 0:
							for bestMethodDict in bestCulMethodDict_addList:
								ws.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
							for bestMethodDict in bestNonCulMethodDict_addList:
								ws_single.write(bestMethodDict["row"], bestMethodDict["col"], bestMethodDict["predResult"], redBoldNum)
					
					# 更新最佳次数计数器
					bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += 1
					bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += 1
					if compareMode == 0:
						bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += len(bestCulMethodDict_addList)
						bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += len(bestNonCulMethodDict_addList)
					
					# 更新数据集序号
					dataIndex += 1
					# 更新数据名称所在行
					if showModelName == True:
						if inOnePage == False:
							dataRow = 2*dataIndex-1
						else:
							#dataRow_old = dataRow
							dataRow += predLen*2
							#print("updata dataRow: "+str(dataRow_old)+" -> "+str(dataRow))
					else:
						if inOnePage == False:
							dataRow = dataIndex
						else:
							dataRow += predLen
					# 更新数据集基本信息行号
					trainBaseRow += 1


				
					

				# 写入最佳次数
				ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
				ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
				i = 1
				for bestCulCounter in bestCulCounterList:
					ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, bestCulCounter, normal)
					i += 1
				i = 1
				for bestNonCulCounter in bestNonCulCounterList:
					ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, bestNonCulCounter, normal)
					i += 1

				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
					i = 1
					for outBaselineCulCounter in outBaselineCulCounterList:
						ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineCulCounter, normal)
						i += 1
					i = 1
					for outBaselineNonCulCounter in outBaselineNonCulCounterList:
						ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineNonCulCounter, normal)
						i += 1

				# 写入不同预测阶段平均改善误差
				ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
				ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
				i = 1
				for outCulCounter in outBaselineCulCounterList:
					diffCulPMAEinTestingPhase = outBaselineCulAverImproList_diffPhase[i-1]
					if outCulCounter == 0:
						ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, -1, normal)
					else:
						ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, round(diffCulPMAEinTestingPhase / outCulCounter,2), normal)
					i += 1
				i = 1
				for outNonCulCounter in outBaselineNonCulCounterList:
					diffNonCulPMAEinTestingPhase = outBaselineNonCulAverImproList_diffPhase[i-1]
					if outNonCulCounter == 0:
						ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, -1, normal)
					else:
						ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, round( diffNonCulPMAEinTestingPhase / outNonCulCounter,3), normal)
					i += 1

				# 写入不同预测阶段平均恶化误差
				ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
				ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
				i = 1
				for underCulCounter in underBaselineCulCounterList:
					diffCulPMAEinTestingPhase = outBaselineCulAverWorsenList_diffPhase[i-1]
					if underCulCounter == 0:
						ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
					else:
						ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round(diffCulPMAEinTestingPhase / underCulCounter,2), normal)
					i += 1
				i = 1
				for underNonCulCounter in underBaselineNonCulCounterList:
					diffNonCulPMAEinTestingPhase = outBaselineNonCulAverWorsenList_diffPhase[i-1]
					if underNonCulCounter == 0:
						ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
					else:
						ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round( diffNonCulPMAEinTestingPhase / underNonCulCounter,3), normal)
					i += 1

	wb.close()
# 输出所有的推参计算时间
def saveEstimationCostTimeResult(estDict, reportName, dictUniName):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in estDict:

		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"

		failTimeCol = 0
		failNumCol = 1

		for predInterval in estDict[dataType]:
			# 按照数据类别以及预测区间划分工作簿
			ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(推参时间)")
			predLen = 1
			# 写入数据集基本信息
			trainBaseCol = 0

			ws.merge_range(0, trainBaseCol, 0, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws.write(1, trainBaseCol, dataTypeName, normal)
			ws.write(1, trainBaseCol+2, "Total Testing Time", normal)
			ws.write(1, trainBaseCol+1, "Total Fault Num", normal)
			ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

			# 数据起始列
			initCol = 3
			# 数据集序号
			dataIndex = 1
			# 数据名称所在行
			dataRow = dataIndex + 1
			# 推参方法名称所在行
			methodRow = 0
			# 模型名称所在行
			modelRow = 1
			# 写入标题
			ws.write(dataRow - 1, initCol, "Data Set", normal)
			# 初始化数据集基本信息行号
			trainBaseRow = 2
			# 首次写入方法名称
			fristWrite = True
			# 开始遍历数据集
			for dataName in estDict[dataType][predInterval]:
				# 模型名称所在列
				modelCol = initCol + 1
				singleDataDict = estDict[dataType][predInterval][dataName]
				ws.write(dataRow, initCol, dataName, normal)
				# 数据集基本信息处同样写入数据集名称
				ws.write(trainBaseRow, trainBaseCol, dataName, normal)
				culFormatedTrainData = singleDataDict["culFormatedTrainData"]
				ws.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
				for methodName in singleDataDict[dictUniName]:
					nowModelCol = modelCol
					try:
						measureName = reportUtilsTemplate.getMainMeasureName(estDict, dictUniName, methodName)
					except Exception as e:
						print("now : " + str(methodName))
						for x in singleDataDict[dictUniName]:
							print(x)
						raise e
					
					nameTitle = methodName + " ("+measureName+")"
					# 模型数量计数器
					modelCounter = 0
					for modelType in singleDataDict[dictUniName][methodName]:
						for modelName in singleDataDict[dictUniName][methodName][modelType]:
							modelEstDict = singleDataDict[dictUniName][methodName][modelType][modelName]
							# 模型的别称(用于生成报告时模型的名称显示)
							modelNameStr = modelEstDict["aliasName"]
							ws.write(modelRow, modelCol, modelNameStr, normal)
							estCostTime = modelEstDict["estCostTime"]
							ws.write(dataRow, modelCol, estCostTime, numFormat)
							modelCol += 1
							modelCounter += 1
					#print("nowModelCol : "+str(nowModelCol)+" modelCol : "+str(modelCol))
					if nowModelCol == modelCol - 1:
						ws.write(methodRow,nowModelCol,nameTitle,normal)
					elif fristWrite == True:
						ws.merge_range(methodRow,nowModelCol,methodRow,modelCol-1,nameTitle,normal)
				fristWrite = False
				dataRow += 1
				trainBaseRow += 1
	wb.close()

# 输出所有的某指标值
def saveSomeMeasureResult(estDict, reportName, dictUniName, goalMeasureName):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in estDict:

		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"

		failTimeCol = 0
		failNumCol = 1

		for predInterval in estDict[dataType]:
			# 按照数据类别以及预测区间划分工作簿
			workSheetName = str(int(predInterval*100))+"%"+dataTypeName+"("+str(goalMeasureName)+")"
			workSheetName = workSheetName[:31]
			ws = wb.add_worksheet(workSheetName)
			predLen = 1
			# 写入数据集基本信息
			trainBaseCol = 0

			ws.merge_range(0, trainBaseCol, 0, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws.write(1, trainBaseCol, dataTypeName, normal)
			ws.write(1, trainBaseCol+2, "Total Testing Time", normal)
			ws.write(1, trainBaseCol+1, "Total Fault Num", normal)
			ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

			# 数据起始列
			initCol = 3
			# 数据集序号
			dataIndex = 1
			# 数据名称所在行
			dataRow = dataIndex + 1
			# 推参方法名称所在行
			methodRow = 0
			# 模型名称所在行
			modelRow = 1
			# 写入标题
			ws.write(dataRow - 1, initCol, "Data Set", normal)
			# 初始化数据集基本信息行号
			trainBaseRow = 2
			# 首次写入方法名称
			fristWrite = True
			# 开始遍历数据集
			for dataName in estDict[dataType][predInterval]:
				# 模型名称所在列
				modelCol = initCol + 1
				singleDataDict = estDict[dataType][predInterval][dataName]
				ws.write(dataRow, initCol, dataName, normal)
				# 数据集基本信息处同样写入数据集名称
				ws.write(trainBaseRow, trainBaseCol, dataName, normal)
				culFormatedTrainData = singleDataDict["culFormatedTrainData"]
				ws.write(trainBaseRow, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws.write(trainBaseRow, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
				for methodName in singleDataDict[dictUniName]:
					nowModelCol = modelCol
					try:
						measureName = reportUtilsTemplate.getMainMeasureName(estDict, dictUniName, methodName)
					except Exception as e:
						print("now : " + str(methodName))
						for x in singleDataDict[dictUniName]:
							print(x)
						raise e
					
					nameTitle = methodName + " ("+measureName+")"
					# 模型数量计数器
					modelCounter = 0
					for modelType in singleDataDict[dictUniName][methodName]:
						for modelName in singleDataDict[dictUniName][methodName][modelType]:
							modelEstDict = singleDataDict[dictUniName][methodName][modelType][modelName]
							# 模型的别称(用于生成报告时模型的名称显示)
							modelNameStr = modelEstDict["aliasName"]
							ws.write(modelRow, modelCol, modelNameStr, normal)
							estCostTime = modelEstDict["measureValueDict"][goalMeasureName]
							#estCostTime = [1,2,3]
							nowDataRow = dataRow
							if isinstance(estCostTime,list) == True:
								for ele in estCostTime:
									ws.write(nowDataRow, modelCol, ele, numFormat)
									nowDataRow += 1
							else:
								ws.write(nowDataRow, modelCol, estCostTime, numFormat)
								nowDataRow += 1

							modelCol += 1
							modelCounter += 1
					#print("nowModelCol : "+str(nowModelCol)+" modelCol : "+str(modelCol))
					if nowModelCol == modelCol - 1:
						ws.write(methodRow,nowModelCol,nameTitle,normal)
					elif fristWrite == True:
						ws.merge_range(methodRow,nowModelCol,methodRow,modelCol-1,nameTitle,normal)
				fristWrite = False
				#dataRow += 1
				dataRow = nowDataRow
				trainBaseRow += 1
	wb.close()

# 输出所有的某指标值的详细结果(经过数据预处理、数据清洗的数据)
# dictUniNameSelector 	= ["dictUniName1", "dictUniName2", ...]
# measureNameSelector 	= ["measureName1", "measureName2", ...]
# flagSelector 			= ["flag1", "flag2", ...]
def saveOriginalListWithPreprocessData(estDict, reportName, dictUniNameSelector = [], measureNameSelector = [], flagSelector = []):
	measureNameInOnePage = True
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)

	# estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][someMeasureDict]["originalList"/"median"/"maxValue"/"minValue"/...]
	estDict = reportUtilsTemplate.formatePreprocessData(estDict, measureNameSelector)
	for dataType in estDict:

		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"

		failTimeCol = 0
		failNumCol = 1
		#print(dataType)

		for predInterval in estDict[dataType]:
			#print(predInterval)
			tempMeasureNameList = reportUtilsTemplate.getMeasureNameListForPreprocessData(estDict, dataType, predInterval)
			if measureNameSelector != []:
				measureNameList = []
				for tempMeasureName in tempMeasureNameList:
					if tempMeasureName in measureNameSelector:
						measureNameList.append(tempMeasureName)
					elif "-" in tempMeasureName:
						for nameEle in measureNameSelector:
							if nameEle in tempMeasureName:
								measureNameList.append(tempMeasureName)
								break
			else:
				measureNameList = tempMeasureNameList
			# 可用的 measureName 数量
			measureLen = len(measureNameList)
			nowMeasureNameList = copy.deepcopy(measureNameList)
			if measureNameInOnePage == True:
				nowMeasureNameList = [None,]
			#print("measureNameList : "+str(measureNameList))
			#print("nowMeasureNameList : "+str(nowMeasureNameList))
			for nowMeasureName in nowMeasureNameList:
				#print("estDict[dataType][predInterval] : "+str(estDict[dataType][predInterval].keys()))
				for dataName in estDict[dataType][predInterval]:
					# 按照数据类别以及预测区间划分工作簿
					if nowMeasureName is None:
						ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+ dataName)
					else:
						ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"_"+nowMeasureName+dataName)
					#print(dataName)
					isTitleWrite = False
					upRow = 0
					modelNameStrList = []
					ws.merge_range(0, 0, 1, 0, "Model Name", normal)
					measureNameStrList = []

					ws.merge_range(0, 1, 1, 1, "Measure", normal)
					upCol = 2
					indicatorNameCol = 1
					indicatorValueCol = 2

					flagLen = len(estDict[dataType][predInterval][dataName])
					if flagLen == 1:
						ws.write(upRow, upCol, dataName, normal)
					else:
						ws.merge_range(upRow, upCol, upRow, upCol + flagLen - 1, dataName, normal)
					
					for flag in estDict[dataType][predInterval][dataName]:
						if flagSelector != [] and flag not in flagSelector:
							continue
						ws.write(upRow+1, upCol, flag, normal)
						upCol += 1
						indicatorRow = 2
						measureIndex = 0
						modelIndex = 0
						modelIndexStart = 0
						modelIndexEnd = 0
						isFirstWriteModelName = True
						for dictUniName in estDict[dataType][predInterval][dataName][flag]:
							if dictUniNameSelector != [] and dictUniName not in dictUniNameSelector:
								continue
							for methodName in estDict[dataType][predInterval][dataName][flag][dictUniName]:
								for modelType in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
									for modelName in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
										resDict = estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]
										modelNameStr = methodName+"/"+modelType+"/"+modelName
										measureLen = 1
										if measureNameInOnePage == True:
											tempMeasureNameList = copy.deepcopy(measureNameList)
										else:
											tempMeasureNameList = [nowMeasureName,]
										for measureName in tempMeasureNameList:
											if measureName not in resDict:
												continue
											indicatorLen = 1
											if "originalList" not in resDict[measureName]:
												continue
											for eleValue in resDict[measureName]["originalList"]:
												
												indicatorValue = eleValue
												ws.write(indicatorRow, indicatorNameCol, measureName, normal)
												try:
													ws.write(indicatorRow, indicatorValueCol, indicatorValue, normal)
												except Exception as e:
													print("measureName " +str(measureName))
													print("indicatorName " +str(indicatorName))
													raise e
												indicatorRow += 1
												indicatorLen += 1
											indicatorLen = indicatorLen - 1
											if measureNameInOnePage == True and isTitleWrite == False:
												if indicatorLen == 1:
													ws.write(2 + measureIndex*indicatorLen,1,measureName,normal)
												else:
													ws.merge_range(2 + measureIndex*indicatorLen,1,2 + (measureIndex+1)*indicatorLen - 1,1,measureName,normal)
												measureIndex += 1
											measureLen += 1
										measureLen = measureLen - 1
										if measureNameInOnePage == True:
											modelNameStrWidth = measureLen * indicatorLen
										else:
											modelNameStrWidth = indicatorLen
										if isTitleWrite == False and measureLen != 0:
											modelIndexStart = 0
											if modelNameStrWidth == 1:
												ws.write(2 + modelIndex,0,modelNameStr,normal)
											else:
												if isFirstWriteModelName == True:
													modelIndexStart = 2 + modelIndex*modelNameStrWidth
													modelIndexEnd = 2 + (modelIndex+1)*modelNameStrWidth - 1
													isFirstWriteModelName = False
												else:
													modelIndexStart = modelIndexEnd + 1
													modelIndexEnd = modelIndexEnd + modelNameStrWidth
												ws.merge_range(modelIndexStart,0,modelIndexEnd,0,modelNameStr,normal)
											modelIndex += 1

						indicatorValueCol += 1
						isTitleWrite = True
	wb.close()


# 输出所有的某指标值(经过数据预处理、数据清洗的数据)
# dictUniNameSelector 	= ["dictUniName1", "dictUniName2", ...]
# measureNameSelector 	= ["measureName1", "measureName2", ...]
# indicatorSelector 	= ["maxValue", "minValue", "average", "median", "q1", "q3", "qVariance", "variance"]
# flagSelector 			= ["flag1", "flag2", ...]
# measureNameInOnePage 为 True 时表示所有 measureName 的结果都写在同一页。为 False 时则分页表示
def saveSomeMeasureResultWithPreprocessData(estDict, reportName, dictUniNameSelector = [], measureNameSelector = [], indicatorSelector = [], flagSelector = [], measureNameInOnePage = False, dataNameInOnePage = True, formatType = "typeI"):
	if formatType == "typeI":
		wb = xlsxwriter.Workbook(reportName[:-5]+"_typeI.xlsx")
		normal = reportUtilsTemplate.getNormalFormat(wb)
		redNum = reportUtilsTemplate.getRedNumFormat(wb)
		numFormat = reportUtilsTemplate.getNumFormat(wb)
		boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
		redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)

		# estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][someMeasureDict]["originalList"/"median"/"maxValue"/"minValue"/...]
		estDict = reportUtilsTemplate.formatePreprocessData(estDict, measureNameSelector)
		for dataType in estDict:

			if dataType == "time":
				dataTypeName = "Time Data"
			elif dataType == "group":
				dataTypeName = "Group Data"

			failTimeCol = 0
			failNumCol = 1

			for predInterval in estDict[dataType]:
				tempMeasureNameList = reportUtilsTemplate.getMeasureNameListForPreprocessData(estDict, dataType, predInterval)
				if measureNameSelector != []:
					measureNameList = []
					for tempMeasureName in tempMeasureNameList:
						if tempMeasureName in measureNameSelector:
							measureNameList.append(tempMeasureName)
						elif "-" in tempMeasureName:
							for nameEle in measureNameSelector:
								if nameEle in tempMeasureName:
									measureNameList.append(tempMeasureName)
									break
				else:
					measureNameList = tempMeasureNameList
				# 可用的 measureName 数量
				measureLen = len(measureNameList)
				nowMeasureNameList = copy.deepcopy(measureNameList)
				if measureNameInOnePage == True:
					nowMeasureNameList = [None,]
				#print("measureNameList : "+str(measureNameList))
				for nowMeasureName in nowMeasureNameList:
					if dataNameInOnePage == True:
						# 按照数据类别以及预测区间划分工作簿
						if nowMeasureName is None:
							ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName)
						else:
							ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"_"+nowMeasureName)
						isTitleWrite = False
						upRow = 0
						modelNameStrList = []
						ws.merge_range(0, 0, 1, 0, "Model Name", normal)
						measureNameStrList = []
						if measureNameInOnePage == True:
							ws.merge_range(0, 1, 1, 1, "Measure", normal)
							ws.merge_range(0, 2, 1, 2, "Indicator", normal)
							upCol = 3
							indicatorNameCol = 2
							indicatorValueCol = 3
						else:
							ws.merge_range(0, 1, 1, 1, "Indicator", normal)
							upCol = 2
							indicatorNameCol = 1
							indicatorValueCol = 2
					for dataName in estDict[dataType][predInterval]:
						if dataNameInOnePage == False:
							# 按照数据类别以及预测区间划分工作簿
							if nowMeasureName is None:
								ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+ dataName)
							else:
								ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"_"+nowMeasureName+dataName)
							isTitleWrite = False
							upRow = 0
							modelNameStrList = []
							ws.merge_range(0, 0, 1, 0, "Model Name", normal)
							measureNameStrList = []
							if measureNameInOnePage == True:
								ws.merge_range(0, 1, 1, 1, "Measure", normal)
								ws.merge_range(0, 2, 1, 2, "Indicator", normal)
								upCol = 3
								indicatorNameCol = 2
								indicatorValueCol = 3
							else:
								ws.merge_range(0, 1, 1, 1, "Indicator", normal)
								upCol = 2
								indicatorNameCol = 1
								indicatorValueCol = 2

						flagLen = len(estDict[dataType][predInterval][dataName])
						if flagLen == 1:
							ws.write(upRow, upCol, dataName, normal)
						else:
							ws.merge_range(upRow, upCol, upRow, upCol + flagLen - 1, dataName, normal)
						
						for flag in estDict[dataType][predInterval][dataName]:
							if flagSelector != [] and flag not in flagSelector:
								continue
							ws.write(upRow+1, upCol, flag, normal)
							upCol += 1
							indicatorRow = 2
							measureIndex = 0
							modelIndex = 0
							modelIndexStart = 0
							modelIndexEnd = 0
							isFirstWriteModelName = True
							for dictUniName in estDict[dataType][predInterval][dataName][flag]:
								if dictUniNameSelector != [] and dictUniName not in dictUniNameSelector:
									continue
								for methodName in estDict[dataType][predInterval][dataName][flag][dictUniName]:
									for modelType in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
										for modelName in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
											resDict = estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]
											modelNameStr = methodName+"/"+modelType+"/"+modelName
											#if modelNameStr not in modelNameStrList:
											#	modelNameStrList.append(modelNameStr)
											measureLen = 1
											if measureNameInOnePage == True:
												tempMeasureNameList = copy.deepcopy(measureNameList)
											else:
												tempMeasureNameList = [nowMeasureName,]
											for measureName in tempMeasureNameList:
												if measureName not in resDict:
													continue
												indicatorLen = 1
												for indicatorName in resDict[measureName]:
													if indicatorSelector != [] and indicatorName not in indicatorSelector:
														continue
													if indicatorName == "originalList":
														continue
													indicatorValue = resDict[measureName][indicatorName]
													ws.write(indicatorRow, indicatorNameCol, indicatorName, normal)
													try:
														ws.write(indicatorRow, indicatorValueCol, indicatorValue, normal)
													except Exception as e:
														print("measureName " +str(measureName))
														print("indicatorName " +str(indicatorName))
														raise e
													indicatorRow += 1
													indicatorLen += 1
												indicatorLen = indicatorLen - 1
												if measureNameInOnePage == True and isTitleWrite == False:
													if indicatorLen == 1:
														ws.write(2 + measureIndex*indicatorLen,1,measureName,normal)
													else:
														ws.merge_range(2 + measureIndex*indicatorLen,1,2 + (measureIndex+1)*indicatorLen - 1,1,measureName,normal)
													measureIndex += 1
												measureLen += 1
											measureLen = measureLen - 1
											if measureNameInOnePage == True:
												modelNameStrWidth = measureLen * indicatorLen
											else:
												modelNameStrWidth = indicatorLen
											if isTitleWrite == False and measureLen != 0:
												modelIndexStart = 0
												if modelNameStrWidth == 1:
													ws.write(2 + modelIndex,0,modelNameStr,normal)
												else:
													if isFirstWriteModelName == True:
														modelIndexStart = 2 + modelIndex*modelNameStrWidth
														modelIndexEnd = 2 + (modelIndex+1)*modelNameStrWidth - 1
														isFirstWriteModelName = False
													else:
														modelIndexStart = modelIndexEnd + 1
														modelIndexEnd = modelIndexEnd + modelNameStrWidth
													ws.merge_range(modelIndexStart,0,modelIndexEnd,0,modelNameStr,normal)
												modelIndex += 1

							indicatorValueCol += 1
							isTitleWrite = True
		wb.close()


	if formatType == "typeII":	
		wb = xlsxwriter.Workbook(reportName[:-5]+"_typeII.xlsx")
		normal = reportUtilsTemplate.getNormalFormat(wb)
		redNum = reportUtilsTemplate.getRedNumFormat(wb)
		numFormat = reportUtilsTemplate.getNumFormat(wb)
		boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
		redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)

		# estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName][someMeasureDict]["originalList"/"median"/"maxValue"/"minValue"/...]
		#estDict = reportUtilsTemplate.formatePreprocessData(estDict, measureNameSelector)
		for dataType in estDict:

			if dataType == "time":
				dataTypeName = "Time Data"
			elif dataType == "group":
				dataTypeName = "Group Data"

			failTimeCol = 0
			failNumCol = 1

			for predInterval in estDict[dataType]:
				tempMeasureNameList = reportUtilsTemplate.getMeasureNameListForPreprocessData(estDict, dataType, predInterval)
				if measureNameSelector != []:
					measureNameList = []
					for tempMeasureName in tempMeasureNameList:
						if tempMeasureName in measureNameSelector:
							measureNameList.append(tempMeasureName)
						elif "-" in tempMeasureName:
							for nameEle in measureNameSelector:
								if nameEle in tempMeasureName:
									measureNameList.append(tempMeasureName)
									break
				else:
					measureNameList = tempMeasureNameList
				# 可用的 measureName 数量
				measureLen = len(measureNameList)
				nowMeasureNameList = copy.deepcopy(measureNameList)
				if measureNameInOnePage == True:
					nowMeasureNameList = [None,]
				#print("measureNameList : "+str(measureNameList))
				for nowMeasureName in nowMeasureNameList:
					if dataNameInOnePage == True:
						# 按照数据类别以及预测区间划分工作簿
						if nowMeasureName is None:
							ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName)
						else:
							ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"_"+nowMeasureName)
						isTitleWrite = False
						upInitCol = 0
						modelNameStrList = []
						
						measureNameStrList = []
						if measureNameInOnePage == True:
							ws.merge_range(0, 0, 2, 0, "Data Set", normal)
							ws.merge_range(0, 1, 2, 1, "Flag", normal)
							upInitRow = 3
							indicatorNameCol = 2
							indicatorValueCol = 3
						else:
							ws.merge_range(0, 0, 1, 0, "Data Set", normal)
							ws.merge_range(0, 1, 1, 1, "Flag", normal)
							upInitRow = 2
							indicatorNameCol = 1
							indicatorValueCol = 2
						dataIndex = 1
						flagIndex = 0
					for dataName in estDict[dataType][predInterval]:
						if dataNameInOnePage == False:
							# 按照数据类别以及预测区间划分工作簿
							if nowMeasureName is None:
								ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+dataName)
							else:
								ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"_"+nowMeasureName+dataName)
							isTitleWrite = False
							upInitCol = 0
							modelNameStrList = []
							
							measureNameStrList = []
							if measureNameInOnePage == True:
								ws.merge_range(0, 0, 2, 0, "Data Set", normal)
								ws.merge_range(0, 1, 2, 1, "Flag", normal)
								upInitRow = 3
								indicatorNameCol = 2
								indicatorValueCol = 3
							else:
								ws.merge_range(0, 0, 1, 0, "Data Set", normal)
								ws.merge_range(0, 1, 1, 1, "Flag", normal)
								upInitRow = 2
								indicatorNameCol = 1
								indicatorValueCol = 2
							dataIndex = 1
							flagIndex = 0
						flagLen = len(estDict[dataType][predInterval][dataName])
						if flagLen == 1:
							ws.write(upInitRow + dataIndex, upInitCol, dataName, normal)
						else:
							ws.merge_range(upInitRow + (dataIndex-1)*flagLen, upInitCol ,upInitRow + dataIndex*flagLen -1, upInitCol, dataName, normal)
						
						for flag in estDict[dataType][predInterval][dataName]:
							if flagSelector != [] and flag not in flagSelector:
								continue
							ws.write(upInitRow +  flagIndex, upInitCol+1 , flag, normal)
							indicatorRow = 2
							measureIndex = 0
							modelIndex = 0
							modelIndexStart = 0
							modelIndexEnd = 0
							isFirstWriteModelName = True
							for dictUniName in estDict[dataType][predInterval][dataName][flag]:
								if dictUniNameSelector != [] and dictUniName not in dictUniNameSelector:
									continue
								for methodName in estDict[dataType][predInterval][dataName][flag][dictUniName]:
									for modelType in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName]:
										for modelName in estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType]:
											resDict = estDict[dataType][predInterval][dataName][flag][dictUniName][methodName][modelType][modelName]
											modelNameStr = methodName+"/"+modelType+"/"+modelName
											measureLen = 1
											if measureNameInOnePage == True:
												tempMeasureNameList = copy.deepcopy(measureNameList)
											else:
												tempMeasureNameList = [nowMeasureName,]
											for measureName in tempMeasureNameList:
												if measureName not in resDict:
													continue
												indicatorLen = 1
												for indicatorName in resDict[measureName]:
													if indicatorSelector != [] and indicatorName not in indicatorSelector:
														continue
													if indicatorName == "originalList":
														continue
													indicatorValue = resDict[measureName][indicatorName]
													#ws.write(indicatorRow, indicatorNameCol, indicatorName, normal)
													ws.write(indicatorNameCol ,indicatorRow , indicatorName, normal)
													
													try:
														#ws.write(indicatorRow, indicatorValueCol, indicatorValue, normal)
														ws.write(indicatorValueCol ,indicatorRow , indicatorValue, normal)
														pass
													except Exception as e:
														print("measureName " +str(measureName))
														print("indicatorName " +str(indicatorName))
														raise e
													indicatorRow += 1
													indicatorLen += 1
												indicatorLen = indicatorLen - 1
												if measureNameInOnePage == True and isTitleWrite == False:
													if indicatorLen == 1:
														#ws.write(2 + measureIndex*indicatorLen,1,measureName,normal)
														ws.write(1, 2 + measureIndex*indicatorLen,measureName,normal)
														pass
													else:
														#ws.merge_range(2 + measureIndex*indicatorLen,1,2 + (measureIndex+1)*indicatorLen - 1,1,measureName,normal)
														ws.merge_range(1, 2 + measureIndex*indicatorLen, 1, 2 + (measureIndex+1)*indicatorLen - 1,measureName,normal)
														pass
													measureIndex += 1
												measureLen += 1
											measureLen = measureLen - 1
											if measureNameInOnePage == True:
												modelNameStrWidth = measureLen * indicatorLen
											else:
												modelNameStrWidth = indicatorLen
											if isTitleWrite == False and measureLen != 0:
												modelIndexStart = 0
												if modelNameStrWidth == 1:
													#ws.write(2 + modelIndex,0,modelNameStr,normal)
													ws.write(0, 2 + modelIndex,modelNameStr,normal)
													pass
												else:
													if isFirstWriteModelName == True:
														modelIndexStart = 2 + modelIndex*modelNameStrWidth
														modelIndexEnd = 2 + (modelIndex+1)*modelNameStrWidth - 1
														isFirstWriteModelName = False
													else:
														modelIndexStart = modelIndexEnd + 1
														modelIndexEnd = modelIndexEnd + modelNameStrWidth
													#ws.merge_range(modelIndexStart,0,modelIndexEnd,0,modelNameStr,normal)
													ws.merge_range(0,modelIndexStart ,0,modelIndexEnd,modelNameStr,normal)
													pass
												modelIndex += 1

							indicatorValueCol += 1
							isTitleWrite = True
							flagIndex += 1
						dataIndex += 1
		wb.close()

def saveBaseEstPic(estDict, reportPath, dictUniName):
	os.system('mkdir '+reportPath+"estPic_"+dictUniName)
	for dataType in estDict:
		if dataType == "time":
			dataTypeName = "TimeData"
		elif dataType == "group":
			dataTypeName = "GroupData"
		for predInterval in estDict[dataType]:
			picPath = reportPath+"estPic_"+dictUniName+"/"+dataTypeName+"_"+str(int(predInterval*100))+"/"
			os.system('mkdir '+picPath)
			# 开始遍历数据集
			for dataName in estDict[dataType][predInterval]:
				singleDataDict = estDict[dataType][predInterval][dataName][dictUniName]
				dataDict = dict()
				culFormatedTrainData = estDict[dataType][predInterval][dataName]["culFormatedTrainData"]
				timeList = []
				valueList = []
				for nowTime, nowNum in culFormatedTrainData:
					timeList.append(nowTime)
					valueList.append(nowNum)
				dataDict["timeList"] = timeList
				dataDict["valueList"] = valueList
				dataDict["labelName"] = dataName
				picFileName = picPath + str(int(predInterval*100)) + "_" + str(dataName)
				
				picPropertyDict = dict()
				picPropertyDict["picFileName"] = picFileName
				linePlot.createPic(dataDict, None, dataType, picPropertyDict)
				for methodName in singleDataDict:
					for modelType in singleDataDict[methodName]:
						for modelName in singleDataDict[methodName][modelType]:
							modelEstDict = singleDataDict[methodName][modelType][modelName]
							modelNameStr = modelEstDict["aliasName"]
							picFileName = picPath + str(int(predInterval*100)) + "_" + str(dataName) + "_" + str(methodName) + "_" + str(modelType) + "_"+str(modelName)
							culFormatedEstData = modelEstDict["culFormatedEstData"]
							timeList = []
							valueList = []
							for nowTime, nowNum in culFormatedEstData:
								timeList.append(nowTime)
								valueList.append(nowNum)
							estModelDict = dict()
							estModelDict["timeList"] = timeList
							estModelDict["valueList"] = valueList
							estModelDict["labelName"] = modelNameStr
							picPropertyDict = dict()
							picPropertyDict["picFileName"] = picFileName
							linePlot.createPic(dataDict, estModelDict, dataType, picPropertyDict)

def saveBasePredPic(predDict, reportPath, dictUniName):
	os.system('mkdir '+reportPath+"predPic_"+dictUniName)
	for dataType in predDict:
		if dataType == "time":
			dataTypeName = "TimeData"
		elif dataType == "group":
			dataTypeName = "GroupData"
		for predInterval in predDict[dataType]:
			picPath = reportPath+"predPic_"+dictUniName+"/"+dataTypeName+"_"+str(int(predInterval*100))+"/"
			os.system('mkdir '+picPath)
			# 开始遍历数据集
			for dataName in predDict[dataType][predInterval]:
				singleDataDict = predDict[dataType][predInterval][dataName][dictUniName]
				timeList = []
				valueList = []
				culFormatedTrainData = predDict[dataType][predInterval][dataName]["culFormatedTrainData"]
				culFormatedTestData = predDict[dataType][predInterval][dataName]["culFormatedTestData"]
				for nowTime, nowNum in culFormatedTrainData:
					timeList.append(nowTime)
					valueList.append(nowNum)
				for nowTime, nowNum in culFormatedTestData:
					timeList.append(nowTime)
					valueList.append(nowNum)
				dataDict = dict()
				dataDict["timeList"] = timeList
				dataDict["valueList"] = valueList
				dataDict["labelName"] = dataName
				picFileName = picPath + str(int(predInterval*100)) + "_" + str(dataName)
				
				picPropertyDict = dict()
				picPropertyDict["picFileName"] = picFileName
				linePlot.createPic(dataDict, None, dataType, picPropertyDict)
				for methodName in singleDataDict:
					for modelType in singleDataDict[methodName]:
						for modelName in singleDataDict[methodName][modelType]:
							modelPredDict = singleDataDict[methodName][modelType][modelName]
							modelNameStr = modelPredDict["aliasName"]
							picFileName = picPath + str(int(predInterval*100)) + "_" + str(dataName) + "_" + str(methodName) + "_" + str(modelType) + "_"+str(modelName)
							culFormatedPredData = modelPredDict["culFormatedPredData"]
							timeList = []
							valueList = []
							for nowTime, nowNum in culFormatedPredData:
								timeList.append(nowTime)
								valueList.append(nowNum)
							estModelDict = dict()
							estModelDict["timeList"] = timeList
							estModelDict["valueList"] = valueList
							estModelDict["labelName"] = modelNameStr
							picPropertyDict = dict()
							picPropertyDict["picFileName"] = picFileName
							linePlot.createPic(dataDict, estModelDict, dataType, picPropertyDict)

def saveBaseDataPic(dataDict, reportPath):
	os.system('mkdir '+reportPath+"dataPic")
	picPath = reportPath+"dataPic/"
	for dataType in dataDict:
		if dataType == "time":
			dataTypeName = "TimeData"
		elif dataType == "group":
			dataTypeName = "GroupData"
		for predInterval in dataDict[dataType]:
			# 开始遍历数据集
			for dataName in dataDict[dataType][predInterval]:
				timeList = []
				valueList = []
				culFormatedTrainData = dataDict[dataType][predInterval][dataName]["culFormatedTrainData"]
				for nowTime, nowNum in culFormatedTrainData:
					timeList.append(nowTime)
					valueList.append(nowNum)
				dataInfoDict = dict()
				dataInfoDict["timeList"] = timeList
				dataInfoDict["valueList"] = valueList
				dataInfoDict["labelName"] = dataName
				picFileName = picPath + dataTypeName + "_" + str(int(predInterval*100)) + "_" + str(dataName)
				picPropertyDict = dict()
				picPropertyDict["picFileName"] = picFileName
				linePlot.createPic(dataInfoDict, None, dataType, picPropertyDict)
		# 输出100%的数据图像
		predInterval = next(iter(dataDict[dataType]))
		for dataName in dataDict[dataType][predInterval]:
			timeList = []
			valueList = []
			culFormatedTrainData = dataDict[dataType][predInterval][dataName]["culFormatedTrainData"]
			culFormatedTestData = dataDict[dataType][predInterval][dataName]["culFormatedTestData"]
			for nowTime, nowNum in culFormatedTrainData:
				timeList.append(nowTime)
				valueList.append(nowNum)
			for nowTime, nowNum in culFormatedTestData:
				timeList.append(nowTime)
				valueList.append(nowNum)
			dataInfoDict = dict()
			dataInfoDict["timeList"] = timeList
			dataInfoDict["valueList"] = valueList
			dataInfoDict["labelName"] = dataName
			picFileName = picPath + dataTypeName + "_100_" + str(dataName)
			picPropertyDict = dict()
			picPropertyDict["picFileName"] = picFileName
			linePlot.createPic(dataInfoDict, None, dataType, picPropertyDict)





# 比较不同推参方法的最佳PMAE结果
#
# uniMethodList 用于确定比较结果的对象. 
# 可以留空. 此时表示比较predictDict内所有的结果字典
# uniMethodList 可以接受以下两种格式的输入:
# 第一种:
# uniMethodList = [dictUniName, ...,]
# 此时只比较uniMethodList内的dictUniName字典之间的结果
# 第二种:
# uniMethodList = [uniMethodDict, ...,]
# uniMethodDict["dictUniName"] 		# 预测结果保存字典
# uniMethodDict["methodName"] 		# 推参方法. 留空时表示比较dictUniName下所有的推参方法
# uniMethodDict["measureName"] 		# 模型选择指标. 留空时则只考虑主指标
# uniMethodDict["nameTitle"] 		# 展示用名称 / 推参方法名称. 留空时则默认等于 "methodName (measureName)"
# 第一种输入等同于第二种输入除了dictUniName全留空的情形.
# 
# showModelName 决定是否展示具有最佳measureValue的"模型名称"(不同于"推参方法名称")
#
# baselineDict用于确定所有模型都会与之比较的对象。
# 超越baseline模型的结果会加粗。baselineDict的格式与uniMethodDict相同
#
# inOnePage = True 时会让不同预测阶段的结果都集中在同一页显示
def savePredictResultComparisonWithBestResult(predictDict, reportName, uniMethodList = [], showModelName = True, baselineDict = None, inOnePage = False):
	#print("savePredictResultComparisonWithBestResult")
	# 暂时不允许显示模型名称 (目前会显示mini measure的模型名称)
	#showModelName = False
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in predictDict:
		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"
		failTimeCol = 0
		failNumCol = 1

		onePageOffset_dataDetail = 0
		onePageOffset_predRes = 0
		if inOnePage == True:
			# 按照数据类别以及预测区间划分工作簿
			ws = wb.add_worksheet(dataTypeName+"(累计PMAE)")
			ws_single = wb.add_worksheet(dataTypeName+"(单日PMAE)")
			predLen = len(predictDict[dataType])
			totalCulBestList = []
			totalNonCulBestList = []
			totalCulBaselineList = []
			totalNonCulBaselineList = []

		# 记录超越baseline模型结果的平均改善(全体预测阶段)
		outBaselineCulAverImproList_totalPhase = []
		outBaselineNonCulAverImproList_totalPhase = []
		# 记录超越baseline模型结果的平均恶化(全体预测阶段)
		outBaselineCulAverWorsenList_totalPhase = []
		outBaselineNonCulAverWorsenList_totalPhase = []

		for predInterval in predictDict[dataType]:
			if inOnePage == False:
				# 按照数据类别以及预测区间划分工作簿
				ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(累计PMAE)")
				ws_single = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(单日PMAE)")
				predLen = 1
			# 写入数据集基本信息
			trainBaseCol = 0

			ws.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Testing Time", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Fault Num", normal)
			ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

			ws_single.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Testing Time", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Fault Num", normal)
			ws_single.set_column(trainBaseCol+1, trainBaseCol+1, 12)
			# 数据集序号
			dataIndex = 1
			# 数据名称所在行
			if showModelName == True:
				dataRow = 2*dataIndex-1
			else:
				dataRow = dataIndex
			# 起始列
			initCol = 3
			# 写入标题
			ws.write(0, initCol, "Data Set", normal)
			ws_single.write(0, initCol, "Data Set", normal)
			# 确认 uniMethodList 类型
			if uniMethodList == []:
				finalUniMethodList = reportUtilsTemplate.getUniNameList(predictDict,dataType,predInterval)
			else:
				finalUniMethodList = uniMethodList
			# 记录每个方法在不同数据集拿到最佳结果的次数
			bestCulCounterList = []
			bestNonCulCounterList = []
			# 记录超越baseline模型结果的次数
			outBaselineCulCounterList = []
			outBaselineNonCulCounterList = []
			# 记录低于baseline模型结果的次数
			underBaselineCulCounterList = []
			underBaselineNonCulCounterList = []
			# 记录超越baseline模型结果的平均改善(不同预测阶段)
			outBaselineCulAverImproList_diffPhase = []
			outBaselineNonCulAverImproList_diffPhase = []
			# 记录超越baseline模型结果的平均恶化(不同预测阶段)
			outBaselineCulAverWorsenList_diffPhase = []
			outBaselineNonCulAverWorsenList_diffPhase = []
			# 初始化数据集基本信息行号
			trainBaseRow = 2
			# 开始遍历数据集
			for dataName in predictDict[dataType][predInterval]:
				# 估计值非法时跳过统计
				nanFlag = False
				

				singleDataDict = predictDict[dataType][predInterval][dataName]
				
				# 查找baseline模型的结果
				baselineModelCulRes = -1
				baselineModelNonCulRes = -1
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					baselineUniName = baselineDict["dictUniName"]
					baselineMethodName = baselineDict["methodName"]
					# 模型选择指标
					baselineMeasureName = reportUtilsTemplate.getMainMeasureName(predictDict, baselineUniName, baselineMethodName)
					# 获得完整训练数据的Measure列表
					measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(predictDict, baselineUniName, dataType, dataName, predInterval, baselineMethodName, baselineMeasureName)
					# measureValue最小的模型的index
					minimeasureValueIndex = measureList[0][1]
					# measureValue最小的模型的模型类别
					modelType = modelIndexMateList[ minimeasureValueIndex ][0]
					# measureValue最小的模型的模型名称
					modelName = modelIndexMateList[ minimeasureValueIndex ][1]
					
					# 查找最佳预测性能结果
					firstFlag = True
					for modelType in singleDataDict[baselineUniName][baselineMethodName]:
						for modelName in singleDataDict[baselineUniName][baselineMethodName][modelType]:
							if firstFlag == True:
								firstFlag = False
								baselineModelCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["culPMAE"]
								baselineModelNonCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["nonCulPMAE"]
							else:
								nowCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["culPMAE"]
								nowNonCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["nonCulPMAE"]
								if nowCulRes < baselineModelCulRes:
									baselineModelCulRes = nowCulRes
								if nowNonCulRes < baselineModelNonCulRes:
									baselineModelNonCulRes = nowNonCulRes

					#baselineModelCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["culPMAE"]
					#baselineModelNonCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["nonCulPMAE"]
				
				# 待比较方法下标
				methodCol = 1
				bestCulMethodDict = None
				bestNonCulMethodDict = None
				boldMethodCulList = []
				boldMethodNonCulList = []
				# 逐个写入待比较方法
				for uniMethodEle in finalUniMethodList:
					# 推参方法
					methodNameList = []
					# 预测结果保存字典
					if isinstance(uniMethodEle, str):
						dictUniName = uniMethodEle
						for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
							methodNameList.append(methodName)
					elif isinstance(uniMethodEle, dict):
						dictUniName = uniMethodEle["dictUniName"]
						if "methodName" not in uniMethodEle:
							for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
								methodNameList.append(methodName)
						else:
							methodName = uniMethodEle["methodName"]
							methodNameList.append(methodName)
					else:
						raise
					for methodName in methodNameList:
						# 模型选择指标
						if isinstance(uniMethodEle, str):
							measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
						elif isinstance(uniMethodEle, dict):
							if "measureName" not in uniMethodEle:
								measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
							else:
								measureName = uniMethodEle["measureName"]
						# 展示用名称 / 推参方法名称
						if isinstance(uniMethodEle, str):
							nameTitle = methodName + " ("+measureName+")"
						elif isinstance(uniMethodEle, dict):
							if "nameTitle" not in uniMethodEle:
								nameTitle = methodName + " ("+measureName+")"
							else:
								nameTitle = uniMethodEle["nameTitle"]
						# 获得完整训练数据的Measure列表
						measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(predictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName)
						# measureValue最小的模型的measureValue
						minimeasureValue = measureList[0][0]
						# measureValue最小的模型的index
						minimeasureValueIndex = measureList[0][1]
						# measureValue最小的模型的模型类别
						modelType = modelIndexMateList[ minimeasureValueIndex ][0]
						# measureValue最小的模型的模型名称
						modelName = modelIndexMateList[ minimeasureValueIndex ][1]
						# measureValue最小的模型的参数
						paraList = modelIndexMateList[ minimeasureValueIndex ][2]
						# 模型的别称(用于生成报告时模型的名称显示)
						alias = modelIndexMateList[ minimeasureValueIndex ][4]
						if alias is None:
							modelNameStr = "("+modelType+"-"+modelName+")"
						else:
							modelNameStr = "("+alias+")"
						# 预测性能结果
						culPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
						nonCulPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["nonCulPMAE"]

						# 获取最小PMAE模型结果
						firstFlag = True
						miniCulModelName = ""
						miniCulModelType = ""
						miniCulDataName = ""
						miniNonCulModelName = ""
						miniNonCulModelType = ""
						miniNonCulDataName = ""
						for modelType in singleDataDict[dictUniName][methodName]:
							for modelName in singleDataDict[dictUniName][methodName][modelType]:
								if firstFlag == True:
									firstFlag = False
									culPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
									nonCulPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["nonCulPMAE"]
									miniCulModelName = modelName
									miniCulModelType = modelType
									if "dataName" in singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]:
										miniCulDataName = singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]["dataName"]
									miniNonCulModelName = modelName
									miniNonCulModelType = modelType
									if "dataName" in singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]:
										miniNonCulDataName = singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]["dataName"]
								else:
									nowCulRes = singleDataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
									nowNonCulRes = singleDataDict[dictUniName][methodName][modelType][modelName]["nonCulPMAE"]
									if nowCulRes < culPMAE:
										culPMAE = nowCulRes
										miniCulModelName = modelName
										miniCulModelType = modelType
										if "dataName" in singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]:
											miniCulDataName = singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]["dataName"]
									if nowNonCulRes < nonCulPMAE:
										nonCulPMAE = nowNonCulRes
										miniNonCulModelName = modelName
										miniNonCulModelType = modelType
										if "dataName" in singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]:
											miniNonCulDataName = singleDataDict[dictUniName][methodName][modelType][modelName]["methodDict"]["dataName"]

						culModelNameStr = "("+miniCulModelType+"-"+miniCulModelName+")"
						nonCulModelNameStr = "("+miniNonCulModelType+"-"+miniNonCulModelName+")"
						if miniCulDataName != "":
							culModelNameStr = "("+miniCulModelType+"-"+miniCulModelName+"-"+miniCulDataName+")"
						if miniNonCulDataName != "":
							nonCulModelNameStr = "("+miniNonCulModelType+"-"+miniNonCulModelName+"-"+miniNonCulDataName+")"
						
						if minimeasureValue == float("inf"):
							nanFlag = True
							continue
						elif minimeasureValue == float("-inf"):
							nanFlag = True
							continue
						elif isinstance(minimeasureValue, str):
							nanFlag = True
							continue
						elif math.isnan(minimeasureValue):
							nanFlag = True
							continue


						if culPMAE == float("inf"):
							culPMAE = "inf"
							continue
						elif culPMAE == float("-inf"):
							culPMAE = "-inf"
							continue
						elif isinstance(culPMAE, str):
							culPMAE = "str"
							continue
						elif math.isnan(culPMAE):
							culPMAE = "Nan"
							continue

						# 性能指标所在行与列
						resRow = dataRow + onePageOffset_predRes
						resCol = methodCol + initCol
						# 写入 推参方法名称
						ws.write(0, resCol, nameTitle, normal)
						ws_single.write(0, resCol, nameTitle, normal)
						# 写入 预测性能指标
						ws.write(resRow, resCol, culPMAE, numFormat)
						ws_single.write(resRow, resCol, nonCulPMAE, numFormat)
						if showModelName == True:
							# 写入 模型名称
							ws.write(dataRow+1, resCol, culModelNameStr, normal)
							ws_single.write(dataRow+1, resCol, nonCulModelNameStr, normal)
						# 记录 最佳模型(累计PMAE)
						if bestCulMethodDict is None:
							bestCulMethodDict = dict()
							bestCulMethodDict["row"] = resRow
							bestCulMethodDict["col"] = resCol
							bestCulMethodDict["methodCol"] = methodCol
							bestCulMethodDict["predResult"] = culPMAE
						# 更新 最佳模型(累计PMAE)
						elif round(culPMAE,2) < round(bestCulMethodDict["predResult"],2):
							bestCulMethodDict["row"] = resRow
							bestCulMethodDict["col"] = resCol
							bestCulMethodDict["methodCol"] = methodCol
							bestCulMethodDict["predResult"] = culPMAE
						# 记录 最佳模型(单日PMAE)
						if bestNonCulMethodDict is None:
							bestNonCulMethodDict = dict()
							bestNonCulMethodDict["row"] = resRow
							bestNonCulMethodDict["col"] = resCol
							bestNonCulMethodDict["methodCol"] = methodCol
							bestNonCulMethodDict["predResult"] = nonCulPMAE
						# 更新 最佳模型(单日PMAE)
						elif round(nonCulPMAE,2) < round(bestNonCulMethodDict["predResult"],2):
							bestNonCulMethodDict["row"] = resRow
							bestNonCulMethodDict["col"] = resCol
							bestNonCulMethodDict["methodCol"] = methodCol
							bestNonCulMethodDict["predResult"] = nonCulPMAE
						# 初始化 最佳次数计数器
						if len(bestCulCounterList) < methodCol:
							bestCulCounterList.append(0)
						if len(bestNonCulCounterList) < methodCol:
							bestNonCulCounterList.append(0)

						# 与baseline相比PMAE的平均变化
						diffCulPMAE = abs(round(baselineModelCulRes,2) - round(culPMAE,2))
						# 初始化 超越baseline模型次数计数器
						if len(outBaselineCulCounterList) < methodCol:
							if round(culPMAE,2) < round(baselineModelCulRes,2):
								outBaselineCulMethodDict = dict()
								outBaselineCulMethodDict["row"] = resRow
								outBaselineCulMethodDict["col"] = resCol
								outBaselineCulMethodDict["predResult"] = culPMAE
								boldMethodCulList.append(outBaselineCulMethodDict)
								outBaselineCulCounterList.append(1)
								underBaselineCulCounterList.append(0)
								# 记录PMAE平均改善与恶化
								outBaselineCulAverImproList_diffPhase.append(diffCulPMAE)
								outBaselineCulAverWorsenList_diffPhase.append(0)
							else:
								outBaselineCulCounterList.append(0)
								underBaselineCulCounterList.append(1)
								# 记录PMAE平均改善与恶化
								outBaselineCulAverImproList_diffPhase.append(0)
								outBaselineCulAverWorsenList_diffPhase.append(diffCulPMAE)
						# 更新 超越baseline模型次数计数器
						elif round(culPMAE,2) < round(baselineModelCulRes,2):
							outBaselineCulMethodDict = dict()
							outBaselineCulMethodDict["row"] = resRow
							outBaselineCulMethodDict["col"] = resCol
							outBaselineCulMethodDict["predResult"] = culPMAE
							boldMethodCulList.append(outBaselineCulMethodDict)
							outBaselineCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均改善
							outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
						else:
							underBaselineCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均恶化
							outBaselineCulAverWorsenList_diffPhase[methodCol - 1] += diffCulPMAE
						# 与baseline相比PMAE的平均变化
						diffNonCulPMAE = abs(round(baselineModelNonCulRes,2) - round(nonCulPMAE,2))
						# 初始化 超越baseline模型次数计数器
						if len(outBaselineNonCulCounterList) < methodCol:
							if round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
								outBaselineNonCulMethodDict = dict()
								outBaselineNonCulMethodDict["row"] = resRow
								outBaselineNonCulMethodDict["col"] = resCol
								outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
								boldMethodNonCulList.append(outBaselineNonCulMethodDict)
								outBaselineNonCulCounterList.append(1)
								underBaselineNonCulCounterList.append(0)
								# 记录PMAE平均改善与恶化
								outBaselineNonCulAverImproList_diffPhase.append(diffNonCulPMAE)
								outBaselineNonCulAverWorsenList_diffPhase.append(0)
							else:
								outBaselineNonCulCounterList.append(0)
								underBaselineNonCulCounterList.append(1)
								# 记录PMAE平均改善与恶化
								outBaselineNonCulAverImproList_diffPhase.append(0)
								outBaselineNonCulAverWorsenList_diffPhase.append(diffNonCulPMAE)
						# 更新 超越baseline模型次数计数器
						elif round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
							outBaselineNonCulMethodDict = dict()
							outBaselineNonCulMethodDict["row"] = resRow
							outBaselineNonCulMethodDict["col"] = resCol
							outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
							boldMethodNonCulList.append(outBaselineNonCulMethodDict)
							outBaselineNonCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均改善
							outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
						else:
							underBaselineNonCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均恶化
							outBaselineNonCulAverWorsenList_diffPhase[methodCol - 1] += diffNonCulPMAE
						methodCol += 1

				if nanFlag== True:
					continue
					
				# 最左侧写入数据集名称
				if showModelName == True:
					if onePageOffset_dataDetail == 0:
						#print("inOnePage : "+str(inOnePage))
						#print("predLen : "+str(predLen))
						#print("dataRow : "+str(dataRow))
						#print("merge_range : "+str(dataRow)+" ~ "+str(dataRow + 1 + (predLen-1)*2))
						ws.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
				else:
					if inOnePage == False:
						ws.write(dataRow, initCol, dataName, normal)
						ws_single.write(dataRow, initCol, dataName, normal)
					elif onePageOffset_dataDetail == 0:
						ws.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
				# 数据集基本信息处同样写入数据集名称
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				culFormatedTrainData = singleDataDict["culFormatedTrainData"]
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)




				# 加粗超越baseline模型的结果
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					#print("A")
					for boldMethodDict in boldMethodCulList:
						ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					for boldMethodDict in boldMethodNonCulList:
						ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redBoldNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redBoldNum)
				else:
					#print("B")
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redNum)
				# 更新最佳次数计数器
				bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += 1
				bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += 1
				# 更新数据集序号
				dataIndex += 1
				# 更新数据名称所在行
				if showModelName == True:
					if inOnePage == False:
						dataRow = 2*dataIndex-1
					else:
						#dataRow_old = dataRow
						dataRow += predLen*2
						#print("updata dataRow: "+str(dataRow_old)+" -> "+str(dataRow))
				else:
					if inOnePage == False:
						dataRow = dataIndex
					else:
						dataRow += predLen
				# 更新数据集基本信息行号
				trainBaseRow += 1


			
				

			# 写入最佳次数
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, bestCulCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, bestNonCulCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineCulCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineNonCulCounter, normal)
					i += 1

			# 写入不同预测阶段平均改善误差
			ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			i = 1
			for outCulCounter in outBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverImproList_diffPhase[i-1]
				if outCulCounter == 0:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, round(diffCulPMAEinTestingPhase / outCulCounter,2), normal)
				i += 1
			i = 1
			for outNonCulCounter in outBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverImproList_diffPhase[i-1]
				if outNonCulCounter == 0:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, round( diffNonCulPMAEinTestingPhase / outNonCulCounter,3), normal)
				i += 1

			# 写入不同预测阶段平均恶化误差
			ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			i = 1
			for underCulCounter in underBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverWorsenList_diffPhase[i-1]
				if underCulCounter == 0:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round(diffCulPMAEinTestingPhase / underCulCounter,2), normal)
				i += 1
			i = 1
			for underNonCulCounter in underBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverWorsenList_diffPhase[i-1]
				if underNonCulCounter == 0:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round( diffNonCulPMAEinTestingPhase / underNonCulCounter,3), normal)
				i += 1


			if inOnePage == True:
				onePageOffset_dataDetail += trainBaseRow
				onePageOffset_predRes += 1
				totalCulBestList.append(bestCulCounterList)
				totalNonCulBestList.append(bestNonCulCounterList)
				totalCulBaselineList.append(outBaselineCulCounterList)
				totalNonCulBaselineList.append(outBaselineNonCulCounterList)

		# 写入总体平均改善误差


		# 写入总体平均恶化误差


		# 记录总和
		if inOnePage == True:
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalCulBestList[j][i-1]
					j += 1
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, totalCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalNonCulBestList[j][i-1]
					j += 1
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, totalCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalCulBaselineList[j][i-1]
						j += 1
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalNonCulBaselineList[j][i-1]
						j += 1
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1


	wb.close()


# 比较不同推参方法的PMAE分布结果 （五数概括法）
# fiveNumUniMethodList 被识别为用五数概括法展示。此时不会被 uniMethodList 使用
#
# uniMethodList 用于确定比较结果的对象. 
# 可以留空. 此时表示比较predictDict内所有的结果字典
# uniMethodList 可以接受以下两种格式的输入:
# 第一种:
# uniMethodList = [dictUniName, ...,]
# 此时只比较uniMethodList内的dictUniName字典之间的结果
# 第二种:
# uniMethodList = [uniMethodDict, ...,]
# uniMethodDict["dictUniName"] 		# 预测结果保存字典
# uniMethodDict["methodName"] 		# 推参方法. 留空时表示比较dictUniName下所有的推参方法
# uniMethodDict["measureName"] 		# 模型选择指标. 留空时则只考虑主指标
# uniMethodDict["nameTitle"] 		# 展示用名称 / 推参方法名称. 留空时则默认等于 "methodName (measureName)"
# 第一种输入等同于第二种输入除了dictUniName全留空的情形.
# 
# showModelName 决定是否展示具有最佳measureValue的"模型名称"(不同于"推参方法名称")
#
# baselineDict用于确定所有模型都会与之比较的对象。
# 超越baseline模型的结果会加粗。baselineDict的格式与uniMethodDict相同
#
# inOnePage = True 时会让不同预测阶段的结果都集中在同一页显示
def savePredictResultComparisonWithFiveNumResult(predictDict, reportName, uniMethodList = [], fiveNumUniMethodList = [], showModelName = True, baselineDict = None, inOnePage = False):
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	boldNum = reportUtilsTemplate.getBoldNumFormat(wb)
	redBoldNum = reportUtilsTemplate.getRedBoldNumFormat(wb)
	for dataType in predictDict:
		if dataType == "time":
			dataTypeName = "Time Data"
		elif dataType == "group":
			dataTypeName = "Group Data"
		failTimeCol = 0
		failNumCol = 1

		onePageOffset_dataDetail = 0
		onePageOffset_predRes = 0
		if inOnePage == True:
			# 按照数据类别以及预测区间划分工作簿
			ws = wb.add_worksheet(dataTypeName+"(累计PMAE)")
			ws_single = wb.add_worksheet(dataTypeName+"(单日PMAE)")
			predLen = len(predictDict[dataType])
			totalCulBestList = []
			totalNonCulBestList = []
			totalCulBaselineList = []
			totalNonCulBaselineList = []

		# 记录超越baseline模型结果的平均改善(全体预测阶段)
		outBaselineCulAverImproList_totalPhase = []
		outBaselineNonCulAverImproList_totalPhase = []
		# 记录超越baseline模型结果的平均恶化(全体预测阶段)
		outBaselineCulAverWorsenList_totalPhase = []
		outBaselineNonCulAverWorsenList_totalPhase = []

		for predInterval in predictDict[dataType]:
			if inOnePage == False:
				# 按照数据类别以及预测区间划分工作簿
				ws = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(累计PMAE)")
				ws_single = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"(单日PMAE)")
				predLen = 1
			# 写入数据集基本信息
			trainBaseCol = 0

			ws.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Testing Time", normal)
			ws.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Fault Num", normal)
			ws.set_column(trainBaseCol+1, trainBaseCol+1, 12)

			ws_single.merge_range(0 + onePageOffset_dataDetail, trainBaseCol, 0+ onePageOffset_dataDetail, trainBaseCol+2,  "Pred Point:"+str(int(predInterval*100))+"%", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol, dataTypeName, normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+2, "Total Testing Time", normal)
			ws_single.write(1 + onePageOffset_dataDetail, trainBaseCol+1, "Total Fault Num", normal)
			ws_single.set_column(trainBaseCol+1, trainBaseCol+1, 12)
			# 数据集序号
			dataIndex = 1
			# 数据名称所在行
			if showModelName == True:
				dataRow = 2*dataIndex-1
			else:
				dataRow = dataIndex
			dataRow += 1
			# 起始列
			initCol = 3
			# 写入标题
			ws.write(0, initCol, "Data Set", normal)
			ws_single.write(0, initCol, "Data Set", normal)
			# 确认 uniMethodList 类型
			if uniMethodList == []:
				finalUniMethodList = reportUtilsTemplate.getUniNameList(predictDict,dataType,predInterval)
			else:
				finalUniMethodList = uniMethodList
			# 记录每个方法在不同数据集拿到最佳结果的次数
			bestCulCounterList = []
			bestNonCulCounterList = []
			# 记录超越baseline模型结果的次数
			outBaselineCulCounterList = []
			outBaselineNonCulCounterList = []
			# 记录低于baseline模型结果的次数
			underBaselineCulCounterList = []
			underBaselineNonCulCounterList = []
			# 记录超越baseline模型结果的平均改善(不同预测阶段)
			outBaselineCulAverImproList_diffPhase = []
			outBaselineNonCulAverImproList_diffPhase = []
			# 记录超越baseline模型结果的平均恶化(不同预测阶段)
			outBaselineCulAverWorsenList_diffPhase = []
			outBaselineNonCulAverWorsenList_diffPhase = []
			# 初始化数据集基本信息行号
			trainBaseRow = 2
			# 首次写入方法名称
			fristWrite = True
			# 开始遍历数据集
			for dataName in predictDict[dataType][predInterval]:
				# 估计值非法时跳过统计
				nanFlag = False
				

				singleDataDict = predictDict[dataType][predInterval][dataName]
				
				# 查找baseline模型的结果
				baselineModelCulRes = -1
				baselineModelNonCulRes = -1
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					baselineUniName = baselineDict["dictUniName"]
					baselineMethodName = baselineDict["methodName"]
					# 模型选择指标
					baselineMeasureName = reportUtilsTemplate.getMainMeasureName(predictDict, baselineUniName, baselineMethodName)
					# 获得完整训练数据的Measure列表
					measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(predictDict, baselineUniName, dataType, dataName, predInterval, baselineMethodName, baselineMeasureName)
					# measureValue最小的模型的index
					minimeasureValueIndex = measureList[0][1]
					# measureValue最小的模型的模型类别
					modelType = modelIndexMateList[ minimeasureValueIndex ][0]
					# measureValue最小的模型的模型名称
					modelName = modelIndexMateList[ minimeasureValueIndex ][1]
					# 预测性能结果
					baselineModelCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["culPMAE"]
					baselineModelNonCulRes = singleDataDict[baselineUniName][baselineMethodName][modelType][modelName]["nonCulPMAE"]
				# 待比较方法下标
				methodCol = 1
				bestCulMethodDict = None
				bestNonCulMethodDict = None
				boldMethodCulList = []
				boldMethodNonCulList = []


				for dictUniName in fiveNumUniMethodList:
					for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
						measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
						nameTitle = methodName + " ("+measureName+")"
						for modelType in predictDict[dataType][predInterval][dataName][dictUniName][methodName]:
							modelResDict = predictDict[dataType][predInterval][dataName][dictUniName][methodName][modelType]
							culFiveNumPMAEList = []
							nonCulFiveNumPMAEList = []
							modelNameStr = "("+modelType+")"
							
							for modelName in modelResDict:
								culPMAE = modelResDict[modelName]["culPMAE"]
								culFiveNumPMAEList.append(culPMAE)
								nonCulPMAE = modelResDict[modelName]["nonCulPMAE"]
								nonCulFiveNumPMAEList.append(nonCulPMAE)
							
							# 计算五数概括
							min_val = np.min(culFiveNumPMAEList)
							q1 = np.percentile(culFiveNumPMAEList, 25)  # 第一四分位数
							median = np.median(culFiveNumPMAEList)      # 中位数
							q3 = np.percentile(culFiveNumPMAEList, 75)  # 第三四分位数
							max_val = np.max(culFiveNumPMAEList)

							# 性能指标所在行与列
							resRow = dataRow + onePageOffset_predRes
							resCol = methodCol + initCol
							
							# 写入 推参方法名称
							if fristWrite == True:
								ws.merge_range(0, resCol, 0, resCol + 4, nameTitle, normal)
							ws.write(1, resCol + 0, "min", normal)
							ws.write(1, resCol + 1, "Q1", normal)
							ws.write(1, resCol + 2, "median", normal)
							ws.write(1, resCol + 3, "Q3", normal)
							ws.write(1, resCol + 4, "max", normal)

							# 写入 预测性能指标
							ws.write(resRow, resCol + 0, min_val, numFormat)
							ws.write(resRow, resCol + 1, q1, numFormat)
							ws.write(resRow, resCol + 2, median, numFormat)
							ws.write(resRow, resCol + 3, q3, numFormat)
							ws.write(resRow, resCol + 4, max_val, numFormat)
							
							if showModelName == True:
								# 写入 模型名称
								ws.merge_range(dataRow+1, resCol, dataRow+1, resCol + 4, modelNameStr, normal)

							methodCol += 5
				fristWrite = False




				# 逐个写入待比较方法
				for uniMethodEle in finalUniMethodList:
					# 推参方法
					methodNameList = []
					# 预测结果保存字典
					if isinstance(uniMethodEle, str):
						dictUniName = uniMethodEle
						for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
							methodNameList.append(methodName)
					elif isinstance(uniMethodEle, dict):
						dictUniName = uniMethodEle["dictUniName"]
						if "methodName" not in uniMethodEle:
							for methodName in predictDict[dataType][predInterval][dataName][dictUniName]:
								methodNameList.append(methodName)
						else:
							methodName = uniMethodEle["methodName"]
							methodNameList.append(methodName)
					else:
						raise
					for methodName in methodNameList:

						isContinue = False
						for fiveNumDictUniName in fiveNumUniMethodList:
							for fiveNumMethodName in predictDict[dataType][predInterval][dataName][dictUniName]:
								if methodName == fiveNumMethodName and dictUniName == fiveNumDictUniName:
									isContinue = True
						if isContinue == True:
							continue

						# 模型选择指标
						if isinstance(uniMethodEle, str):
							measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
						elif isinstance(uniMethodEle, dict):
							if "measureName" not in uniMethodEle:
								measureName = reportUtilsTemplate.getMainMeasureName(predictDict, dictUniName, methodName)
							else:
								measureName = uniMethodEle["measureName"]
						# 展示用名称 / 推参方法名称
						if isinstance(uniMethodEle, str):
							nameTitle = methodName + " ("+measureName+")"
						elif isinstance(uniMethodEle, dict):
							if "nameTitle" not in uniMethodEle:
								nameTitle = methodName + " ("+measureName+")"
							else:
								nameTitle = uniMethodEle["nameTitle"]
						# 获得完整训练数据的Measure列表
						measureList, modelIndexMateList = reportUtilsTemplate.getTrainDataMeasureList(predictDict, dictUniName, dataType, dataName, predInterval, methodName, measureName)
						# measureValue最小的模型的measureValue
						minimeasureValue = measureList[0][0]
						# measureValue最小的模型的index
						minimeasureValueIndex = measureList[0][1]
						# measureValue最小的模型的模型类别
						modelType = modelIndexMateList[ minimeasureValueIndex ][0]
						# measureValue最小的模型的模型名称
						modelName = modelIndexMateList[ minimeasureValueIndex ][1]
						# measureValue最小的模型的参数
						paraList = modelIndexMateList[ minimeasureValueIndex ][2]
						# 模型的别称(用于生成报告时模型的名称显示)
						alias = modelIndexMateList[ minimeasureValueIndex ][4]
						if alias is None:
							modelNameStr = "("+modelType+"-"+modelName+")"
						else:
							modelNameStr = "("+alias+")"
						# 预测性能结果
						culPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["culPMAE"]
						nonCulPMAE = singleDataDict[dictUniName][methodName][modelType][modelName]["nonCulPMAE"]
						
						if minimeasureValue == float("inf"):
							nanFlag = True
							continue
						elif minimeasureValue == float("-inf"):
							nanFlag = True
							continue
						elif isinstance(minimeasureValue, str):
							nanFlag = True
							continue
						elif math.isnan(minimeasureValue):
							nanFlag = True
							continue


						if culPMAE == float("inf"):
							culPMAE = "inf"
							continue
						elif culPMAE == float("-inf"):
							culPMAE = "-inf"
							continue
						elif isinstance(culPMAE, str):
							culPMAE = "str"
							continue
						elif math.isnan(culPMAE):
							culPMAE = "Nan"
							continue

						# 性能指标所在行与列
						resRow = dataRow + onePageOffset_predRes
						resCol = methodCol + initCol
						# 写入 推参方法名称
						ws.write(0, resCol, nameTitle, normal)
						ws_single.write(0, resCol, nameTitle, normal)
						# 写入 预测性能指标
						ws.write(resRow, resCol, culPMAE, numFormat)
						ws_single.write(resRow, resCol, nonCulPMAE, numFormat)
						if showModelName == True:
							# 写入 模型名称
							ws.write(dataRow+1, resCol, modelNameStr, normal)
							ws_single.write(dataRow+1, resCol, modelNameStr, normal)
						# 记录 最佳模型(累计PMAE)
						if bestCulMethodDict is None:
							bestCulMethodDict = dict()
							bestCulMethodDict["row"] = resRow
							bestCulMethodDict["col"] = resCol
							bestCulMethodDict["methodCol"] = methodCol
							bestCulMethodDict["predResult"] = culPMAE
						# 更新 最佳模型(累计PMAE)
						elif round(culPMAE,2) < round(bestCulMethodDict["predResult"],2):
							bestCulMethodDict["row"] = resRow
							bestCulMethodDict["col"] = resCol
							bestCulMethodDict["methodCol"] = methodCol
							bestCulMethodDict["predResult"] = culPMAE
						# 记录 最佳模型(单日PMAE)
						if bestNonCulMethodDict is None:
							bestNonCulMethodDict = dict()
							bestNonCulMethodDict["row"] = resRow
							bestNonCulMethodDict["col"] = resCol
							bestNonCulMethodDict["methodCol"] = methodCol
							bestNonCulMethodDict["predResult"] = nonCulPMAE
						# 更新 最佳模型(单日PMAE)
						elif round(nonCulPMAE,2) < round(bestNonCulMethodDict["predResult"],2):
							bestNonCulMethodDict["row"] = resRow
							bestNonCulMethodDict["col"] = resCol
							bestNonCulMethodDict["methodCol"] = methodCol
							bestNonCulMethodDict["predResult"] = nonCulPMAE
						# 初始化 最佳次数计数器
						if len(bestCulCounterList) < methodCol:
							bestCulCounterList.append(0)
						if len(bestNonCulCounterList) < methodCol:
							bestNonCulCounterList.append(0)

						# 与baseline相比PMAE的平均变化
						diffCulPMAE = abs(round(baselineModelCulRes,2) - round(culPMAE,2))
						# 初始化 超越baseline模型次数计数器
						if len(outBaselineCulCounterList) < methodCol:
							if round(culPMAE,2) < round(baselineModelCulRes,2):
								outBaselineCulMethodDict = dict()
								outBaselineCulMethodDict["row"] = resRow
								outBaselineCulMethodDict["col"] = resCol
								outBaselineCulMethodDict["predResult"] = culPMAE
								boldMethodCulList.append(outBaselineCulMethodDict)
								outBaselineCulCounterList.append(1)
								underBaselineCulCounterList.append(0)
								# 记录PMAE平均改善与恶化
								outBaselineCulAverImproList_diffPhase.append(diffCulPMAE)
								outBaselineCulAverWorsenList_diffPhase.append(0)
							else:
								outBaselineCulCounterList.append(0)
								underBaselineCulCounterList.append(1)
								# 记录PMAE平均改善与恶化
								outBaselineCulAverImproList_diffPhase.append(0)
								outBaselineCulAverWorsenList_diffPhase.append(diffCulPMAE)
						# 更新 超越baseline模型次数计数器
						elif round(culPMAE,2) < round(baselineModelCulRes,2):
							outBaselineCulMethodDict = dict()
							outBaselineCulMethodDict["row"] = resRow
							outBaselineCulMethodDict["col"] = resCol
							outBaselineCulMethodDict["predResult"] = culPMAE
							boldMethodCulList.append(outBaselineCulMethodDict)
							outBaselineCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均改善
							outBaselineCulAverImproList_diffPhase[methodCol - 1] += diffCulPMAE
						else:
							underBaselineCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均恶化
							outBaselineCulAverWorsenList_diffPhase[methodCol - 1] += diffCulPMAE
						# 与baseline相比PMAE的平均变化
						diffNonCulPMAE = abs(round(baselineModelNonCulRes,2) - round(nonCulPMAE,2))
						# 初始化 超越baseline模型次数计数器
						if len(outBaselineNonCulCounterList) < methodCol:
							if round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
								outBaselineNonCulMethodDict = dict()
								outBaselineNonCulMethodDict["row"] = resRow
								outBaselineNonCulMethodDict["col"] = resCol
								outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
								boldMethodNonCulList.append(outBaselineNonCulMethodDict)
								outBaselineNonCulCounterList.append(1)
								underBaselineNonCulCounterList.append(0)
								# 记录PMAE平均改善与恶化
								outBaselineNonCulAverImproList_diffPhase.append(diffNonCulPMAE)
								outBaselineNonCulAverWorsenList_diffPhase.append(0)
							else:
								outBaselineNonCulCounterList.append(0)
								underBaselineNonCulCounterList.append(1)
								# 记录PMAE平均改善与恶化
								outBaselineNonCulAverImproList_diffPhase.append(0)
								outBaselineNonCulAverWorsenList_diffPhase.append(diffNonCulPMAE)
						# 更新 超越baseline模型次数计数器
						elif round(nonCulPMAE,2) < round(baselineModelNonCulRes,2):
							outBaselineNonCulMethodDict = dict()
							outBaselineNonCulMethodDict["row"] = resRow
							outBaselineNonCulMethodDict["col"] = resCol
							outBaselineNonCulMethodDict["predResult"] = nonCulPMAE
							boldMethodNonCulList.append(outBaselineNonCulMethodDict)
							outBaselineNonCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均改善
							outBaselineNonCulAverImproList_diffPhase[methodCol - 1] += diffNonCulPMAE
						else:
							underBaselineNonCulCounterList[methodCol - 1] += 1
							# 记录PMAE平均恶化
							outBaselineNonCulAverWorsenList_diffPhase[methodCol - 1] += diffNonCulPMAE
						methodCol += 1

				if nanFlag== True:
					continue

				# 最左侧写入数据集名称
				if showModelName == True:
					if onePageOffset_dataDetail == 0:
						#print("inOnePage : "+str(inOnePage))
						#print("predLen : "+str(predLen))
						#print("dataRow : "+str(dataRow))
						#print("merge_range : "+str(dataRow)+" ~ "+str(dataRow + 1 + (predLen-1)*2))
						ws.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + 1 + (predLen-1)*2, initCol, dataName, normal)
				else:
					if inOnePage == False:
						ws.write(dataRow, initCol, dataName, normal)
						ws_single.write(dataRow, initCol, dataName, normal)
					elif onePageOffset_dataDetail == 0:
						ws.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
						ws_single.merge_range(dataRow, initCol, dataRow + predLen - 1, initCol, dataName, normal)
				# 数据集基本信息处同样写入数据集名称
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol, dataName, normal)
				culFormatedTrainData = singleDataDict["culFormatedTrainData"]
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+1, culFormatedTrainData[-1][failTimeCol], normal)
				ws_single.write(trainBaseRow + onePageOffset_dataDetail, trainBaseCol+2, culFormatedTrainData[-1][failNumCol], normal)



				"""
				# 加粗超越baseline模型的结果
				if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
					for boldMethodDict in boldMethodCulList:
						ws.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					for boldMethodDict in boldMethodNonCulList:
						ws_single.write(boldMethodDict["row"], boldMethodDict["col"], boldMethodDict["predResult"], boldNum)
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redBoldNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redBoldNum)
				else:
					# 加红同一数据集下的最佳结果
					ws.write(bestCulMethodDict["row"], bestCulMethodDict["col"], bestCulMethodDict["predResult"], redNum)
					ws_single.write(bestNonCulMethodDict["row"], bestNonCulMethodDict["col"], bestNonCulMethodDict["predResult"], redNum)
				"""

				# 更新最佳次数计数器 暂时删除
				#bestCulCounterList[ bestCulMethodDict["methodCol"] - 1 ] += 1
				#bestNonCulCounterList[ bestNonCulMethodDict["methodCol"] - 1 ] += 1
				# 更新数据集序号
				dataIndex += 1
				# 更新数据名称所在行
				if showModelName == True:
					if inOnePage == False:
						dataRow = 2*dataIndex-1
					else:
						#dataRow_old = dataRow
						dataRow += predLen*2
						#print("updata dataRow: "+str(dataRow_old)+" -> "+str(dataRow))
				else:
					if inOnePage == False:
						dataRow = dataIndex
					else:
						dataRow += predLen
				# 更新数据集基本信息行号
				trainBaseRow += 1


			
				

			# 写入最佳次数
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Best Counter", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, bestCulCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, bestNonCulCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Out Baseline", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineCulCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, outBaselineNonCulCounter, normal)
					i += 1

			# 写入不同预测阶段平均改善误差
			ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol, "Aver Improvement", normal)
			i = 1
			for outCulCounter in outBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverImproList_diffPhase[i-1]
				if outCulCounter == 0:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 2*predLen + onePageOffset_predRes + 3, initCol + i, round(diffCulPMAEinTestingPhase / outCulCounter,2), normal)
				i += 1
			i = 1
			for outNonCulCounter in outBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverImproList_diffPhase[i-1]
				if outNonCulCounter == 0:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 2*predLen + onePageOffset_predRes + 3 , initCol + i, round( diffNonCulPMAEinTestingPhase / outNonCulCounter,3), normal)
				i += 1

			# 写入不同预测阶段平均恶化误差
			ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol, "Aver Worsening", normal)
			i = 1
			for underCulCounter in underBaselineCulCounterList:
				diffCulPMAEinTestingPhase = outBaselineCulAverWorsenList_diffPhase[i-1]
				if underCulCounter == 0:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round(diffCulPMAEinTestingPhase / underCulCounter,2), normal)
				i += 1
			i = 1
			for underNonCulCounter in underBaselineNonCulCounterList:
				diffNonCulPMAEinTestingPhase = outBaselineNonCulAverWorsenList_diffPhase[i-1]
				if underNonCulCounter == 0:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, -1, normal)
				else:
					ws_single.write(dataRow + 3*predLen + onePageOffset_predRes + 4, initCol + i, round( diffNonCulPMAEinTestingPhase / underNonCulCounter,3), normal)
				i += 1


			if inOnePage == True:
				onePageOffset_dataDetail += trainBaseRow
				onePageOffset_predRes += 1
				totalCulBestList.append(bestCulCounterList)
				totalNonCulBestList.append(bestNonCulCounterList)
				totalCulBaselineList.append(outBaselineCulCounterList)
				totalNonCulBaselineList.append(outBaselineNonCulCounterList)

		# 写入总体平均改善误差


		# 写入总体平均恶化误差


		# 记录总和
		if inOnePage == True:
			ws.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			ws_single.write(dataRow + onePageOffset_predRes + 1, initCol, "Total", normal)
			i = 1
			for bestCulCounter in bestCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalCulBestList[j][i-1]
					j += 1
				ws.write(dataRow + onePageOffset_predRes + 1, initCol + i, totalCounter, normal)
				i += 1
			i = 1
			for bestNonCulCounter in bestNonCulCounterList:
				j = 0
				totalCounter = 0	
				while j < predLen:
					totalCounter += totalNonCulBestList[j][i-1]
					j += 1
				ws_single.write(dataRow + onePageOffset_predRes + 1 , initCol + i, totalCounter, normal)
				i += 1

			if baselineDict is not None and "dictUniName" in baselineDict and "methodName" in baselineDict:
				ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol, "Total", normal)
				i = 1
				for outBaselineCulCounter in outBaselineCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalCulBaselineList[j][i-1]
						j += 1
					ws.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1
				i = 1
				for outBaselineNonCulCounter in outBaselineNonCulCounterList:
					j = 0
					totalCounter = 0	
					while j < predLen:
						totalCounter += totalNonCulBaselineList[j][i-1]
						j += 1
					ws_single.write(dataRow + predLen + onePageOffset_predRes + 2, initCol + i, totalCounter, normal)
					i += 1


	wb.close()


# 模拟估计结果
# mergeDataSet 为 False 时， 不同预测阶段的各个数据集的结果分开显示
# mergeDataSet 为 True 时， 不同预测阶段的各个数据集的结果放一起显示(不同预测阶段的仍然分开)
def saveSimulationEstimateBaseResult(estimateDict, reportName, dictUniName, mergeDataSet = False):
	# 保存数据集
	wb = xlsxwriter.Workbook(reportName)
	normal = reportUtilsTemplate.getNormalFormat(wb)
	redNum = reportUtilsTemplate.getRedNumFormat(wb)
	numFormat = reportUtilsTemplate.getNumFormat(wb)
	# 保存数据
	for dataType in estimateDict:
		if dataType == "time":
			dataTypeName = "时间"
		elif dataType == "group":
			dataTypeName = "组"
		failNumCol = 1
		failTimeCol = 0
		for predInterval in estimateDict[dataType]:
			methodNameList = reportUtilsTemplate.getMethodNameList(estimateDict, dictUniName)
			for methodName in methodNameList:
				measureNameList = reportUtilsTemplate.getMeasureNameList(estimateDict, dictUniName, methodName)
				measureLen = len(measureNameList)
				ws_trainBase_diff = wb.add_worksheet(str(int(predInterval*100))+"%"+dataTypeName+"("+str(methodName)+")新")
				trainBaseCol = 0
				if mergeDataSet == True:
					ws_trainBase_diff.write(1, 0, "Data Set", normal)
					trainBaseCol = 1
					ws_trainBase_diff.merge_range(0, 0, 0, trainBaseCol+measureLen+2-1, "All Data Set", normal)
					trainBaseRow = 2
					initRow = 2
				for dataName in estimateDict[dataType][predInterval]:
					dataDict = estimateDict[dataType][predInterval][dataName]
					# 写入估计指标
					methodLen = len(dataDict[dictUniName])
					if mergeDataSet == False:
						trainBaseRow = 2
						initRow = 2
						ws_trainBase_diff.merge_range(0, trainBaseCol, 0, trainBaseCol+measureLen+2-1, dataName, normal)
					ws_trainBase_diff.write(1, trainBaseCol, "Model Type", normal)
					ws_trainBase_diff.write(1, trainBaseCol+1, "Model Name", normal)
					measureNameIndex = 1
					for measureName in measureNameList:
						ws_trainBase_diff.write(1, trainBaseCol+1+measureNameIndex, measureName, normal)
						measureNameIndex += 1

					for modelType in dataDict[dictUniName][methodName]:
						for modelName in dataDict[dictUniName][methodName][modelType]:
							ws_trainBase_diff.write(trainBaseRow, trainBaseCol, modelType, normal)
							ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1, modelName, normal)
							ws_trainBase_diff.write(trainBaseRow, 0, dataName, normal)

							resDict = dataDict[dictUniName][methodName][modelType][modelName]
							maxRow = 0
							measureNameIndex = 1
							for measureName in resDict["measureValueDict"]:
								ws_trainBase_diff.write(1, trainBaseCol+1+measureNameIndex, measureName, normal)

								trainBaseRow = initRow

								measureValue = resDict["measureValueDict"][measureName]

								# 识别 measureValue 的类型
								if not isinstance(measureValue,list):

									if measureValue == float("inf"):
										measureValue = "inf"
									elif measureValue == float("-inf"):
										measureValue = "-inf"
									elif isinstance(measureValue, str):
										pass
									elif isinstance(measureValue, list):
										measureValue = str(measureValue)
									elif math.isnan(measureValue):
										measureValue = "Nan"
									ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1+measureNameIndex, measureValue, numFormat)
									trainBaseRow += 1
								else:
									for eleNum in measureValue:
										try:
											ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1+measureNameIndex, eleNum)
										except Exception as e:
											ws_trainBase_diff.write(trainBaseRow, trainBaseCol+1+measureNameIndex, str(eleNum))
										trainBaseRow += 1
								measureNameIndex += 1

								if trainBaseRow > maxRow:
									maxRow = trainBaseRow
							initRow = maxRow

					if mergeDataSet == False:
						trainBaseCol = trainBaseCol+measureLen+2

	wb.close()
	return reportName
