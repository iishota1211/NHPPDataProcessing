# v0.3
# 修复了AICC公式的数据长度判断条件
# v0.2
# 修复了AICC公式

import math
from classicUtils import existSRM, modelTool
def AIC(LL, paraLen):
	return -2 * LL + 2 * paraLen

def BIC(LL, paraLen, dataLen):
	try:
		return -2 * LL + paraLen * math.log(dataLen)
	except Exception as e:
		print("measure.BIC() : dataLen ("+str(dataLen)+") is not excepted ")
		raise e

def AICC1(LL, paraLen, dataLen):
	# 根据AICC的计算公式, 数据长度不能太小
	if dataLen <= paraLen + 1:
		return False
	else:
		return -2 * LL + 2 * paraLen + 2*paraLen*(paraLen + 1)/(dataLen-paraLen-1)

def AICC2(LL, paraLen, dataLen):
	# 根据AICC的计算公式, 数据长度不能太小
	if dataLen <= paraLen + 2:
		return False
	else:
		penaltyTerm = 2*(paraLen+1)*(paraLen+2)/(dataLen-paraLen-2)
		return -2 * LL + 2 * paraLen + penaltyTerm

def CAIC(LL, paraLen, dataLen):
	try:
		return -2 * LL + paraLen * (math.log(dataLen) + 1)
	except Exception as e:
		print("measure.BIC() : dataLen ("+str(dataLen)+") is not excepted ")
		raise e

def calcMAE(paraList, meanValueFun, culFormatedTrainData):
	culTotalLoss = 0
	nonCulTotalLoss = 0
	oldEstNum = 0
	oldNum = 0
	for nowTime,nowNum in culFormatedTrainData:
		estNum = float(meanValueFun(nowTime, paraList))
		intervalNowNum = nowNum - oldNum
		intervalEstNum = estNum - oldEstNum
		culTotalLoss += abs(estNum - nowNum)
		nonCulTotalLoss += abs(intervalEstNum - intervalNowNum)
		oldNum = nowNum
		oldEstNum = estNum
	culLossValue = culTotalLoss / len(culFormatedTrainData)
	nonCulLossValue = nonCulTotalLoss / len(culFormatedTrainData)
	return [nonCulLossValue, culLossValue]

def MAE(culFormatedTrainData, culFormatedEstData):
	culTotalLoss = 0
	nonCulTotalLoss = 0
	oldEstNum = 0
	oldNum = 0
	i = 0
	for nowTime,nowNum in culFormatedTrainData:
		estNum = culFormatedEstData[i][1]
		intervalNowNum = nowNum - oldNum
		intervalEstNum = estNum - oldEstNum
		culTotalLoss += abs(estNum - nowNum)
		nonCulTotalLoss += abs(intervalEstNum - intervalNowNum)
		oldNum = nowNum
		oldEstNum = estNum
	culLossValue = culTotalLoss / len(culFormatedTrainData)
	nonCulLossValue = nonCulTotalLoss / len(culFormatedTrainData)
	return [nonCulLossValue, culLossValue]

# 用户尽可能提供以下信息. extraMeasure() 会尽可能根据用户已提供信息尽量满足 extraMeasureList 的指标需求
# nowInfoDict["mainMeasureName"]
# nowInfoDict["mainMeasureValue"]
# nowInfoDict["paraLen"]
# nowInfoDict["paraList"]
# nowInfoDict["dataType"]
# nowInfoDict["meanValueFun"]
# nowInfoDict["intensityFun"]
# nowInfoDict["modelDict"]
# nowInfoDict["dataLen"]
# nowInfoDict["culFormatedTrainData"]
# nowInfoDict["culFormatedEstData"]
# nowInfoDict["likelihoodFun"]
# nowInfoDict["methodDict"]
# nowInfoDict["LL"]
def extraMeasure(nowInfoDict):
	measureNameList = []
	measureValueDict = dict()

	mainMeasureName = None
	mainMeasureValue = None
	paraList = None
	paraLen = None
	dataType = None
	meanValueFun = None
	intensityFun = None
	likelihoodFun = None
	modelDict = None
	culFormatedTrainData = None
	culFormatedEstData = None
	dataLen = None
	methodDict = None
	tempLL = None

	if "LL" in nowInfoDict:
		tempLL = nowInfoDict["LL"]
	if "mainMeasureName" in nowInfoDict:
		mainMeasureName = nowInfoDict["mainMeasureName"]
		measureNameList.append(mainMeasureName)
	if "mainMeasureValue" in nowInfoDict:
		mainMeasureValue = nowInfoDict["mainMeasureValue"]
		if mainMeasureName is not None :
			measureValueDict[mainMeasureName] = mainMeasureValue
	if "paraLen" in nowInfoDict:
		paraLen = nowInfoDict["paraLen"]
	if "paraList" in nowInfoDict:
		paraList = nowInfoDict["paraList"]
		paraLen = len(paraList)
		if paraLen is not None:
			if paraLen != len(paraList):
				raise
	if "dataType" in nowInfoDict:
		dataType = nowInfoDict["dataType"]
	if "modelDict" in nowInfoDict:
		modelDict = nowInfoDict["modelDict"]
		if "modelType" in modelDict and "modelName" in modelDict:
			meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
			intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
			if dataType is not None:
				likelihoodFun, likelihoodFun_backup = modelTool.logLikelihoodFunction(modelDict, dataType)
	if "meanValueFun" in nowInfoDict:
		meanValueFun = nowInfoDict["meanValueFun"]
	if "intensityFun" in nowInfoDict:
		intensityFun = nowInfoDict["intensityFun"]
	if "likelihoodFun" in nowInfoDict:
		likelihoodFun = nowInfoDict["likelihoodFun"]
	if "meanValueFun_backup" in nowInfoDict:
		meanValueFun_backup = nowInfoDict["meanValueFun_backup"]
	if "intensityFun_backup" in nowInfoDict:
		intensityFun_backup = nowInfoDict["intensityFun_backup"]
	if "likelihoodFun_backup" in nowInfoDict:
		likelihoodFun_backup = nowInfoDict["likelihoodFun_backup"]
	if "dataLen" in nowInfoDict:
		dataLen = nowInfoDict["dataLen"]
	if "culFormatedTrainData" in nowInfoDict:
		culFormatedTrainData = nowInfoDict["culFormatedTrainData"]
		if dataLen is not None:
			if dataLen != len(culFormatedTrainData):
				raise
		elif dataLen is None:
			dataLen = len(culFormatedTrainData)
	if "culFormatedEstData" in nowInfoDict:
		culFormatedEstData = nowInfoDict["culFormatedEstData"]
	if "methodDict" in nowInfoDict:
		methodDict = nowInfoDict["methodDict"]

	# 可选计算额外的指标
	if methodDict == None:
		return [measureNameList, measureValueDict]
	if "extraMeasureList" not in methodDict:
		return [measureNameList, measureValueDict]
	if "extraMeasureList" in methodDict:
		extraMeasureList = methodDict["extraMeasureList"]
		if mainMeasureName == None and mainMeasureValue == None:
			if methodName in methodDict["methodName"]:
				methodName = methodDict["methodName"]
				if methodName == "MLE" and "LL" not in extraMeasureList:
					extraMeasureList.append("LL")
				if methodName == "LSE" and "MSE" not in extraMeasureList:
					extraMeasureList.append("MSE")
		for extraMeasureName in extraMeasureList:
			measureValue = None
			if extraMeasureName == "MAE":
				if culFormatedTrainData is not None and culFormatedEstData is not None:
					nonCulLossValue, culLossValue = MAE(culFormatedTrainData, culFormatedEstData)
					measureNameList.append("culMAE")
					measureValueDict["culMAE"] = culLossValue
					measureNameList.append("nonCulMAE")
					measureValueDict["nonCulMAE"] = nonCulLossValue
				elif culFormatedTrainData is not None and meanValueFun_backup is not None and paraList is not None:
					nonCulLossValue, culLossValue = calcMAE(paraList, meanValueFun_backup, culFormatedTrainData)
					measureNameList.append("culMAE")
					measureValueDict["culMAE"] = culLossValue
					measureNameList.append("nonCulMAE")
					measureValueDict["nonCulMAE"] = nonCulLossValue
				elif culFormatedTrainData is not None and meanValueFun is not None and paraList is not None:
					nonCulLossValue, culLossValue = calcMAE(paraList, meanValueFun, culFormatedTrainData)
					measureNameList.append("culMAE")
					measureValueDict["culMAE"] = culLossValue
					measureNameList.append("nonCulMAE")
					measureValueDict["nonCulMAE"] = nonCulLossValue
			if extraMeasureName == "MSE":
				if "MSE" in measureValueDict:
					continue
				if paraList is not None and meanValueFun is not None and culFormatedTrainData is not None:
					from classicGlobalLib import classicLSE
					MSE = classicLSE.lossFun(paraList, meanValueFun, culFormatedTrainData)
					measureNameList.append(extraMeasureName)
					measureValueDict[extraMeasureName] = MSE
			if extraMeasureName == "LL":
				if "LL" in measureValueDict:
					continue
				if tempLL is not None:
					measureNameList.append(extraMeasureName)
					measureValueDict[extraMeasureName] = tempLL
					continue
				if dataType == None or dataType == "time":
					if likelihoodFun_backup is not None and paraList is not None and meanValueFun_backup is not None and culFormatedTrainData is not None and intensityFun_backup is not None:
						LL = float(likelihoodFun_backup(paraList, culFormatedTrainData, meanValueFun_backup, intensityFun_backup))
						measureNameList.append(extraMeasureName)
						measureValueDict[extraMeasureName] = LL
					elif likelihoodFun is not None and paraList is not None and meanValueFun is not None and culFormatedTrainData is not None and intensityFun is not None:
						LL = likelihoodFun(paraList, culFormatedTrainData, meanValueFun, intensityFun)
						measureNameList.append(extraMeasureName)
						measureValueDict[extraMeasureName] = LL
				elif dataType == "group":
					if likelihoodFun_backup is not None and paraList is not None and meanValueFun_backup is not None and culFormatedTrainData is not None:
						LL = float(likelihoodFun_backup(paraList, culFormatedTrainData, meanValueFun_backup, None))
						measureNameList.append(extraMeasureName)
						measureValueDict[extraMeasureName] = LL
					elif likelihoodFun is not None and paraList is not None and meanValueFun is not None and culFormatedTrainData is not None:
						LL = likelihoodFun(paraList, culFormatedTrainData, meanValueFun, None)
						measureNameList.append(extraMeasureName)
						measureValueDict[extraMeasureName] = LL
			if extraMeasureName == "AIC" or extraMeasureName == "BIC" or extraMeasureName == "AICC2" or extraMeasureName == "AICC1" or extraMeasureName == "CAIC":
				if extraMeasureName in measureValueDict:
					continue
				if paraLen == None:
					continue
				if extraMeasureName != "AIC" and dataLen == None:
					continue
				LL = None
				if "LL" in measureValueDict:
					LL = measureValueDict["LL"]
				elif tempLL is not None:
					LL = tempLL
				else:
					if dataType == None or dataType == "time":
						if likelihoodFun_backup is not None and paraList is not None and meanValueFun_backup is not None and culFormatedTrainData is not None and intensityFun_backup is not None:
							LL = float(likelihoodFun_backup(paraList, culFormatedTrainData, meanValueFun_backup, intensityFun_backup))
						elif likelihoodFun is not None and paraList is not None and meanValueFun is not None and culFormatedTrainData is not None and intensityFun is not None:
							LL = likelihoodFun(paraList, culFormatedTrainData, meanValueFun, intensityFun)
					elif dataType == "group":
						if likelihoodFun_backup is not None and paraList is not None and meanValueFun_backup is not None and culFormatedTrainData is not None:
							LL = float(likelihoodFun_backup(paraList, culFormatedTrainData, meanValueFun_backup, None))
						elif likelihoodFun is not None and paraList is not None and meanValueFun is not None and culFormatedTrainData is not None:
							LL = likelihoodFun(paraList, culFormatedTrainData, meanValueFun, None)
					tempLL = LL
				if extraMeasureName == "AIC":
					measureValue = AIC(LL, paraLen)
				if extraMeasureName == "BIC":
					measureValue = BIC(LL, paraLen, dataLen)
				if extraMeasureName == "AICC1":
					measureValue = AICC1(LL, paraLen, dataLen)
				if extraMeasureName == "AICC2":
					measureValue = AICC2(LL, paraLen, dataLen)
				if extraMeasureName == "CAIC":
					measureValue = CAIC(LL, paraLen, dataLen)
				measureNameList.append(extraMeasureName)
				measureValueDict[extraMeasureName] = measureValue
	return [measureNameList, measureValueDict]