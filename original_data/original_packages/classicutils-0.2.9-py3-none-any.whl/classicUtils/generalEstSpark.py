import copy, redis, pickle, hashlib, time, random
from classicUtils import global_variables, SRMtool
from tqdm import tqdm

# 主逻辑
def main(dataSetDict,modelList,methodList,dictUniName, debugServerInfoDict = None, sparkFun = None, redisConfDict = None):
	# 二周目返还spark计算结果
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			redisHost = redisConfDict["host"] # "10.30.87.10"
			redisPassword = redisConfDict["password"] # "wJc@2410"
			redisPort = redisConfDict["port"] # 6379
			if "databaseNum" in redisConfDict:
				redisDbNum = redisConfDict["databaseNum"] # 0
			else:
				redisDbNum = 0
			if global_variables.sparkTaskCounter != -1 :
				client = redis.Redis(
					host=redisHost,
					port=redisPort,
					db=redisDbNum,
					password=redisPassword,
					decode_responses=False
				)
		bar = tqdm(len(global_variables.sparkTaskList))
	resDict = copy.deepcopy(dataSetDict)


	isFirst = True
	for dataType in dataSetDict:
		for predInterval in dataSetDict[dataType]:
			for dataName in dataSetDict[dataType][predInterval]:
				# 当前训练数据的字典
				singleDataDict 			= dataSetDict[dataType][predInterval][dataName]
				# 当前训练数据
				culFormatedTrainData 	= singleDataDict["culFormatedTrainData"]
				# 当前验证数据
				culFormatedTestData 	= singleDataDict["culFormatedTestData"]
				# 额外的数据参数
				if "optionPara" in singleDataDict:
					optionPara = singleDataDict["optionPara"]
				else:
					optionPara = None
				# 创建所有结果字典
				if dictUniName not in resDict[dataType][predInterval][dataName]:
					resDict[dataType][predInterval][dataName][dictUniName] = dict()
				if isFirst == True:
					dataTypeSum = len(dataSetDict.keys())
					predIntervalSum = len(dataSetDict[dataType].keys())
					dataNameSum = len(dataSetDict[dataType][predInterval].keys())
					methodSum = len(methodList)
					modelSum = len(modelList)
					print("理论任务总数 : ",dataTypeSum," * ",predIntervalSum," * ",dataNameSum," * ",methodSum," * ",modelSum," = ",dataTypeSum*predIntervalSum*dataNameSum*methodSum*modelSum)
				isFirst = False
				# 不同推参方法
				for methodDict in methodList:
					methodName = methodDict["methodName"]
					# 创建单一推参结果字典
					if methodName not in resDict[dataType][predInterval][dataName][dictUniName]:
						resDict[dataType][predInterval][dataName][dictUniName][methodName] = dict()
					for modelDict in modelList:
						modelType = modelDict["modelType"]
						modelName = modelDict["modelName"]
						# 用于显示在报告中的模型名称. 可选
						if "aliasName" not in modelDict:
							aliasName = modelType+"-"+modelName
						else:
							aliasName = modelDict["aliasName"]
						# 创建单一模型推参结果字典
						if modelType not in resDict[dataType][predInterval][dataName][dictUniName][methodName]:
							resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType] = dict()
						if modelName not in resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType]:
							resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType][modelName] = dict()
						# 一周目收集spark任务
						if global_variables.sparkTaskCounter == -1 :
							sparkTaskDict = dict()
							sparkTaskDict["culFormatedTrainData"] = culFormatedTrainData
							sparkTaskDict["methodDict"] = copy.deepcopy(methodDict)
							sparkTaskDict["modelDict"] = copy.deepcopy(modelDict)
							sparkTaskDict["dataType"] = dataType
							sparkTaskDict["predInterval"] = predInterval
							sparkTaskDict["dataName"] = dataName
							sparkTaskDict["optionPara"] = optionPara
							sparkTaskDict["debugServerInfoDict"] = debugServerInfoDict
							if len(culFormatedTestData) == 0:
								dataInterval = 1.0
							else:
								dataInterval = culFormatedTrainData[-1][0] / culFormatedTestData[-1][0]
							sparkTaskDict["dataInterval"] = dataInterval
							sparkTaskDict["otherEstDict"] = singleDataDict
							global_variables.sparkTaskList.append([sparkTaskDict, sparkFun, redisConfDict])
						# 二周目返还spark计算结果
						if global_variables.sparkTaskCounter != -1 :
							# 回收结果
							sparkResDict = global_variables.sparkTaskList[global_variables.sparkTaskCounter]
							# 从redis中还原结果
							if redisConfDict is not None:
								hashName = sparkResDict
								exeFlag = False
								for sleepTime in range(3):
									try:
										sparkResDump = client.get(hashName)
									except Exception as e:
										time.sleep(5 + sleepTime*10)
									else:
										exeFlag = True
										break
								if exeFlag == False:
									raise
								sparkResDict = pickle.loads(sparkResDump)
							# 整理结果
							global_variables.sparkTaskCounter += 1
							tempResDict = dict()
							#tempResDict["methodDict"] 			= copy.deepcopy(methodDict)
							tempResDict["methodDict"] 			= sparkResDict["methodDict"]
							tempResDict["paraList"] 			= sparkResDict["paraList"]
							tempResDict["culFormatedEstData"] 	= sparkResDict["culFormatedEstData"]
							tempResDict["measureNameList"] 		= sparkResDict["measureNameList"]
							if "estCostTime" in sparkResDict:
								tempResDict["estCostTime"] 		= sparkResDict["estCostTime"]
							else:
								tempResDict["estCostTime"] 		= -1
							tempResDict["measureValueDict"] 	= copy.deepcopy(sparkResDict["measureValueDict"])
							tempResDict["aliasName"] 			= aliasName
							resDict[dataType][predInterval][dataName][dictUniName][methodName][modelType][modelName] = tempResDict
							# 校验结果是否按预期顺序返还
							if methodName != sparkResDict["methodDict"]["methodName"]:
								raise 
							bar.update(1)
	# 二周目返还spark计算结果
	if global_variables.sparkTaskCounter != -1 :
		if redisConfDict is not None:
			client.flushdb()
			client.close()
		bar.close()
	return resDict

# 将spark的结果用redis暂存
def sparkFun_redis(args):
	sparkTaskDict = args[0]
	sparkFun = args[1]
	redisConfDict = args[2]
	redisHost = redisConfDict["host"] # "10.30.87.10"
	redisPassword = redisConfDict["password"] # "wJc@2410"
	redisPort = redisConfDict["port"] # 6379
	if "databaseNum" in redisConfDict:
		redisDbNum = redisConfDict["databaseNum"] # 0
	else:
		redisDbNum = 0
	exeFlag = False
	sparkResDict = sparkFun(sparkTaskDict)
	for sleepTime in range(5):
		try:
			client = redis.Redis(
				host=redisHost,
				port=redisPort,
				db=redisDbNum,
				password=redisPassword,
				decode_responses=False
			)
			

			dumpsDict = pickle.dumps(sparkResDict, protocol=pickle.HIGHEST_PROTOCOL)
			hashName = str(hashlib.sha256(dumpsDict).hexdigest())
			client.set(hashName, dumpsDict)
			client.close()
			exeFlag = True
		except Exception as e:
			randomA = random.randint(5, 20)
			randomB = random.randint(10, 20)
			time.sleep(randomA + sleepTime*randomB)
		else:
			break
	if exeFlag == True:
		return hashName
	else:
		raise
	
# 启动spark执行计算
def startSpark(sc,sparkFun,redisConfDict,threshold = 30000):
	# spark计算
	
	print("spark任务总数量 : "+str(len(global_variables.sparkTaskList)))
	sparkTaskList_total = SRMtool.split_list(global_variables.sparkTaskList, threshold)
	resTaskList_total = []
	index = 1
	for sparkTaskList in sparkTaskList_total:
		print("spark任务 第",index,"批数量 : ",len(sparkTaskList))
		paraRDD = sc.parallelize(sparkTaskList)
		#predictionRDD = paraRDD.map(lambda sparkTaskDict: sparkFun(sparkTaskDict))
		predictionRDD = paraRDD.map(lambda args: sparkFun_redis(args))
		tempResList = predictionRDD.collect()
		resTaskList_total.append(tempResList)
		index += 1
	global_variables.sparkTaskList = SRMtool.rebuild_list(resTaskList_total)
	global_variables.sparkTaskCounter = 0

# 外部调用接口
def exec(dataSetDict,modelList,methodList,dictUniName,sparkFun,sc, debugServerInfoDict = None, redisConfDict=None,threshold = 30000):
	# 测试redis连接
	if redisConfDict is not None:
		redisHost = redisConfDict["host"] # "10.30.87.10"
		redisPassword = redisConfDict["password"] # "wJc@2410"
		redisPort = redisConfDict["port"] # 6379
		if "databaseNum" in redisConfDict:
			redisDbNum = redisConfDict["databaseNum"] # 0
		else:
			redisDbNum = 0
		client = redis.Redis(
			host=redisHost,
			port=redisPort,
			db=redisDbNum,
			password=redisPassword,
			decode_responses=False
		)
		client.set("hello", "world"+str(redisDbNum))
		value = client.get("hello")
		print("Redis Test Results : ", value)
		client.close()
	else:
		print("No Redis Conf (Est)")
	# 布置spark任务
	global_variables.sparkTaskList = []
	global_variables.sparkTaskCounter = -1
	#print(redisConfDict)
	#exit()
	# 收集spark任务（主逻辑）
	main(dataSetDict,modelList,methodList,dictUniName, debugServerInfoDict, sparkFun,redisConfDict)
	# 提交spark计算处理
	try:
		startSpark(sc,sparkFun,redisConfDict,threshold)
	except Exception as e:
		raise e
	# 再次执行并返还spark计算结果 （再次调用主逻辑）
	try:
		resDict = main(dataSetDict,modelList,methodList,dictUniName, debugServerInfoDict, sparkFun,redisConfDict)
	except Exception as e:
		raise e
	return resDict




































