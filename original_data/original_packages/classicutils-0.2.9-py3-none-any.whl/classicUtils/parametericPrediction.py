import math
from classicUtils import SRMtool

# 带入time, 计算未来的num以及predNum与真实num的差异
def calcNum(paraList, meanValueFunc, meanValueFunc_backup, culFormatedTrainData, culFormatedTestData):

	lastNum = culFormatedTrainData[-1][1]
	lastTime = culFormatedTrainData[-1][0]
	# 优先用高速函数计算。计算失败时尝试使用高精度函数。
	isError = False
	try:
		lastEstNum = float(meanValueFunc(lastTime, paraList))
		if res == float("inf") or res == float("-inf") or math.isnan(res):
			isError = True
	except Exception as e:
		isError = True
	if isError == True:
		lastEstNum = float(meanValueFunc_backup(lastTime, paraList))
	# 获取从 lastEstNum 开始计算的累计预测值
	culTempList = []
	for nowTime, nowNum in culFormatedTestData:
		# 优先用高速函数计算。计算失败时尝试使用高精度函数。
		isError = False
		try:
			predValue = float(meanValueFunc(nowTime, paraList))
			if res == float("inf") or res == float("-inf") or math.isnan(res):
				isError = True
		except Exception as e:
			isError = True
		if isError == True:
			predValue = float(meanValueFunc_backup(nowTime, paraList))
		culTempList.append(predValue)
	# 获取从 0 开始计算的非累积预测值
	
	tempList = SRMtool.toNonCulData(culTempList)
	try:
		tempList[0] = tempList[0] - lastEstNum
	except Exception as e:
		print("lastEstNum : "+str(lastEstNum))
		print("tempList : "+str(tempList))
		print("tempList[0] : "+str(tempList[0]))
		raise e
	# 获取从 0 开始计算的累计预测值
	culTempList = SRMtool.toCulData(tempList)
	# 获取从 lastNum 开始计算的累计预测值
	culPredList = []
	for nowNum in culTempList:
		culPredValue = nowNum + lastNum
		culPredList.append(culPredValue)
	culFormatedPredData = []
	culdTestList = []
	i = 0
	for nowTime, nowNum in culFormatedTestData:
		predNum = culPredList[i]
		culFormatedPredData.append([nowTime, predNum])
		culdTestList.append(nowNum)
		i += 1
	culPMAE = SRMtool.realMSE(culPredList, culdTestList)
	nonCulPMAE = SRMtool.realMSE(SRMtool.toNonCulData(culPredList), SRMtool.toNonCulData(culdTestList))
	return [culFormatedPredData, nonCulPMAE, culPMAE]

