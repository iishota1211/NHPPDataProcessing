# v10
# 删除了不必要的冗余代码（基于mathematica库的相关实现）
#
# v09
# 修改了高精度运算的上下文环境,使得运算精度超过设定值时不会报错而是自动舍入为近似值
# 修改了paratoBase等函数吗,使得不会爆出numpy相关错误
# 新增模型参数范围字典
# 取消使用longdouble类型
#
# v08
# 新增归一最大似然函数
# normalized_LLF_t_float(args, formatedData, meanValueFun, intensityFun)
# normalized_LLF_g_float(args, formatedData, meanValueFun, intensityFun)
# 新增归一最大似然估计
# normalizedMaxLikelihoodMethod(dataType, formatedData, meanValueFun, intensityFun)
# 新增使用归一估计参数的原最大似然值函数
# inverseNormalized_LLF_t_float(args, formatedData, meanValueFun, intensityFun)
# inverseNormalized_LLF_g_float(args, formatedData, meanValueFun, intensityFun)
#
# v07
# 新增生成泊松过程模拟数据方法
# 新增部分基础函数的逆函数
#
# v06
# 新增float精度基础函数与LLF
# 新增归一化LLF_t_float
# 使用scipy实现的gamma函数代替自己实现的gamma函数
# WeightedLindleyCDF()暂时无法使用
#
# v05
# 修复LogLoist函数与EV函数的bug
# 修复LLF_g的bug
#
# v04
# 修复LogLoistIF的bug
#
# v03
# 新增LLF_g

import math,numpy,random,scipy
from scipy import integrate,optimize
#from scipy import optimize
from decimal import *
from scipy.special import gamma,gammaincc
from numpy import longdouble
from numpy import emath
from scipy import stats

# 全局变量
from classicUtils import global_variables
#import warnings
#warnings.filterwarnings("error")


# 高精度指数计算类
class highPrecisionCalc():
	"""docstring for high-precision"""
	def __init__(self,):
		pass

	# 计算 a^b * ∏ x_i = a^b • x1 • x2 • ... • x_n
	# xList = [x1, x2, ..., x_n] = x1 • x2 • ... • x_n
	# 其中(a^b)接近无穷大，xList接近无穷小. b > 10
	def highPowerRes(self, b, xList, a = math.e, p = 25):
		n = len(xList)
		# c个p相加得到b的绝对值的整数部分
		c = int(abs(b)/p)
		# d是b的绝对值的小数部分
		d = abs(b) - (p * c)
		a_p = a ** p
		a_d = a ** d
		if b == 0:
			res = 1
			for x in xList:
				res = res * x
			return res
		if b < 0:
			if abs(b) <= p:
				res = a ** b
				for x in xList:
					res = res * x
				return res
			a_p = 1 / a_p
			a_d = 1 / a_d
			b = -b
		if b > 0:
			if b <= p:
				res = a ** b
				for x in xList:
					res = res * x
				return res
			if b > p:
				if c == n:
					res = a_d
					i = 0
					while i < c:
						res = res * xList[i] * a_p
						i += 1
					return res
				if c > n:
					if n * 100 < c :
						print("待计算表达式： "+str(a)+"^"+str(b)+" * "+str(xList[0])+" * ... * "+str(xList[-1]))
						print("b值太大。无法进行高精度计算。 b = "+str(b))
						raise
					res = a_d
					i = 0
					while i < n:
						res = res * xList[i] * a_p
						i += 1
					while i < c:
						res = res * a_p
						i += 1
					return res
				if n > c:
					if c * 100 < n :
						print("待计算表达式： "+str(a)+"^"+str(b)+" * "+str(xList[0])+" * ... * "+str(xList[-1]))
						print("xList太长。无法进行高精度计算。 len(xList) = "+str(len(xList)))
						raise
					res = a_d
					i = 0
					while i < c:
						res = res * xList[i] * a_p
						i += 1
					while i < n:
						res = res * xList[i]
						i += 1
					return res
		raise

	# 计算 a^b * c^d
	# a默认为e。即默认计算 exp(b) * c^d
	def highPowerRes2(self, b, c, d, a = math.e):
		highPowerRes_p = 25
		xList = []
		p = abs(math.log(10000000000,c))
		#print(p)
		# ibp个p相加得到d的绝对值的整数部分
		ibp = int(abs(d)/p)
		# afp是d的绝对值的小数部分. 即 ( ibp * p ) + afp = d
		afp = abs(d) - (p * ibp)
		if abs(d) <= p:
			xList.append(c ** d)
		if abs(d) > p:
			# 判断是否需要直接报错
			if abs(b) > abs(highPowerRes_p):
				# highPowerRes_c 个 highPowerRes_p 相加得到b的绝对值的整数部分
				highPowerRes_c = int( abs(b) / highPowerRes_p )
				if highPowerRes_c > ibp + 1:
					if (ibp + 1) * 100 < highPowerRes_c :
						print("待计算表达式： "+str(a)+"^"+str(b)+" * "+str(c)+"^"+str(d))
						print("b值太大。无法进行高精度计算。 b = "+str(b))
						raise
				if ibp + 1 > highPowerRes_c:
					if highPowerRes_c * 100 < (ibp + 1) :
						print("待计算表达式： "+str(a)+"^"+str(b)+" * "+str(c)+"^"+str(d))
						print("d值太大。无法进行高精度计算。 d = "+str(d))
						raise
			# 正式开始计算预处理
			if d < 0:
				p = - p
				afp = - afp
			i = 0
			c_p = c ** p 
			while i < ibp:
				xList.append(c_p)
				i += 1
			xList.append(c ** afp)
		res = self.highPowerRes(b, xList, a, highPowerRes_p)
		return res

class usefulMathFunction(highPrecisionCalc):
	
	# 计算gamma函数用被积函数
	def GammaIntegrate(self, t, z,):
		res = self.highPowerRes2(-t ,t, z - 1)
		return res

	def GammaFunction(self, x, startTime = 0):
		# new version
		if startTime != 0:
			return gammaincc(x,startTime)
		else:
			return gamma(x)
		# old version
		midTime = 20
		endTime = 60
		res0 = 0
		if startTime <= 0:
			if startTime < 0:
				res0 = integrate.quad(self.GammaIntegrate, startTime, 0, (x))[0]
			#print(x)
			res1 = integrate.quad(self.GammaIntegrate, 0, midTime, (x))[0]
			res2 = integrate.quad(self.GammaIntegrate, midTime, endTime, (x))[0]
			res3 = integrate.quad(self.GammaIntegrate, endTime, numpy.inf, (x))[0]
			res = res0 + res1 + res2 + res3
		if startTime > 0:
			res1 = integrate.quad(self.GammaIntegrate, startTime, startTime + midTime, (x))[0]
			res2 = integrate.quad(self.GammaIntegrate, startTime + midTime, startTime + endTime, (x))[0]
			res3 = integrate.quad(self.GammaIntegrate, startTime + endTime, numpy.inf, (x))[0]
			res = res1 + res2 + res3
		#res = integrate.quad(self.GammaIntegrate, 0, endTime, (x))[0]
		return res

	def erf(self, z):
		if z < 0:
			raise
		def erfIntegrate(t):
			return math.exp(- t * t)
		midTime = 20
		endTime = 60
		coe = 2 / math.sqrt(math.pi)
		res1 = 0
		res2 = 0
		res3 = 0
		if z > 60:
			res1 = integrate.quad(erfIntegrate, 0, midTime)[0]
			res2 = integrate.quad(erfIntegrate, midTime, endTime)[0]
			res3 = integrate.quad(erfIntegrate, endTime, z)[0]
		if z <= 60:
			if z > 20:
				res1 = integrate.quad(erfIntegrate, 0, midTime)[0]
				res2 = integrate.quad(erfIntegrate, midTime, z)[0]
			if z <= 20:
				res1 = integrate.quad(erfIntegrate, 0, z)[0]
		res = coe * (res1 + res2 + res3)
		return res

	def erfc(self, z):
		return 1 - self.erf(z)


	# 获得 0-1之间的随机值。遵循均匀分布。
	def getU(self):
		while True:
			now = random.uniform(0, 1)
			#print(now)
			#exit()
			if now != 0.0 and now != 1.0:
				return now

	# 计算反函数
	def getInverse(self,meanValueFun, args ,y_values,x0):
		#scipy.optimize.minimize_scalar()
		res = scipy.optimize.leastsq(self.error, x0, args=(meanValueFun, args,y_values))
		#print(res[0][0])
		#exit()
		#print("getInverse")
		#print(res)
		#exit()
		return res[0][0]

	def error(self,t,meanValueFun, args,y_values):
		return (float(meanValueFun(t,args)) - y_values)**2





# 基于NHPP的软件可靠性模型基础类
class NHPPbasedSRM(usefulMathFunction):
	
	modelNames = None

	baseModelNames = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]
	baseModelNames_float = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin",]


	def __init__(self, prec = 1000):
		setcontext(ExtendedContext)
		getcontext().prec = prec
		self.decimalContext = getcontext()
		zeroNear = 1e-15
		self.baseInitParaDict = {
			"Exp"			:	[0.00001,],
			"Gamma"			:	[1, 0.00001],
			"Pareto"		:	[1, 1],
			"TruncNormal"	:	[100, -100],
			"LogNormal"		:	[1, 1],
			"TruncLogist"	:	[10, -10],
			"LogLogist"		:	[1, 1],
			"TruncEVMax"	:	[10, 10],
			"LogEVMax"		:	[1, 1],
			"TruncEVMin"	:	[100, 100],
			"LogEVMin"		:	[10, -10],
		}
		# 新版
		self.baseCumulativeDistributionBoundsDict = {
			"Exp"			:	[[zeroNear,None],],
			"Gamma"			:	[[zeroNear,None],[zeroNear,None],],
			"Pareto"		:	[[zeroNear,None],[zeroNear,None],],
			"TruncNormal"	:	[[zeroNear,None],[None,None],],
			"LogNormal"		:	[[zeroNear,None],[None,None],],
			"TruncLogist"	:	[[zeroNear,None],[None,None],],
			"LogLogist"		:	[[zeroNear,None],[None,None],],
			"TruncEVMax"	:	[[zeroNear,None],[None,None],],
			"LogEVMax"		:	[[zeroNear,None],[None,None],],
			"TruncEVMin"	:	[[zeroNear,None],[None,None],],
			"LogEVMin"		:	[[zeroNear,None],[None,None],],
		}
		"""
		# 上一版
		self.baseCumulativeDistributionBoundsDict = {
			"Exp"			:	[[zeroNear,None],],
			"Gamma"			:	[[zeroNear,None],[zeroNear,None],],
			"Pareto"		:	[[zeroNear,None],[zeroNear,None],],
			"TruncNormal"	:	[[zeroNear,None],[None,None],],
			"LogNormal"		:	[[zeroNear,None],[zeroNear,None],],
			"TruncLogist"	:	[[zeroNear,None],[None,None],],
			"LogLogist"		:	[[zeroNear,None],[zeroNear,None],],
			"TruncEVMax"	:	[[zeroNear,None],[None,None],],
			"LogEVMax"		:	[[zeroNear,None],[zeroNear,None],],
			"TruncEVMin"	:	[[zeroNear,None],[zeroNear,None],],
			"LogEVMin"		:	[[zeroNear,None],[None,None],],
		}
		"""
		self.baseCumulativeDistributionFunctionDict = {
			"Exp"			:	self.ExpBaseMVF,
			"Gamma"			:	self.GammaBaseMVF,
			#"Gamma"		:	self.GammaBaseMVF_new,
			"Pareto"		:	self.ParetoBaseMVF,
			"TruncNormal"	:	self.TruncNormalBaseMVF,
			"LogNormal"		:	self.LogNormalBaseMVF,
			"TruncLogist"	:	self.TruncLogistBaseMVF,
			"LogLogist"		:	self.LogLogistBaseMVF,
			"TruncEVMax"	:	self.TruncEVMaxBaseMVF,
			"LogEVMax"		:	self.LogEVMaxBaseMVF,
			"TruncEVMin"	:	self.TruncEVMinBaseMVF,
			"LogEVMin"		:	self.LogEVMinBaseMVF,
		}
		self.baseIntensityFunctionDict = {
			"Exp"			:	self.ExpBaseIF,
			"Gamma"			:	self.GammaBaseIF,
			"Pareto"		:	self.ParetoBaseIF,
			"TruncNormal"	:	self.TruncNormalBaseIF,
			"LogNormal"		:	self.LogNormalBaseIF,
			"TruncLogist"	:	self.TruncLogistBaseIF,
			"LogLogist"		:	self.LogLogistBaseIF,
			"TruncEVMax"	:	self.TruncEVMaxBaseIF,
			"LogEVMax"		:	self.LogEVMaxBaseIF,
			"TruncEVMin"	:	self.TruncEVMinBaseIF,
			"LogEVMin"		:	self.LogEVMinBaseIF,
		}
		self.baseCumulativeDistributionFunctionDict_float = {
			"Exp"			:	self.ExpBaseMVF_float,
			"Gamma"			:	self.GammaBaseMVF_float,
			"Pareto"		:	self.ParetoBaseMVF_float,
			"TruncNormal"	:	self.TruncNormalBaseMVF_float,
			"LogNormal"		:	self.LogNormalBaseMVF_float,
			"TruncLogist"	:	self.TruncLogistBaseMVF_float,
			"LogLogist"		:	self.LogLogistBaseMVF_float,
			"TruncEVMax"	:	self.TruncEVMaxBaseMVF_float,
			"LogEVMax"		:	self.LogEVMaxBaseMVF_float,
			"TruncEVMin"	:	self.TruncEVMinBaseMVF_float,
			"LogEVMin"		:	self.LogEVMinBaseMVF_float,
		}
		self.baseIntensityFunctionDict_float = {
			"Exp"			:	self.ExpBaseIF_float,
			"Gamma"			:	self.GammaBaseIF_float,
			"Pareto"		:	self.ParetoBaseIF_float,
			"TruncNormal"	:	self.TruncNormalBaseIF_float,
			"LogNormal"		:	self.LogNormalBaseIF_float,
			"TruncLogist"	:	self.TruncLogistBaseIF_float,
			"LogLogist"		:	self.LogLogistBaseIF_float,
			"TruncEVMax"	:	self.TruncEVMaxBaseIF_float,
			"LogEVMax"		:	self.LogEVMaxBaseIF_float,
			"TruncEVMin"	:	self.TruncEVMinBaseIF_float,
			"LogEVMin"		:	self.LogEVMinBaseIF_float,
		}
		self.baseInverseCumulativeDistributionFunctionDict_float = {
			"Exp"			:	self.ExpBaseInverseMVF_float,
			"Gamma"			:	self.GammaBaseInverseMVF_float,
			"Pareto"		:	self.ParetoBaseInverseMVF_float,
			"TruncNormal"	:	self.TruncNormalBaseInverseMVF_float,
			"LogNormal"		:	self.LogNormalBaseInverseMVF_float,
			"TruncLogist"	:	self.TruncLogistBaseInverseMVF_float,
			"LogLogist"		:	self.LogLogistBaseInverseMVF_float,
			"TruncEVMax"	:	self.TruncEVMaxBaseInverseMVF_float,
			"LogEVMax"		:	self.LogEVMaxBaseInverseMVF_float,
			"TruncEVMin"	:	self.TruncEVMinBaseInverseMVF_float,
			"LogEVMin"		:	self.LogEVMinBaseInverseMVF_float,
		}
		self.baseInverseModelNames_float = self.baseInverseCumulativeDistributionFunctionDict_float.keys()
	
	def baseInitPara(self, modelName):
		if modelName in self.baseModelNames:
			return self.baseInitParaDict[modelName]	
		else:
			return [1,1]

	def baseBounds(self, modelName):
		if modelName in self.baseModelNames:
			return self.baseCumulativeDistributionBoundsDict[modelName]	
		else:
			return [[None,None],[None,None],]

	def baseCumDistFun(self, modelName):
		if modelName in self.baseModelNames:
			return self.baseCumulativeDistributionFunctionDict[modelName]	
		else:
			return None

	def baseInteDistFun(self, modelName):
		if modelName in self.baseModelNames:
			return self.baseIntensityFunctionDict[modelName]	
		else:
			return None

	def baseCumDistFun_float(self, modelName):
		if modelName in self.baseModelNames_float:
			return self.baseCumulativeDistributionFunctionDict_float[modelName]	
		else:
			return None

	def baseInteDistFun_float(self, modelName):
		if modelName in self.baseModelNames_float:
			return self.baseIntensityFunctionDict_float[modelName]	
		else:
			return None

	def baseInverseCumDistFun_float(self, modelName):
		if modelName in self.baseInverseModelNames_float:
			return self.baseInverseCumulativeDistributionFunctionDict_float[modelName]	
		else:
			return None

	# 组数据时的LLF
	# t_i : calendar time
	# n_i : cumulative number of software faults
	# intensityFun 是为了参数格式上与LF_t相同。并不实际使用。
	def LLF_g(self, args, groupDataFormat, meanValueFun, intensityFun):
		res = 0
		old_t = 0
		old_n = 0
		old_meanValue = Decimal(0)
		last_t = groupDataFormat[-1][0]
		res = - meanValueFun(last_t, args)
		#print(float(res))
		for dataEle in groupDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]
			meanValue = meanValueFun(t_i, args)
			intervalMeanValue = meanValue - old_meanValue
			intervalN = n_i - old_n
			#print("interval N : "+str(intervalN))
			#print("intervalMeanValue = "+str(float(intervalMeanValue)))
			old_meanValue = meanValue
			old_n = n_i

			tempRes = Decimal(1)
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / Decimal(i))
				i += 1
			
			tempRes = tempRes.ln()
			#print("tempRes:"+str(float(tempRes)))
			res = res + tempRes

		return float(res)

	# 组数据时的LLF
	# t_i : calendar time
	# n_i : cumulative number of software faults
	# intensityFun 是为了参数格式上与LF_t相同。并不实际使用。
	def LLF_g_float(self, args, groupDataFormat, meanValueFun, intensityFun):
		res = 0
		old_t = 0
		old_n = 0
		old_meanValue = 0
		last_t = groupDataFormat[-1][0]
		res = - meanValueFun(last_t, args)
		#print(float(res))
		for dataEle in groupDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]
			meanValue = meanValueFun(t_i, args)
			intervalMeanValue = meanValue - old_meanValue
			intervalN = n_i - old_n
			#print("interval N : "+str(intervalN))
			#print("intervalMeanValue = "+str(float(intervalMeanValue)))
			old_meanValue = meanValue
			old_n = n_i

			tempRes = 1
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / i)
				i += 1
			tempRes = emath.log(tempRes)
			#print("tempRes:"+str(float(tempRes)))
			res = res + tempRes

		return float(res)

	# 时间数据时的LLF
	# timeDataFormat[0] = [t_i, n_i]
	# t_i : failure time
	# n_i : cumulative number of software faults
	def LLF_t(self, args, timeDataFormat, meanValueFun, intensityFun):
		res = 0
		old_t = 0
		old_n = 0
		last_t,last_n, = timeDataFormat[-1]
		meanValue = meanValueFun(last_t, args)
		
		#print("last_t = "+str(last_t)+" args = "+str(args)+" meanValue = "+str(meanValue))
		
		#expMeanValue = Decimal(- meanValue).exp()
		#print("meanValue = "+str(meanValue)+" expMeanValue = "+str(expMeanValue))
		res = - meanValue
		i = 0
		for dataEle in timeDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]
			intensity = intensityFun(t_i, args)
			lnIntensity = Decimal(intensity).ln()
			#if i < 5:
			#i += 1
			res = res + lnIntensity
			#print("t_i = "+str(t_i)+" args = "+str(args)+" intensity = " + str(intensity)+" res = "+str(res))
			
		return float(res)

	# 时间数据时的LLF
	# timeDataFormat[0] = [t_i, n_i]
	# t_i : failure time
	# n_i : cumulative number of software faults
	def LLF_t_float(self, args, timeDataFormat, meanValueFun, intensityFun):
		res = 0
		old_t = 0
		old_n = 0
		last_t,last_n, = timeDataFormat[-1]
		try:
			meanValue = meanValueFun(last_t, args)
		except Exception as e:
			print(last_t)
			print(type(last_t))
			for x in args:
				print("x : "+str(x)+" type : "+str(type(x)))
			raise e
		
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
		res = - meanValue
		i = 0
		for dataEle in timeDataFormat:
			t_i = dataEle[0]
			n_i = dataEle[1]
			intensity = intensityFun(t_i, args)
			try:
				lnIntensity = emath.log(intensity)
				if intensity == 0.0:
					raise 
			except Exception as e:
				print("args : "+str(args))
				print("i : "+str(i))
				print("t_i : "+str(t_i)+" intensity : "+str(intensity))
				raise e
			i += 1
			res = res + lnIntensity
		#print("res : ")
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
		return float(res)

	def inverseNormalized_LLF_t_float(self, args, formatedData, normalizedMeanValueFun, normalizedIntensityFun):
		dataLen = formatedData[-1][1]
		endTime = formatedData[-1][0]

		res = 0
		old_t = 0
		old_n = 0
		last_t,last_n, = formatedData[-1]

		meanValue = normalizedMeanValueFun(last_t, args, endTime, dataLen)
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
		res = - meanValue
		i = 0
		for dataEle in formatedData:
			t_i = dataEle[0]
			n_i = dataEle[1]
			intensity = normalizedIntensityFun(t_i, args, endTime, dataLen)
			try:
				lnIntensity = emath.log(intensity)
				if intensity == 0.0:
					raise 
			except Exception as e:
				print("args : "+str(args))
				print("i : "+str(i))
				print("t_i : "+str(t_i)+" intensity : "+str(intensity))
				raise e
			i += 1
			res = res + lnIntensity
		#print("res : ")
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
		return float(res)

	def inverseNormalized_LLF_g_float(self, args, formatedData, normalizedMeanValueFun, normalizedIntensityFun):
		dataLen = formatedData[-1][1]
		endTime = formatedData[-1][0]

		res = 0
		old_t = 0
		old_n = 0
		old_meanValue = 0
		last_t = formatedData[-1][0]
		res = - normalizedMeanValueFun(last_t, args, endTime, dataLen)
		#print(float(res))
		for dataEle in formatedData:
			t_i = dataEle[0]
			n_i = dataEle[1]
			meanValue = normalizedMeanValueFun(t_i, args, endTime, dataLen)
			intervalMeanValue = meanValue - old_meanValue
			intervalN = n_i - old_n
			#print("interval N : "+str(intervalN))
			#print("intervalMeanValue = "+str(float(intervalMeanValue)))
			old_meanValue = meanValue
			old_n = n_i

			tempRes = 1
			i = 1
			while i <= intervalN:
				tempRes = tempRes * (intervalMeanValue / i)
				i += 1
			tempRes = emath.log(tempRes)
			#print("tempRes:"+str(float(tempRes)))
			res = res + tempRes

		return float(res)


	def normalizedMaxLikelihoodMethod(self, dataType, formatedData, meanValueFun, intensityFun,modelType,modelName):
		# 对数似然函数
		if dataType == "time":
			logLikelihoodFunc = self.normalized_LLF_t_float
		elif dataType == "group":
			logLikelihoodFunc = self.normalized_LLF_g_float
		if len(global_variables.histroyParaList[modelType][modelName]) > 0:
			initPara = global_variables.histroyParaList[modelType][modelName][0]
		else:
			initPara = [1,0.01,0.01,]
		#logLikelihoodFunc = models.LLF_t_float
		def negLikelihoodFunc(args, formatedData, meanValueFun, intensityFun,):
			return -logLikelihoodFunc(args, formatedData, meanValueFun, intensityFun,)
		bounds = []
		bounds.append([0,5000])
		bounds.append([1e-100,None])
		bounds.append([1e-100,None])
		bList = []
		cList = []
		i = 10
		s = 0.0000001
		counter = 0
		while counter <= 14:
			bList.append(s)
			cList.append(s)
			s = s * i
			counter += 1
		try:
			isSame1 = True
			isFinish = False
			res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
			isFinish = True
			i = 0
			for p in initPara:
				if res.x[i] != p:
					isSame = False
					break
				i += 1
			if isSame1 == True:
				raise Exception
		except Exception as e:
			# 先尝试历史成功参数
			for initPara in global_variables.histroyParaList[modelType][modelName]:
				try:
					nLL = negLikelihoodFunc(initPara, formatedData, meanValueFun, intensityFun)
					if nLL != float("inf") and nLL != float("-inf"):
						res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
					else:
						continue
				except Exception:
					pass
				else:
					isSame = True
					i = 0
					for p in initPara:
						if res.x[i] != p:
							isSame = False
							break
						i += 1
					if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
						#global_variables.histroyParaList.append(res.x)
						print("历史参数成功")
						return res.x
					else:
						continue
			# 先尝试所有可能的初始参数
			for b in bList:
				for c in cList:
					initPara[1] = b
					initPara[2] = c
					try:
						nLL = negLikelihoodFunc(initPara, formatedData, meanValueFun, intensityFun)
						if nLL != float("inf") and nLL != float("-inf"):
							res = optimize.minimize(fun=negLikelihoodFunc, x0=initPara, args=(formatedData, meanValueFun, intensityFun,), method = "Nelder-Mead", bounds=bounds)
						else:
							continue
					except Exception:
						pass
					else:
						isSame = True
						i = 0
						for p in initPara:
							if res.x[i] != p:
								isSame = False
								break
							i += 1
						if res.fun != float("inf") and res.fun != float("-inf") and isSame == False:
							#global_variables.histroyParaList.append(res.x)
							return res.x
						else:
							continue
			return []
			raise e
		#global_variables.histroyParaList.append(res.x)
		return res.x

	# 时间数据的LLF
	# timeDataFormat[0] = [t_i, n_i]
	# t_i : failure time
	# n_i : cumulative number of software faults
	# Numpy version
	def normalized_LLF_t_float(self, args, timeDataFormat, meanValueFun, intensityFun, tScale = 1):
		res = 0
		old_t = 0
		old_n = 0
		last_t,last_n, = timeDataFormat[-1]
		dataLen = len(timeDataFormat)

		tScaleCoe = last_t*tScale
		meanValue = meanValueFun(last_t/tScaleCoe, args)*dataLen
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
		res = - meanValue
		i = 0
		for dataEle in timeDataFormat:
			t_i = dataEle[0]
			intensity = intensityFun(t_i/tScaleCoe, args)*dataLen
			try:
				lnIntensity = emath.log(intensity)
				if intensity == 0.0:
					raise 
			except Exception as e:
				#print("args : "+str(args))
				#print("i : "+str(i))
				#print("t_i : "+str(t_i/tScaleCoe)+" intensity : "+str(intensity))
				raise e
			i += 1
			res = res + lnIntensity
		#print("res : ")
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
		return float(res)

	# 组数据时的LLF
	# groupDataFormat[0] = [t_i, n_i]
	# t_i : failure time
	# n_i : cumulative number of software faults
	# Numpy version
	def normalized_LLF_g_float(self, args, groupDataFormat, meanValueFun, intensityFun, tScale = 1):
		"""
		normalizedGroupDataFormat = []
		last_t,last_n, = groupDataFormat[-1]
		for dataEle in groupDataFormat:
			nowTime = dataEle[0]
			nowFaultNumber = dataEle[1]
			normalizedGroupDataFormat.append([nowTime/last_t,nowFaultNumber/last_n])
		last_t,last_n, = normalizedGroupDataFormat[-1]
		"""
		last_t,last_n, = groupDataFormat[-1]
		res = 0
		meanValue = meanValueFun(last_t/last_t, args)
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue))
		res = - meanValue
		i = 0
		oldMeanValue = 0
		oldFaultNumber = 0
		for dataEle in groupDataFormat:
			nowTime = dataEle[0]/last_t
			nowFaultNumber = dataEle[1]/last_n
			nowMeanValue = meanValueFun(nowTime, args)
			intervalMeanValue = nowMeanValue - oldMeanValue
			intervalFaultNumber = nowFaultNumber - oldFaultNumber
			partA = emath.power(intervalMeanValue, intervalFaultNumber)
			if intervalFaultNumber == 0:
				partB = 1
			else:
				partB = self.GammaFunction(intervalFaultNumber)
			try:
				lnPart = emath.log(partA) - emath.log(partB)
			except Exception as e:
				print("intervalMeanValue : "+str(intervalMeanValue))
				print("intervalFaultNumber : "+str(intervalFaultNumber))
				print("partA : "+str(partA))
				print("partB : "+str(partB))
				print("t_i : "+str(t_i)+" args : "+str(args))
				raise e
			i += 1
			res = res + lnPart
			oldMeanValue = nowMeanValue
			oldFaultNumber = nowFaultNumber
		#print("res : ")
		#print("last_t : "+str(last_t)+" meanValue : "+str(meanValue)+" LLF : "+str(res))
		return res


	def NHPPwithSum_timeScale( self ,meanValueFun, args ,totalSum):
		resList = []
		totalE = 0
		i = 0
		SimulationData = 0
		while i < totalSum:
			now = self.getU()
			#totalE += now
			totalE += (-1)*emath.log(now)
			#SimulationData = inversefunc(meanValueFun, y_values=totalE)
			SimulationData = self.getInverse(meanValueFun, args, totalE, SimulationData)
			resList.append(SimulationData)
			i += 1
		return resList

	def NHPPwithTime_timeScale(self, meanValueFun, args, endTime):
		resList = []
		totalE = 0
		SimulationData = 0
		while SimulationData <= endTime:
			now = self.getU()
			totalE += (-1)*emath.log(now,math.e)
			#SimulationData = inversefunc(meanValueFun, y_values=totalE)
			#print(SimulationData)
			SimulationData = self.getInverse(meanValueFun, args, totalE, SimulationData + 10)
			#print(SimulationData)
			#if SimulationData == 0.0:
			#	exit()
			resList.append(SimulationData)
		del resList[-1]
		return resList

	def NHPPwithSum_thinning( self ,intensityFun, args ,totalSum, maxIntensity = 0.1):
		resList = []
		totalE = 0
		i = 0
		SimulationData = 0
		while i < totalSum:
			#print("now = self.getU()")
			now = self.getU()
			totalE += (-1/maxIntensity)*emath.log(now)
			SimulationData = totalE
			#SimulationData = self.getInverse(meanValueFun, args, totalE, SimulationData)
			#print("judge = self.getU()")
			judge = self.getU()
			#print(SimulationData)
			if judge < intensityFun(SimulationData, args) / maxIntensity:
				resList.append(SimulationData)
				i += 1
				#print(i)
		return resList


	# 计算gamma分布用被积函数
	# 高精度
	def GammaCdfIntegrate(self, s, b, c):
		#res = self.highPowerRes2(-s * c ,s, b - 1)
		s = Decimal(s)
		b = Decimal(b)
		c = Decimal(c)
		partA = s ** (b - Decimal(1))
		partB = Decimal(-c*s).exp()
		res = partB * partA
		#print(res)
		return res

	def IntegNormal(self, s, b, c):
		expPart = (s-c) / b
		res = math.exp( - expPart * expPart / 2)
		return res
		s = Decimal(s)
		b = Decimal(b)
		c = Decimal(c)
		expPart = ( (s-c) / b )
		ePart = - expPart * expPart / Decimal(2)
		res = Decimal(ePart).exp()
		return res


	# start需要小于等于0,end需要大于等于0,不然计算不正确。
	# 高精度
	def NormalFunction(self, start, end, b, c):
		# new
		#print("b : "+str(float(b)))
		NormalCoe = Decimal(1) / Decimal( Decimal(2 * math.pi).sqrt() * Decimal(b) )
		#print("Decimal(2 * math.pi).sqrt() * Decimal(b) : "+str(float(Decimal(2 * math.pi).sqrt() * Decimal(b))))
		#print("NormalCoe : "+str(float(NormalCoe)))
		if end == 0.0:
			intRes1 = 0.0
			intRes2 = 0.0
			intRes3 = 0.0
			miniRange = c - (5)*abs(b)
			maxRange = c + (4.5)*abs(b)
			if miniRange < 0:
				intRes1 = integrate.quad(self.IntegNormal,start,miniRange,(b,c))[0]
				if maxRange < 0:
					intRes2 = integrate.quad(self.IntegNormal,miniRange,maxRange,(b,c))[0]
					intRes3 = integrate.quad(self.IntegNormal,maxRange,0,(b,c))[0]
				else:
					intRes2 = integrate.quad(self.IntegNormal,miniRange,0,(b,c))[0]
			else:
				intRes1 = integrate.quad(self.IntegNormal,start,end,(b,c))[0]
			intRes = Decimal(intRes1) + Decimal(intRes2) + Decimal(intRes3)
		else:
			miniRange = c - (3.5)*abs(b)
			maxRange = c + (3.5)*abs(b)
			intRes1 = 0.0
			intRes2 = 0.0
			intRes3 = 0.0
			if start < miniRange:
				if miniRange < end:
					intRes1 = integrate.quad(self.IntegNormal,start,miniRange,(b,c))[0]
					if maxRange < end:
						intRes2 = integrate.quad(self.IntegNormal,miniRange,maxRange,(b,c))[0]
						intRes3 = integrate.quad(self.IntegNormal,maxRange,end,(b,c))[0]
					else:
						intRes2 = integrate.quad(self.IntegNormal,miniRange,end,(b,c))[0]
				else:
					intRes1 = integrate.quad(self.IntegNormal,start,end,(b,c))[0]
			else:
				if maxRange < end:
					intRes1 = integrate.quad(self.IntegNormal,start,maxRange,(b,c))[0]
					intRes2 = integrate.quad(self.IntegNormal,maxRange,end,(b,c))[0]
				else:
					intRes1 = integrate.quad(self.IntegNormal,start,end,(b,c))[0]
			intRes = Decimal(intRes1) + Decimal(intRes2) + Decimal(intRes3)
		#print("intRes1 = "+str(float(intRes1)))
		#print("intRes2 = "+str(float(intRes2)))
		#print("intRes3 = "+str(float(intRes3)))
		#print("NormalCoe = "+str(float(NormalCoe)))
		res = intRes * NormalCoe
		#print(float(res))
		return res

	def LogistFunction_float(self, t, b, c):
		t = t
		b = b
		c = c
		ePart = (c-t) / b
		partA = numpy.exp(ePart)
		res = 1 / (1 + partA)
		return res

	# 高精度
	def LogistFunction(self, t, b, c):
		#ePart = (c-t) / b
		ePart = Decimal(c-t) / Decimal(b)
		try:
			#partA = math.exp(ePart)
			partA = Decimal(ePart).exp()
		except Exception as e:
			print("baseModel.LogistFunction : "+str(float(ePart)))
			print(e)
			raise e
			#return Decimal(0.0)
		#res = 1 / (1 + partA)
		res = Decimal(1) / (Decimal(1) + partA)
		return res

	def ExtremeValueFunction_float(self, t, b, c):
		t = t
		b = b
		c = c
		#ePart = (c-t) / b
		ePart = (c-t) / b
		#print("ePart = "+str(float(ePart)))
		try:
			partA = numpy.exp(ePart)
			#partA = Decimal(ePart).exp()
		except Exception as e:
			print("baseModel.ExtremeValueFunction : " + str(float(ePart)))
			print(e)
			raise e
			#return Decimal(0.0)
		res = numpy.exp(- partA)
		#print("-partA = "+str(float(- partA)))
		#print(float(- partA))
		#res = Decimal(- partA).exp()
		#print("res : "+str(res))
		return res


	# 高精度
	def ExtremeValueFunction(self, t, b, c):
		#ePart = (c-t) / b
		ePart = (Decimal(c)-Decimal(t)) / Decimal(b)
		#print("ePart = "+str(float(ePart)))
		try:
			#partA = math.exp(ePart)
			partA = Decimal(ePart).exp()
		except Exception as e:
			print("baseModel.ExtremeValueFunction : " + str(float(ePart)))
			print(e)
			raise e
			#return Decimal(0.0)
		#res = math.exp(- partA)
		#print("-partA = "+str(float(- partA)))
		#print(float(- partA))
		res = Decimal(- partA).exp()
		#print("res : "+str(res))
		return res

	def ExpBaseMVF_float(self, t, args):
		b = args[0]
		return 1 - math.exp(-b*t)

	# 高精度
	def ExpBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		#ePart = -b * t
		ePart = -Decimal(b)*Decimal(t)
		#res = 1 - math.exp(ePart)
		res = Decimal(1) - Decimal(ePart).exp()
		return res

	# 高精度
	def GammaBaseMVF_new(self, t, args):
		b = args[0]
		c = args[1]
		Gamma_b = Decimal(self.GammaFunction(b))
		earlyPoint =  1 / (t / 10)
		midPoint = 5 / (t / 10)
		lastPoint = 9 / (t / 10)
		intRes1 = integrate.quad(self.GammaCdfIntegrate, 0, earlyPoint, (b, c))[0]
		intRes2 = integrate.quad(self.GammaCdfIntegrate, earlyPoint, midPoint, (b, c))[0]
		intRes3 = integrate.quad(self.GammaCdfIntegrate, midPoint, lastPoint, (b, c))[0]
		intRes4 = integrate.quad(self.GammaCdfIntegrate, lastPoint, t, (b, c))[0]
		b = Decimal(b)
		c = Decimal(c)
		coe = (c ** b) / Gamma_b
		res = Decimal(intRes1) + Decimal(intRes2) + Decimal(intRes3) + Decimal(intRes4)
		#print("intRes1 : "+str(intRes1) + " intRes2 : "+str(intRes2) + " intRes3 : "+str(intRes3) + " intRes4 : "+str(intRes4))
		#print("res : "+str(res))
		resValue = coe * res
		return resValue


	def GammaBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		return stats.gamma.cdf(t,b,0,1/c)


	# 高精度
	def GammaBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		# new
		return Decimal(stats.gamma.cdf(t,b,0,1/c))

		# old
		low_b = b
		low_c = c
		b = Decimal(b)
		c = Decimal(c)
		#print("GammaFunction")
		coe = (c ** b) / Decimal(self.GammaFunction(low_b))
		coe.quantize(Decimal('.000001'), rounding=ROUND_DOWN)
		#print("coe : "+str(coe))
		center = float((b-Decimal(1)) / c)
		xa = c*c
		xb = (Decimal(1)-b)*(Decimal(2)*c)
		xc = (b*b + Decimal(2) - Decimal(3)*b)
		exeFlag = False
		if xb*xb - Decimal(4)*xa*xc > 0:
			r1 = float( (- xb + Decimal(xb*xb - Decimal(4)*xa*xc).sqrt()) / (Decimal(2) * xa) )
			r2 = float( (- xb - Decimal(xb*xb - Decimal(4)*xa*xc).sqrt()) / (Decimal(2) * xa) )
			if center > 0:
				if r1 < r2:
					miniRange = center - 7 * abs(r1 - center)
					maxRange = center + 8 * abs(r2 - center)
				else:
					miniRange = center - 7 * abs(r2 - center)
					maxRange = center + 8 * abs(r1 - center)
				if miniRange < 0.0:
					miniRange = 0
				if maxRange < 0.0:
					maxRange = 0.0
				#print("miniRange : "+str(miniRange))
				#print("maxRange : "+str(maxRange))
				intRes1 = 0.0
				intRes2 = 0.0
				intRes3 = 0.0
				#print("integrate.quad")
				if 0 < miniRange:
					intRes1 = integrate.quad(self.GammaCdfIntegrate, 0, miniRange, (low_b, low_c))[0]
					if maxRange < t:
						intRes2 = integrate.quad(self.GammaCdfIntegrate, miniRange, maxRange, (low_b, low_c))[0]
						intRes3 = integrate.quad(self.GammaCdfIntegrate, maxRange, t, (low_b, low_c))[0]
					else:
						intRes2 = integrate.quad(self.GammaCdfIntegrate, miniRange, t, (low_b, low_c))[0]
				else:
					if maxRange < t:
						intRes1 = integrate.quad(self.GammaCdfIntegrate, 0, maxRange, (low_b, low_c))[0]
						intRes2 = integrate.quad(self.GammaCdfIntegrate, maxRange, t, (low_b, low_c))[0]
					else:
						intRes1 = integrate.quad(self.GammaCdfIntegrate, 0, t, (low_b, low_c))[0]
				res = Decimal(intRes1) + Decimal(intRes2) + Decimal(intRes3)
				#print("intRes1 : "+str(intRes1) + " " +"intRes2 : "+str(intRes2) + " " +"intRes3 : "+str(intRes3) + " ")
			else:
				exeFlag = True
		else:
			exeFlag = True
		if exeFlag == True:
			res = Decimal(integrate.quad(self.GammaCdfIntegrate, 0, t, (low_b, low_c))[0])
		#print("intRes1 = "+str(float(intRes1)))
		#print("intRes2 = "+str(float(intRes2)))
		#print("intRes3 = "+str(float(intRes3)))
		res.quantize(Decimal('.000001'), rounding=ROUND_DOWN)
		#print("res : "+str(res))
		resValue = res * coe
		#print("resValue = "+str(float(resValue)))
		return resValue

	# 高精度
	def ParetoBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		#partA = c / (c + t)
		#res = 1 - (partA ** b)
		partA = Decimal(c) / Decimal(c+t)
		if partA < 0:
			print("partA : "+str(float(partA)))
			print("args : "+str(args))
			print("t : "+str(t))
		try:
			res = Decimal(1) - self.decimalContext.power(partA,Decimal(b))
			#res = Decimal(1) - (partA ** Decimal(b))
		except Exception as e:
			print("partA : "+str(float(partA)))
			print("b : "+str(float(b)))
			print(e)
			raise e
		return res

	# 低精度
	def ParetoBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		#partA = c / (c + t)
		#res = 1 - (partA ** b)
		partA = c / (c+t)
		if partA < 0:
			print("partA : "+str(partA))
			print("args : "+str(args))
			print("t : "+str(t))
		res = 1 - (partA ** b)
		
		return res

	def TruncNormalBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		#print("t : "+str(t))
		#print("第一个参数 : "+str(c))
		#print("第二个参数 : "+str(b))
		

		# new
		from scipy import stats
		F0 = stats.norm.cdf(0,c,b)
		Ft = stats.norm.cdf(t,c,b)
		#print("TruncNormalBaseMVF_float")
		#print("Ft = "+str(Ft))
		return (Ft - F0) / (1 - F0)

	def TruncNormalBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]

		# new
		F0 = Decimal(stats.norm.cdf(0,c,b))
		Ft = Decimal(stats.norm.cdf(t,c,b))
		return (Ft - F0) / (Decimal(1) - F0)

		# old
		NormalConstant = self.NormalFunction(-numpy.inf,0,b,c)
		#print("NormalConstant : "+str(float(NormalConstant)))
		fPart = self.NormalFunction(0,t,b,c)
		#print("fPart : "+str(float(fPart)))
		res = (fPart) / (Decimal(1) - NormalConstant)
		#print("TruncNormalBaseMVF Res = "+str(float(res)))
		return res

	def LogNormalBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		logT = emath.log(t)
		# new
		return stats.norm.cdf(logT,c,b)

	def LogNormalBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		# new
		return Decimal(stats.norm.cdf(math.log(t),c,b))

		# old
		if math.log(t) <= 0:
			norRes1 = self.NormalFunction(-numpy.inf,math.log(t),b,c)
			norRes2 = Decimal(0)
		else:
			norRes1 = self.NormalFunction(-numpy.inf,0,b,c)
			norRes2 = self.NormalFunction(0,math.log(t),b,c)
		norRes = norRes1 + norRes2
		return norRes

	
	def TruncLogistBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		
		F0 = self.LogistFunction_float(0, b, c)
		Ft = self.LogistFunction_float(t, b, c)
		res = (Ft - F0) / (1 - F0)
		return res

	# 高精度
	def TruncLogistBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		
		F0 = self.LogistFunction(0, b, c)
		Ft = self.LogistFunction(t, b, c)
		res = (Ft - F0) / (Decimal(1) - F0)
		return res

	
	def LogLogistBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		res = self.LogistFunction_float(emath.log(t), b, c)
		return res

	# 高精度
	def LogLogistBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		res = self.LogistFunction(math.log(t), b, c)
		return res

	# 高精度	
	def TruncEVMaxBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		F0 = self.ExtremeValueFunction(0, b, c)
		Ft = self.ExtremeValueFunction(t, b, c)
		res = (Ft - F0) / (Decimal(1) - F0)
		return res

	# 高精度	
	def LogEVMaxBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		res = self.ExtremeValueFunction(math.log(t), b, c)
		return res

	# 高精度	
	def TruncEVMinBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		F0 = self.ExtremeValueFunction(0, b, c)
		Ft = self.ExtremeValueFunction(-t, b, c)
		#print("PartA = "+str(F0 - Ft))
		#print("PartB = "+str(F0))
		#print("res = "+str((F0 - Ft)/F0))
		res = (F0 - Ft) / F0
		return res

	# 高精度	
	def LogEVMinBaseMVF(self, t, args):
		b = args[0]
		t = float(t)
		c = args[1]
		Ft = self.ExtremeValueFunction(-math.log(t), b, c)
		res = Decimal(1) - Ft
		return res


	
	def TruncEVMaxBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		F0 = self.ExtremeValueFunction_float(0, b, c)
		Ft = self.ExtremeValueFunction_float(t, b, c)
		res = (Ft - F0) / (1 - F0)
		return res

	
	def LogEVMaxBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		res = self.ExtremeValueFunction_float(emath.log(t), b, c)
		return res

	
	def TruncEVMinBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		F0 = self.ExtremeValueFunction_float(0, b, c)
		Ft = self.ExtremeValueFunction_float(-t, b, c)
		#print("PartA = "+str(F0 - Ft))
		#print("PartB = "+str(F0))
		#print("res = "+str((F0 - Ft)/F0))
		res = (F0 - Ft) / F0
		return res

	
	def LogEVMinBaseMVF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		Ft = self.ExtremeValueFunction_float(-emath.log(t), b, c)
		res = 1 - Ft
		return res


	#强度函数
	def ExpBaseIF_float(self, t, args):
		b = args[0]
		return b * math.exp(-b*t)

	# 高精度	
	def ExpBaseIF(self, t, args):
		b = args[0]
		return Decimal(b) * Decimal(-b*t).exp()

	def GammaBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		return stats.gamma.pdf(t,b,0,1/c)

	# 高精度	
	def GammaBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		# new 
		return Decimal(stats.gamma.pdf(t,b,0,1/c))

		# old
		low_b = b
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		return (c**b) * Decimal(-c*t).exp() * (t**(b-Decimal(1))) / Decimal(self.GammaFunction(low_b))

	# 高精度	
	def ParetoBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		partA = b * ((c/(c+t))**b)
		partB = c+t
		res = partA / partB
		return res

	# 低精度	
	def ParetoBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		partA = b * ((c/(c+t))**b)
		partB = c+t
		res = partA / partB
		return res


	def TruncNormalBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		return stats.norm.pdf(t,c,b) / (1 - stats.norm.cdf(0,c,b))


	# 高精度	
	def TruncNormalBaseIF(self, t, args):
		b = args[0]
		c = args[1]


		# new
		return Decimal(stats.norm.pdf(t,c,b))  / (Decimal(1) - Decimal(stats.norm.cdf(0,c,b)))


		# old
		low_b = b
		low_c = c
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		#print("b : "+str(float(b)))
		#print("c : "+str(float(c)))
		ePartA = -Decimal(0.5)*(((c-t)/b)**Decimal(2))
		partA = Decimal(ePartA).exp() * (Decimal(1) / (Decimal(2*math.pi).sqrt()*b))
		partB = (Decimal(1) - Decimal(self.NormalFunction(-numpy.inf,0,low_b,low_c)))
		res = partA / partB
		#print("res : "+str(float(res)))
		#print("partA : "+str(float(partA)))
		#print("partB : "+str(float(partB)))
		return res

	
	def LogNormalBaseIF_float(self, t, args):
		b = Decimal(args[0])
		c = Decimal(args[1])
		t = Decimal(t)
		ePart = -Decimal(0.5)*(((c-t.ln())/b)**Decimal(2))
		partA = b*Decimal(2*math.pi).sqrt()*t
		res = Decimal(ePart).exp() / partA
		return float(res)


	# 高精度	
	def LogNormalBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		ePart = -Decimal(0.5)*(((c-Decimal(t).ln())/b)**Decimal(2))
		partA = b*Decimal(2*math.pi).sqrt()*t
		res = Decimal(ePart).exp() / partA
		return res


	
	def TruncLogistBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		ePartA = numpy.exp(t/b)
		ePartB = numpy.exp(c/b)
		partA = ePartA*(1+ePartB)
		partB = b * ((ePartA + ePartB)**2)
		res = partA / partB
		return res

	# 高精度	
	def TruncLogistBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		ePartA = Decimal(t/b).exp()
		ePartB = Decimal(c/b).exp()
		partA = ePartA*(Decimal(1)+ePartB)
		partB = b * ((ePartA + ePartB)**Decimal(2))
		res = partA / partB
		return res

	def LogLogistBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		ePartA = numpy.exp(c/b)
		#tPow = t ** ((b-Decimal(1)) / b)
		tPow = emath.power(t, (1-b) / b)
		tbPow = emath.power(t,1/b)
		partA = ePartA * tPow
		partB = b * (emath.power(ePartA + tbPow,2))
		res = partA / partB
		return res

	# 高精度	
	def LogLogistBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		ePartA = Decimal(c/b).exp()
		#tPow = t ** ((b-Decimal(1)) / b)
		tPow = t ** ((Decimal(1)-b) / b)
		tbPow = t ** (Decimal(1)/b)
		partA = ePartA * tPow
		partB = b * ((ePartA + tbPow)**Decimal(2))
		res = partA / partB
		return res

	# 高精度	
	def TruncEVMaxBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		expPart = (c-t) / b
		ePartA = expPart - Decimal(expPart).exp()
		partA = Decimal(ePartA).exp()
		ePartB = -Decimal(c/b).exp()
		partB = b * (Decimal(1) - Decimal(ePartB).exp())
		res = partA / partB
		return res

	# 高精度	
	def LogEVMaxBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		expPart = (c-Decimal(t).ln()) / b
		ePartA = expPart - Decimal(expPart).exp()
		partA = Decimal(ePartA).exp()
		res = partA / (b * t)
		return res

	# 高精度	
	def TruncEVMinBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		ePartA = c/b
		ePartB = (c+t) / b
		expPart = Decimal(ePartA).exp() - Decimal(ePartB).exp() + ePartB
		res = Decimal(expPart).exp() / b
		return res

	# 高精度	
	def LogEVMinBaseIF(self, t, args):
		b = args[0]
		c = args[1]
		b = Decimal(b)
		c = Decimal(c)
		t = Decimal(t)
		expPart = (c+Decimal(t).ln()) / b
		#print("expPart : "+str(expPart))
		ePartA = expPart - Decimal(expPart).exp()
		partA = Decimal(ePartA).exp()
		res = partA / (b * t)
		#print("res : "+str(float(res)))
		return res

	def TruncEVMaxBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		expPart = (c-t) / b
		ePartA = expPart - numpy.exp(expPart)
		partA = numpy.exp(ePartA)
		ePartB = -numpy.exp(c/b)
		partB = b * (1 - numpy.exp(ePartB))
		res = partA / partB
		return res

	
	def LogEVMaxBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		expPart = (c-emath.log(t)) / b
		ePartA = expPart - numpy.exp(expPart)
		partA = numpy.exp(ePartA)
		res = partA / (b * t)
		return res

	
	def TruncEVMinBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		ePartA = c/b
		ePartB = (c+t) / b
		expPart = numpy.exp(ePartA) - numpy.exp(ePartB) + ePartB
		res = numpy.exp(expPart) / b
		return res
	
	def LogEVMinBaseIF_float(self, t, args):
		b = args[0]
		c = args[1]
		t = t
		expPart = (c+emath.log(t)) / b
		#print("expPart : "+str(expPart))
		ePartA = expPart - numpy.exp(expPart)
		partA = numpy.exp(ePartA)
		res = partA / (b * t)
		#print("res : "+str(float(res)))
		return res

	def ExpBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		return emath.log(1/(1-y))/b

	def GammaBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		return stats.gamma.ppf(y, b,0,1/c)

	def ParetoBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		return -c*(((1-y)**(1/b))-1)*((1-y)**(-1/b))

	def TruncNormalBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		F0 = stats.norm.cdf(0,c,b)
		g_y = (y*(1-F0))+F0
		return stats.norm.ppf(g_y,c,b)

	def LogNormalBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		return numpy.exp(stats.norm.ppf(y,c,b))

	def TruncLogistBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		partA = numpy.exp(c/b)*(y-1)
		partB = 1+numpy.exp(c/b)*y
		lnPart = b*emath.log(-partA/partB)
		return c - lnPart

	def LogLogistBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		lnPart = b*emath.log((1-y)/y)
		expPart = numpy.exp(c-lnPart)
		return expPart

	def TruncEVMaxBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		expBC = numpy.exp(c/b)
		partA = numpy.exp(expBC)
		partB = partA*y+1-y
		lnPart = emath.log(partA/partB)
		lnlnPart = emath.log(lnPart)
		res = c - b*lnlnPart
		return res

	def LogEVMaxBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		expBC_m = numpy.exp(-c/b)
		res = (-expBC_m*emath.log(y))**(-b)
		return res

	def TruncEVMinBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		expBC = numpy.exp(c/b)
		partA = numpy.exp(expBC)
		partB = y-1
		lnPart = emath.log(-partA/partB)
		lnlnPart = emath.log(lnPart)
		res = b*lnlnPart - c
		return res

	def LogEVMinBaseInverseMVF_float(self, y, args):
		y = y
		b = args[0]
		c = args[1]
		expBC_m = numpy.exp(-c/b)
		res = (-expBC_m*emath.log(1-y))**(b)
		return res



class LindleyDist(usefulMathFunction):

	LindleyModelNames = ["GammaLindley", "ExpLindley", "PowerLindley", "ExpPowerLindley", "GompertzLindley", "WeightedLindley", "OriginalLindley"]

	def __init__(self,):
		pass

	def cumulativeDistributionFunction(self, modelName):
		if modelName in self.modelNames:
			return self.LindleyCdfDict[modelName]	
		else:
			return None

	def probabilityDensityFunctions(self, modelName):
		if modelName in self.modelNames:
			return self.LindleyPdfDict[modelName]	
		else:
			return None

	def OriginalLindleyCDF(self, t ,args):
		a = args[0]
		partA = 1 + (a*t)/(a+1)
		res = 1 - partA * math.exp(-a*t)
		return res

	def GammaLindleyCDF(self, t ,args):
		a = args[0]
		b = args[1]
		partA = ( ( a*b + b - a ) * ( a*t + 1 ) + a ) * math.exp(-a*t)
		partB = b*(1+a)
		res = 1 - partA / partB
		return res

	def ExpLindleyCDF(self, t ,args):
		a = args[0]
		c = args[1]
		partA = (1 + a + a*t) / (1 + a)
		res = ( 1 - partA*math.exp(-a*t) ) ** c
		return res

	def PowerLindleyCDF(self, t ,args):
		a = args[0]
		b = args[1]
		x = t**b
		res = self.OriginalLindleyCDF(x, args)
		return res

	def ExpPowerLindleyCDF(self, t ,args):
		a = args[0]
		b = args[1]
		c = args[2]
		partA = self.PowerLindleyCDF(t, args)
		res = 1 - (partA ** c)
		return res

	def GompertzLindleyCDF(self, t ,args):
		a = args[0]
		b = args[1]
		expPart = math.exp(b*t)
		partA = ( a / (a - 1 + expPart) ) ** 2
		partB = ( a + expPart ) / ( a + 1 )
		res = 1 - partA * partB
		return res

	def WeightedLindleyCDF(self, t ,args):
		a = args[0]
		b = args[1]
		Gamma1 = self.GammaFunction(b)
		Gamma2 = self.GammaFunction(b, a*t)
		partA = (a+b) * Gamma2
		partB = ( (a*t) ** b ) * math.exp(-a*t)
		partC = (a+b) * Gamma1
		resPart = (partA + partB) / partC
		res = 1 - resPart
		return res

	def OriginalLindleyPDF(self, t ,args):
		a = args[0]
		partA = ( a / (a + 1) ) * a
		partB = (1 + t) * math.exp(-a*t)
		res = partA * partB
		return res

	def GammaLindleyPDF(self, t ,args):
		a = args[0]
		b = args[1]
		partA = a * a * math.exp(-a*t)
		partB = (a*b + b - a) * t + 1
		partC = b * (1 + a)
		res = (partA / partC) * partB
		return res

	def ExpLindleyPDF(self, t ,args):
		a = args[0]
		c = args[1]
		partA = (a / (a + 1)) * a * c
		partB = (t + 1) * math.exp(-a * t)
		partC = ( 1 - (1+a+a*t) / (1+a) * math.exp(-a*t) ) ** (c-1)
		res = partA * partB * partC
		return res

	def PowerLindleyPDF(self, t ,args):
		a = args[0]
		c = args[1]
		partA = (a*a*b) / (1 + (t**b))
		partB = math.exp(-a*(t**b)) * (t**(b-1))
		res = partA * partB
		return res

	def ExpPowerLindleyPDF(self, t ,args):
		a = args[0]
		b = args[1]
		c = args[2]
		partA = (a / (a+1))*a*c*b*(t**(b-1))
		partB = (1 + (t**b)) * math.exp(-a*(t**b))
		partC1 = 1 + (a/(a+1))*(t**b)
		partC2 = math.exp(-a*(t**b))
		partC = (1 - partC1*partC2) ** (c-1)
		res = partA * partB * partC
		return res

	def GompertzLindleyPDF(self, t ,args):
		a = args[0]
		b = args[1]
		partA = (-a/(a+1))*a
		partB1 = math.exp(b*t) / (a-1+math.exp(b*t))
		partB2 = b / (a-1+math.exp(b*t))
		partB = partB1 * partB2
		partC1 = (2*b) / (a-1+math.exp(b*t))
		partC2 = math.exp(b*t) / (a-1+math.exp(b*t))
		partC3 = (a * math.exp(b*t)) / (a-1+math.exp(b*t))
		partC = partC1 * partC2 * partC3
		res = partA * (partB - partC)
		return res

	def WeightedLindleyPDF(self, t ,args):
		a = args[0]
		b = args[1]
		partA = ( a**(b+1) ) * ( t**(b-1) ) * ( t+1 ) * math.exp(-a*t)
		partB = (a+b) * self.GammaFunction(b)
		res = partA / partB
		return res

	LindleyCdfDict = {
			"GammaLindley"		:	GammaLindleyCDF,
			"ExpLindley"		:	ExpLindleyCDF,
			"PowerLindley"		:	PowerLindleyCDF,
			"ExpPowerLindley"	:	ExpPowerLindleyCDF,
			"GompertzLindley"	:	GompertzLindleyCDF,
			"WeightedLindley"	:	WeightedLindleyCDF,
			"OriginalLindley"	:	OriginalLindleyCDF,
	}
	LindleyPdfDict = {
			"GammaLindley"		:	GammaLindleyPDF,
			"ExpLindley"		:	ExpLindleyPDF,
			"PowerLindley"		:	PowerLindleyPDF,
			"ExpPowerLindley"	:	ExpPowerLindleyPDF,
			"GompertzLindley"	:	GompertzLindleyPDF,
			"WeightedLindley"	:	WeightedLindleyPDF,
			"OriginalLindley"	:	OriginalLindleyPDF,
	}

class BurrDist():

	def __init__(self,):
		pass




















