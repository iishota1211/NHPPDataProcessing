from classicUtils import parametericPrediction, existSRM, modelTool

def sparkFun(sparkTaskDict):
	# 准备参数
	culFormatedTrainData = sparkTaskDict["culFormatedTrainData"]
	culFormatedTestData = sparkTaskDict["culFormatedTestData"]
	paraList = sparkTaskDict["paraList"]
	modelDict = dict()
	modelDict["modelType"] = sparkTaskDict["modelType"]
	modelDict["modelName"] = sparkTaskDict["modelName"]
	meanValueFunc, meanValueFunc_backup = modelTool.meanValueFunction(modelDict)
	dataType = sparkTaskDict["dataType"]

	# 开始预测
	#resList = parametericPrediction.calcNum(paraList, meanValueFunc_backup, meanValueFunc_backup, culFormatedTrainData, culFormatedTestData)
	resList = [[],True,True]
	# 收集结果
	sparkResDict = dict()
	sparkResDict["culFormatedPredData"] = resList[0]
	sparkResDict["culPMAE"] = resList[2]
	sparkResDict["nonCulPMAE"] = resList[1]
	return sparkResDict
		
	




































