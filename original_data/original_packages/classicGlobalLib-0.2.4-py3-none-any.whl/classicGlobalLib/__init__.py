# Version 0.2.4
# 区分EM(来源于R-SRATS)算法与普通的MLE

# Version 0.2.3
# 更新了classicEstCore, 支持记录推参时间 estCostTime

# Version 0.2
# 新增 classicRelAssCore 模块。实现了软件可靠性相关指标的计算

# Version 0.1
# 包名 	: classicGlobalLib
# 功能	: 实现了11种 typeI-NHPP 模型的经典最大似然估计(基于R-SRAT), 经典最小二乘估计
# 主要模块与接口 : 
# classicMLE.parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData)
# classicLSE.parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData)