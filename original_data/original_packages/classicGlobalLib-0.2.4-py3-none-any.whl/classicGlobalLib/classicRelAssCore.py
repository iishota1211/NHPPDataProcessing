from classicUtils import parametericPrediction, existSRM, modelTool, softwareReliabilityTool
import copy
from scipy import optimize

def sparkFun(sparkTaskDict):
	# 准备参数
	culFormatedTrainData = sparkTaskDict["culFormatedTrainData"]
	culFormatedTestData = sparkTaskDict["culFormatedTestData"]
	paraList = sparkTaskDict["paraList"]
	modelDict = dict()
	modelDict["modelType"] = sparkTaskDict["modelType"]
	modelDict["modelName"] = sparkTaskDict["modelName"]
	meanValueFunc, meanValueFunc_backup = modelTool.meanValueFunction(modelDict)
	dataType = sparkTaskDict["dataType"]
	optionDict = sparkTaskDict["optionDict"]

	startTime = culFormatedTrainData[-1][0]
	# 计算 NHPP-based SRM 软件可靠性
	softwareReliabilityCulFormatedList = getSoftwareReliability(startTime, meanValueFunc, paraList)

	# 设置软件开发测试成本以及预期运行时长
	costSettingList = []
	if dataType == "time":
		settingDict = dict()
		settingDict["c1"] = 10
		settingDict["c2"] = 1
		settingDict["c3"] = 5
		settingDict["tLC"] = 100
		costSettingList.append(settingDict)
	elif dataType == "group":
		settingDict = dict()
		settingDict["c1"] = 10
		settingDict["c2"] = 1
		settingDict["c3"] = 5
		settingDict["tLC"] = 100
		costSettingList.append(settingDict)
	# 计算最佳发布时间
	bestReleaseTimeList = getbestReleaseTime(costSettingList, meanValueFunc, paraList, startTime)
	
	# 收集结果
	sparkResDict = dict()
	sparkResDict["softwareReliabilityCulFormatedList"] = softwareReliabilityCulFormatedList
	sparkResDict["bestReleaseTimeList"] = bestReleaseTimeList
	return sparkResDict

def getSoftwareReliability(startTime, meanValueFunc, paraList):
	endTime = startTime * 6
	softwareReliabilityCulFormatedList = []
	startEstNum = meanValueFunc(startTime, paraList)
	if dataType == "time":
		# 软件可靠性计算打点精度
		intervalRate = 100 
		i = 1
		while i <= intervalRate:
			intervalTime = (i / intervalRate) * (endTime - startTime)
			nowTime = startTime + intervalTime
			nowEstNum = meanValueFunc(nowTime, paraList)
			# 仅限TypeI-NHPP模型计算软件可靠性
			softwareReliability = softwareReliabilityTool.typeI(startEstNum, nowEstNum)
			softwareReliabilityCulFormatedList.append([nowTime, softwareReliability])
			i += 1
	elif dataType == "group":
		i = 1
		while i <= endTime:
			nowTime = startTime + i
			nowEstNum = meanValueFunc(nowTime, paraList)
			# 仅限TypeI-NHPP模型计算软件可靠性
			softwareReliability = softwareReliabilityTool.typeI(startEstNum, nowEstNum)
			softwareReliabilityCulFormatedList.append([nowTime, softwareReliability])
			i += 1
	return softwareReliabilityCulFormatedList

def costFun(t0, c1, c2, c3, tLC, meanValueFunc, paraList):
	M1 = float(meanValueFunc(t0, paraList))
	M2 = float(meanValueFunc(tLC + t0, paraList)) - M1
	partA = c1 * t0
	partB = c2 * M1
	partC = c3 * (M2 - M1)
	return partA + partB + partC

def getbestReleaseTime(costSettingList, meanValueFunc, paraList, initTime):
	bestReleaseTimeList = []
	for settingDict in costSettingList:
		resDict = copy.deepcopy(settingDict)
		c1 = settingDict["c1"]
		c2 = settingDict["c2"]
		c3 = settingDict["c3"]
		tLC = settingDict["tLC"]
		maxTime = tLC
		bounds = [[1e-14,maxTime]]
		res = optimize.minimize(costFun, initTime, (c1, c2, c3, tLC, meanValueFunc, paraList), method='Nelder-Mead', bounds=bounds)
		resDict["bestReleaseTime"] = res.x
		resDict["totalCost"] = res.fun
		bestReleaseTimeList.append(resDict)
	return bestReleaseTimeList
































