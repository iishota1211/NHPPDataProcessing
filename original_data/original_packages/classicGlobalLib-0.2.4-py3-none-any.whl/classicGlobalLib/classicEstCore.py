import copy, traceback
from classicGlobalLib import classicMLE, classicLSE, classicEM
from classicUtils import SRMtool

# spark内的具体执行函数
def sparkFun(sparkTaskDict):
	sparkResDict = dict()
	culFormatedTrainData = sparkTaskDict["culFormatedTrainData"]
	methodDict 	= copy.deepcopy(sparkTaskDict["methodDict"])
	modelDict 	= sparkTaskDict["modelDict"]
	dataType 	= sparkTaskDict["dataType"]
	methodName 	= methodDict["methodName"]
	dataName 	= sparkTaskDict["dataName"]
	try:
		# 开始推参估计
		if methodName == "EM":
			estResDict 	= classicEM.parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData)
		elif methodName == "LSE":
			estResDict 	= classicLSE.parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData)
		elif methodName == "MLE":
			estResDict 	= classicMLE.parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData)
	except Exception as e:
		SRMtool.sendNoticeMail("基础推参出错", "dataType : "+dataType+"\n\n dataName : "+dataName+"\n\n 错误输出 : "+str(traceback.format_exc()))
		raise e
	
	# 整理结果
	sparkResDict["methodDict"] 		= methodDict
	sparkResDict["modelDict"] 		= modelDict
	sparkResDict["dataType"] 		= estResDict["dataType"]
	sparkResDict["paraList"] 		= estResDict["paraList"]
	sparkResDict["estCostTime"] 		= estResDict["estCostTime"]
	sparkResDict["culFormatedEstData"]   = estResDict["culFormatedEstData"]
	sparkResDict["measureNameList"] 	 = estResDict["measureNameList"]
	sparkResDict["measureValueDict"] 	 = estResDict["measureValueDict"]
	return sparkResDict