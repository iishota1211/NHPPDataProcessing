from classicUtils import SRMtool, measure, existSRM, RSRAT, modelTool
import time as timeLib
from scipy import optimize
import math

# 基于RSRAT实现对typeI-NHPP模型的最大似然参数估计
def parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue = True):
	supportModelNameList = modelTool.supportModelNameList()
	NoEMList = ["Log","Plaw","Gtlogist","DSshaped","ISshaped"]
	#supportModelNameList = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin","Log","Plaw","Gtlogist","DSshaped","ISshaped"]
	if modelDict["modelType"] != "typeI":
		return False
	if modelDict["modelName"] not in supportModelNameList:
		return False

	estResDict = dict()

	# 数据预处理
	culTrainData = []
	oldNum = 0
	relIntervalFlag = False
	for time,num in culFormatedTrainData:
		if num == oldNum and dataType == "time":
			relIntervalFlag = True
			culTrainData.append(time)
			break
		oldNum = num
		if dataType == "time":
			culTrainData.append(time)
		elif dataType == "group":
			culTrainData.append(num)
	tempData = SRMtool.toNonCulData(culTrainData)

	trainData = []
	for dataEle in tempData:
		if dataEle < 1000:
			trainData.append(round(dataEle,5))
		else:
			trainData.append(round(dataEle,1))
	
	if relIntervalFlag == True:
		trainData[-1] = -1 * trainData[-1]

	# 获取平均值函数
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
	likelihoodFun, likelihoodFun_backup = modelTool.logLikelihoodFunction(modelDict, dataType)
	parameterBounds = modelTool.parameterBounds(modelDict)

	startTime = timeLib.time()	
	if modelDict["modelName"] not in NoEMList:
		#!= "Log" and modelDict["modelName"] != "Plaw" and modelDict["modelName"] != "Gtlogist":
		# RSRAT
		if dataType == "time":
			paraList,res = RSRAT.getParameter_timeData(trainData,modelDict["modelName"])
		elif dataType == "group":
			paraList,res = RSRAT.getParameter_groupData(trainData,modelDict["modelName"])
	else:
		# Log, Plaw, Gtlogist 没有RSRAT实现, 出于统一API的考虑, 用普通的最大似然估计实现(非EM估计)
		def lossFun(paraList, culFormatedTrainData, meanValueFun, intensityFun):
			return -likelihoodFun(paraList, culFormatedTrainData, meanValueFun, intensityFun)
		wPara = len(culFormatedTrainData)
		endTime = culFormatedTrainData[-1][0]
		initPara = [wPara, ]
		if modelDict["modelName"] == "Log":
			bPara = (2.71-1)/endTime # (e-1)/t_n
			initPara.append(bPara)
		elif modelDict["modelName"] == "Plaw":
			bPara = math.log(1.5)/math.log(endTime)
			initPara.append(bPara)
		elif modelDict["modelName"] == "Gtlogist":
			aPara = 10
			bPara = 10
			cPara = math.log(1.1)/math.log(endTime)
			initPara.append(aPara)
			initPara.append(bPara)
			initPara.append(cPara)
		elif modelDict["modelName"] == "DSshaped":
			bPara = 3.88 / endTime
			initPara.append(bPara)
		elif modelDict["modelName"] == "ISshaped":
			bPara = 2.9 / endTime
			cPara = 1
			initPara.append(bPara)
			initPara.append(cPara)

		optimizeRes = optimize.minimize(fun=lossFun, x0=initPara, args=(culFormatedTrainData, meanValueFun, intensityFun), method = "Nelder-Mead", bounds=parameterBounds)
		paraList = optimizeRes.x
		#print(optimizeRes)
		res = [-optimizeRes.fun, optimizeRes.fun*2 + 2*len(initPara)]


	endTime = timeLib.time()
	intervalTime = endTime - startTime
	#print("推参耗时："+str(intervalTime))
	
	
	# 定义主指标
	mainMeasureValue = res[1]
	mainMeasureName = "AIC"

	# 把当前拥有的所有的信息都传入 extraMeasure(), 然后 extraMeasure() 方法会尽力计算被要求的额外指标
	nowInfoDict = dict()
	nowInfoDict["mainMeasureValue"] = mainMeasureValue
	nowInfoDict["mainMeasureName"] = mainMeasureName
	nowInfoDict["methodDict"] = methodDict
	nowInfoDict["culFormatedTrainData"] = culFormatedTrainData
	nowInfoDict["meanValueFun"] = meanValueFun
	nowInfoDict["intensityFun"] = intensityFun
	nowInfoDict["likelihoodFun"] = likelihoodFun
	nowInfoDict["meanValueFun_backup"] = meanValueFun_backup
	nowInfoDict["intensityFun_backup"] = intensityFun_backup
	nowInfoDict["likelihoodFun_backup"] = likelihoodFun_backup
	nowInfoDict["paraList"] = paraList
	nowInfoDict["dataType"] = dataType
	measureNameList, measureValueDict = measure.extraMeasure(nowInfoDict)

	# 计算估计值
	culFormatedEstData = []
	if isNeedEstValue == True:
		for time,num in culFormatedTrainData:
			estNum = float(meanValueFun_backup(time, paraList))
			culFormatedEstData.append([time,estNum])


	# 返回推参结果
	estResDict["dataType"] 		= dataType
	estResDict["paraList"] 		= paraList
	estResDict["methodDict"] 	= methodDict
	estResDict["modelDict"] 	= modelDict
	estResDict["estCostTime"]   = intervalTime
	estResDict["culFormatedEstData"] = culFormatedEstData
	estResDict["measureNameList"] 	 = measureNameList
	estResDict["measureValueDict"] 	 = measureValueDict
	return estResDict
	





# 给出模型列表，计算拟合性能最佳的模型
def findBestModel(methodDict, modelDictList, dataType, culFormatedTrainData, isNeedEstValue = False):
	bestEstResDict = dict()
	bestMeasureValue = 999999999
	for modelDict in modelDictList:
		estResDict = parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue)
		AIC = estResDict["measureValueDict"]["AIC"]
		if AIC < bestMeasureValue:
			bestEstResDict = estResDict
			bestMeasureValue = AIC
	return bestEstResDict





























