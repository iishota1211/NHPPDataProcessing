import math,copy
from scipy import optimize
from classicUtils import SRMtool, measure, existSRM, RSRAT, modelTool, likelihoodFunc_TypeI
import time as timeLib

# 基于RSRAT实现对typeI-NHPP模型的最小二乘估计
def parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue = True):
	
	# 获取平均值函数以及参数范围限制
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
	likelihoodFun, likelihoodFun_backup = modelTool.logLikelihoodFunction(modelDict, dataType)
	parameterBounds = modelTool.parameterBounds(modelDict)
	initPara = modelTool.initPara(modelDict)

	modelDictList = []
	tempModelDict = copy.deepcopy(modelDict)
	tempModelDict["paraList"] = copy.deepcopy(initPara)
	modelDictList.append(tempModelDict)

	startTime = timeLib.time()
	# 开始推参
	if dataType == "time":
		res = optimize.minimize(fun=likelihoodFunc_TypeI.negaLogLikelihoodFun_time_ari, x0=initPara, args=(culFormatedTrainData, modelDictList), method = "Nelder-Mead", bounds=parameterBounds)
	elif dataType == "group":
		res = optimize.minimize(fun=likelihoodFunc_TypeI.negaLogLikelihoodFun_group_ari, x0=initPara, args=(culFormatedTrainData, modelDictList), method = "Nelder-Mead", bounds=parameterBounds)
	endTime = timeLib.time()
	intervalTime = endTime - startTime

	# 定义主指标
	mainMeasureValue = 2*res.fun + 2*len(res.x)
	mainMeasureName = "AIC"
	paraList = res.x

	# 计算估计值
	culFormatedEstData = []
	if isNeedEstValue == True:
		for time,num in culFormatedTrainData:
			estNum = float(meanValueFun_backup(time, paraList))
			culFormatedEstData.append([time,estNum])

	# 把当前拥有的所有的信息都传入 extraMeasure(), 然后 extraMeasure() 方法会尽力计算被要求的额外指标
	nowInfoDict = dict()
	nowInfoDict["mainMeasureValue"] = mainMeasureValue
	nowInfoDict["mainMeasureName"] = mainMeasureName
	nowInfoDict["methodDict"] = methodDict
	nowInfoDict["culFormatedTrainData"] = culFormatedTrainData
	nowInfoDict["meanValueFun"] = meanValueFun
	nowInfoDict["intensityFun"] = intensityFun
	nowInfoDict["likelihoodFun"] = likelihoodFun
	nowInfoDict["meanValueFun_backup"] = meanValueFun_backup
	nowInfoDict["intensityFun_backup"] = intensityFun_backup
	nowInfoDict["likelihoodFun_backup"] = likelihoodFun_backup
	nowInfoDict["dataType"] = dataType
	nowInfoDict["paraList"] = paraList
	measureNameList, measureValueDict = measure.extraMeasure(nowInfoDict)

	# 返回推参结果
	estResDict = dict()
	estResDict["dataType"] 		= dataType
	estResDict["paraList"] 		= paraList
	estResDict["methodDict"] 	= methodDict
	estResDict["modelDict"] 	= modelDict
	estResDict["estCostTime"]   = intervalTime
	estResDict["culFormatedEstData"] = culFormatedEstData
	estResDict["measureNameList"] 	 = measureNameList
	estResDict["measureValueDict"] 	 = measureValueDict
	return estResDict
	

# 给出模型列表，计算拟合性能最佳的模型
def findBestModel(methodDict, modelDictList, dataType, culFormatedTrainData, isNeedEstValue = False):
	bestEstResDict = dict()
	bestMeasureValue = 999999999
	for modelDict in modelDictList:
		estResDict = parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue)
		AIC = estResDict["measureValueDict"]["AIC"]
		if AIC < bestMeasureValue:
			bestEstResDict = estResDict
			bestMeasureValue = AIC
	return bestEstResDict








































































