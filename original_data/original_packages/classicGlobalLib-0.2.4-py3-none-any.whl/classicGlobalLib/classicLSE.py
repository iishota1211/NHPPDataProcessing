import math,copy
from scipy import optimize
from classicUtils import SRMtool, measure, existSRM, RSRAT, modelTool
import time as timeLib
# 定义推参损失函数
def lossFun(paraList, meanValueFun, culFormatedTrainData):
	totalLoss = 0
	for nowTime,nowNum in culFormatedTrainData:
		nowEstNum = float(meanValueFun(nowTime, paraList))
		totalLoss += (nowNum - nowEstNum)**2
	lossValue = totalLoss / len(culFormatedTrainData)
	return lossValue

# 基于RSRAT实现对typeI-NHPP模型的最小二乘估计
def parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue = True):
	
	EMmodelList = ["Exp","Gamma","Pareto","TruncNormal","LogNormal","TruncLogist","LogLogist","TruncEVMax","LogEVMax","TruncEVMin","LogEVMin"]
	

	# 获取平均值函数以及参数范围限制
	meanValueFun, meanValueFun_backup = modelTool.meanValueFunction(modelDict)
	intensityFun, intensityFun_backup = modelTool.intensityFunction(modelDict)
	likelihoodFun, likelihoodFun_backup = modelTool.logLikelihoodFunction(modelDict, dataType)
	parameterBounds = modelTool.parameterBounds(modelDict)

	startTime = timeLib.time()
	# 利用RSRAT获得参数的初始估计
	oriList = []
	if dataType == "time":
		for nowTime,nowNum in culFormatedTrainData:
			oriList.append(nowTime)
		oriList = SRMtool.toNonCulData(oriList)
		if modelDict["modelName"] in EMmodelList:
			initPara,measureList = RSRAT.getParameter_timeData(oriList, modelDict["modelName"])
		else:
			initPara = modelTool.initPara(modelDict)
	elif dataType == "group":
		for nowTime,nowNum in culFormatedTrainData:
			oriList.append(nowNum)
		oriList = SRMtool.toNonCulData(oriList)
		if modelDict["modelName"] in EMmodelList:
			initPara,measureList = RSRAT.getParameter_groupData(oriList, modelDict["modelName"])
		else:
			initPara = modelTool.initPara(modelDict)
	else:
		raise

	# 开始推参
	res = optimize.minimize(fun=lossFun, x0=initPara, args=(meanValueFun, culFormatedTrainData), method = "Nelder-Mead", bounds=parameterBounds)
	endTime = timeLib.time()
	intervalTime = endTime - startTime

	# 定义主指标
	mainMeasureValue = res.fun
	mainMeasureName = "MSE"
	paraList = res.x

	# 计算估计值
	culFormatedEstData = []
	if isNeedEstValue == True:
		for time,num in culFormatedTrainData:
			estNum = float(meanValueFun_backup(time, paraList))
			culFormatedEstData.append([time,estNum])

	# 把当前拥有的所有的信息都传入 extraMeasure(), 然后 extraMeasure() 方法会尽力计算被要求的额外指标
	nowInfoDict = dict()
	nowInfoDict["mainMeasureValue"] = mainMeasureValue
	nowInfoDict["mainMeasureName"] = mainMeasureName
	nowInfoDict["methodDict"] = methodDict
	nowInfoDict["culFormatedTrainData"] = culFormatedTrainData
	nowInfoDict["meanValueFun"] = meanValueFun
	nowInfoDict["intensityFun"] = intensityFun
	nowInfoDict["likelihoodFun"] = likelihoodFun
	nowInfoDict["meanValueFun_backup"] = meanValueFun_backup
	nowInfoDict["intensityFun_backup"] = intensityFun_backup
	nowInfoDict["likelihoodFun_backup"] = likelihoodFun_backup
	nowInfoDict["dataType"] = dataType
	nowInfoDict["paraList"] = paraList
	measureNameList, measureValueDict = measure.extraMeasure(nowInfoDict)

	# 返回推参结果
	estResDict = dict()
	estResDict["dataType"] 		= dataType
	estResDict["paraList"] 		= paraList
	estResDict["methodDict"] 	= methodDict
	estResDict["modelDict"] 	= modelDict
	estResDict["estCostTime"]   = intervalTime
	estResDict["culFormatedEstData"] = culFormatedEstData
	estResDict["measureNameList"] 	 = measureNameList
	estResDict["measureValueDict"] 	 = measureValueDict
	return estResDict
	


# 给出模型列表，计算拟合性能最佳的模型
def findBestModel(methodDict, modelDictList, dataType, culFormatedTrainData, isNeedEstValue = False):
	bestEstResDict = dict()
	bestMeasureValue = 999999999
	for modelDict in modelDictList:
		estResDict = parameterEstimate(methodDict, modelDict, dataType, culFormatedTrainData, isNeedEstValue)
		MSE = estResDict["measureValueDict"]["MSE"]
		if MSE < bestMeasureValue:
			bestEstResDict = estResDict
			bestMeasureValue = MSE
	return bestEstResDict







































































